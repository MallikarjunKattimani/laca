package com.hrms.admin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Branch;
import com.hrms.admin.model.BranchRequest;
import com.hrms.admin.repository.BranchRepository;
import com.hrms.admin.response.BranchResponse;
import com.hrms.admin.service.BranchService;

@Service
public class BranchServiceImpl implements BranchService {


	private static final Logger logger = LoggerFactory.getLogger(BranchServiceImpl.class);


	@Autowired
	private BranchRepository repo;

	/**
	 * Returns true when new branch is store in database
	 * 
	 * @param model - new branch data
	 * @return - boolean
	 */

	@Override
	public boolean save(BranchRequest model) {
		boolean flag = Boolean.FALSE;
		Branch entity = new Branch();
		BeanUtils.copyProperties(model, entity);
		//setting values
		entity.setName(model.getName());
		entity.setDescription(model.getDescription());
		entity.setCreatedBy("abc");
		entity.setUpdatedBy("abc");
		Branch d=repo.save(entity);
		if(!Objects.isNull(d)) 
			flag = Boolean.TRUE;
		logger.debug("Branch Added into database :: " + entity);
		return flag;
	}


	/**
	 * Returns true when existing branch data is store in database
	 * 
	 * @param model - new branch data
	 * @param id - branch Id
	 * @return - boolean
	 */

	/**
	 * Returns All Branch data when branch data is available in database
	 * @return - List of Branchresponse
	 */
	@Override
	public Map<String, Object> getAllBranch(Integer pageIndex, Integer pageSize, String sortBy) {

		/*
		 * List<Branch> allBranch = repo.findAll(); List<BranchResponse> models =
		 * allBranch.stream().map(entity -> { BranchResponse model = new
		 * BranchResponse(); BeanUtils.copyProperties(entity, model); return model;
		 * }).collect(Collectors.toList());
		 * 
		 * return models;
		 */

		Pageable paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy));

		Page<Branch> pagedResult = repo.findAll(paging);

		if(pagedResult.hasContent()) {
			//return pagedResult.getContent();
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}
	/**
	 * Returns Branch data when branch data is available in database by id
	 * @param id - branch Id
	 * @return - BranchResponse
	 */
	@Override
	public BranchResponse getById(Long id) {
		Optional<Branch> optionalEntity = repo.findById(id);
		Branch branchEntity = optionalEntity.get();
		BranchResponse model = new BranchResponse();
		BeanUtils.copyProperties(branchEntity, model);
		logger.debug("Branch found with ID = " + id + " " + branchEntity);
		return model;
	}

	/**
	 * Returns true when branch data is deleted from database by id
	 * @param id - branch id
	 * @return - boolean
	 */
	@Override
	public boolean deleteBranch(Long id) {
		repo.deleteById(id);
		logger.debug(" Branch record is deleted from database ");
		return true;

	}

	/**
	 * Returns true when existing Branch data is store in database
	 * 
	 * @param model - new branch data
	 * @param id - branch Id
	 * @return - boolean
	 */
	@Override
	public boolean updateBranch(BranchRequest model, Long id) {
		boolean flag = Boolean.FALSE;
		Optional<Branch> findById = repo.findById(id);
		if (findById.isPresent()) {
			Branch oldBranch = findById.get();
			oldBranch.setName(model.getName());
			oldBranch.setDescription(model.getDescription());
			oldBranch.setCreatedBy("abc");
			oldBranch.setUpdatedBy("abc");
			Branch d =repo.save(oldBranch);
			if(!Objects.isNull(d))
				flag = Boolean.TRUE;
			logger.debug("Branch ID = " + id + " is updated in to database :: " + oldBranch);
			return flag;
		} else {
			logger.error("Branch is not available in to database with ID= " + id);
			return flag;
		}
	}
	
	public static Map<String, Object> mapData(Page<Branch> pagedResult){

		HashMap<String,Object> response = new HashMap<>();
		List<BranchResponse> branchModels = pagedResult.stream().map(branchEntity -> { 
			BranchResponse model =	new BranchResponse(); BeanUtils.copyProperties(branchEntity, model);
			return	model;}).collect(Collectors.toList());

		response.put("data", branchModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}
}