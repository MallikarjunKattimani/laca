package com.hrms.admin.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;


@Entity
@Table(name ="ATTENDANCE")
public class Attendance {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "COMPANYNAME")
	private String companyName;
	
	@Column(name = "BRANCHNAME")
	private String branch;
	
	@Column(name = "IN_TIME", columnDefinition = "varchar")
	private String inTime;
	
	@Column(name = "OUT_TIME", columnDefinition = "varchar")
	private String outTime;
	
	@Column(name = "CREATED_DATE", columnDefinition = "TIMESTAMP",nullable = false,updatable = false)
	@CreationTimestamp
	private LocalDateTime createDate;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "UPDATED_DATE", columnDefinition = "TIMESTAMP")
	@UpdateTimestamp
	private LocalDateTime updateDate;
	
	@Column(name = "UPDATED_BY")
	private String updatedBy;
	
	

	public Attendance() {
		
	}


	public Attendance(Long id, String companyName, String branch, String inTime, String outTime,
			LocalDateTime createDate, String createdBy, LocalDateTime updateDate, String updatedBy) {
		super();
		this.id = id;
		this.companyName = companyName;
		this.branch = branch;
		this.inTime = inTime;
		this.outTime = outTime;
		this.createDate = createDate;
		this.createdBy = createdBy;
		this.updateDate = updateDate;
		this.updatedBy = updatedBy;
	}



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public String getCompanyName() {
		return companyName;
	}



	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}



	public String getBranch() {
		return branch;
	}



	public void setBranch(String branch) {
		this.branch = branch;
	}



	public String getInTime() {
		return inTime;
	}



	public void setInTime(String inTime) {
		this.inTime = inTime;
	}



	public String getOutTime() {
		return outTime;
	}



	public void setOutTime(String outTime) {
		this.outTime = outTime;
	}



	public LocalDateTime getCreateDate() {
		return createDate;
	}



	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}



	public String getCreatedBy() {
		return createdBy;
	}



	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}



	public LocalDateTime getUpdateDate() {
		return updateDate;
	}



	public void setUpdateDate(LocalDateTime updateDate) {
		this.updateDate = updateDate;
	}



	public String getUpdatedBy() {
		return updatedBy;
	}



	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}



	@Override
	public String toString() {
		return "Attendance [id=" + id + ", name=" + companyName + ", branch=" + branch + ", inTime=" + inTime + ", outTime="
				+ outTime + ", createDate=" + createDate + ", createdBy=" + createdBy + ", updateDate=" + updateDate
				+ ", updatedBy=" + updatedBy + "]";
	}	
}
