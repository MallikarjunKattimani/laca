package com.hrms.admin.util;

import com.hrms.admin.model.CompanyRequest;

public class CompanyUtil {
	public static void copyNonNullValues(CompanyRequest req, CompanyRequest db) {

		if (req.getCompanyName() != null) {
			db.setCompanyName((req.getCompanyName()));
		}
		if (req.getDesignation() != null) {
			db.setDesignation((req.getDesignation()));
		}
		

	}
}
