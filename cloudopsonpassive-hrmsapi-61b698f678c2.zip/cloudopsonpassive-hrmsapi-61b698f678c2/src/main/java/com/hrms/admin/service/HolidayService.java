package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.model.HolidayRequest;
import com.hrms.admin.response.HolidayResponse;

public interface HolidayService {

	/**
	 * Takes Reg Form data as input and returns true
	 * 
	 * @param holidayId
	 */
	public boolean save(HolidayRequest model);

	/**
	 * select all rows and give as List<Holidays>
	 */
	public List<HolidayResponse> getAllHolidays();

	/**
	 * Provide id as input and returns one row as one object
	 */
	public HolidayResponse getById(Long id);

	public HolidayResponse getByName(String name);

	/**
	 * Takes PK(ID) as input and perform delete operation
	 */
	public boolean deleteHoliday(Long id);

	public boolean updateHoliday(HolidayRequest model, Long id);

}
