package com.hrms.admin.util;

import com.hrms.admin.model.AttendanceRequest;


public class AttendancesUtil {
	public static void copyNonNullValues(AttendanceRequest  req, AttendanceRequest db) {
	

	if(req.getCompanyName()!=null) {
		db.setCompanyName((req.getCompanyName()));
	}
	if(req.getBranch()!=null ) {
		db.setBranch((req.getBranch()));
	}
	if (req.getInTime()!=null) {
		db.setInTime(req.getInTime());
		
	}
	if (req.getOutTime()!=null) {
		db.setOutTime(req.getOutTime());
		
	}


}
}
