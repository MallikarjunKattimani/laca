package com.hrms.admin.exceptions;

public class PolicyNotCreateException extends RuntimeException {
	private static final long serialVersionUID = 1L;

	public PolicyNotCreateException(String exception) {
		super(exception);

	}

}
