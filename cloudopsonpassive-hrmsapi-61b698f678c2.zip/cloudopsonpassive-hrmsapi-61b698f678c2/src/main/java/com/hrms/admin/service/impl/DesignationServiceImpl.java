package com.hrms.admin.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Designation;
import com.hrms.admin.model.DesignationRequest;
import com.hrms.admin.repository.Designationrepository;
import com.hrms.admin.response.DesignationResponse;
import com.hrms.admin.service.DesignationService;

/**
 * Contains method to perform DB operation on Designation Record
 * 
 * @author {Ramesh}
 *
 */
@Service
public class DesignationServiceImpl implements DesignationService {

	private final static Logger logger = LoggerFactory.getLogger(DesignationServiceImpl.class);

	@Autowired
	Designationrepository repo;

	/**
     * Returns All Designation data when designation data is available in database
     * @return - List of DesignationModel
     */
	@Override
	public List<DesignationResponse> getAllDesignations() {
		
		List<Designation> findAll = repo.findAll();
		List<DesignationResponse> models = new ArrayList<DesignationResponse>();
		for (Designation Entity : findAll) {
			DesignationResponse model = new DesignationResponse();
			BeanUtils.copyProperties(Entity, model);
			models.add(model);
		}
		
		return models;
	}

	/**
     * Returns Designation data when designation data is available in database by id
     * @param id - Designation Id
     * @return - DesignationModel
     */
	@Override
	public DesignationResponse getById(Long id) {
	
		Optional<Designation> designation = repo.findById(id);
		Designation designationEntity = designation.get();
		DesignationResponse model = new DesignationResponse();
		BeanUtils.copyProperties(designationEntity, model);
		logger.debug("Designation found with ID = " + id + " " + designationEntity);
		return model;
		

	}

	 /**
     * Returns true when new Designation is store in database
     * 
     * @param model - new designation data
     * @return - boolean
     */
	@Override
	public boolean save(DesignationRequest model) {
		
		Designation designation = new Designation();
		BeanUtils.copyProperties(model, designation);
		repo.save(designation);
		logger.debug("Designation Added into database :: " + designation);
		// class ");
		return true;

	}

	/**
     * Returns true when existing designation data is store in database
     * 
     * @param model - new designation data
     * @param id - designation Id
     * @return - boolean
     */
	@Override
	public boolean updateDesignation(DesignationRequest model, Long id) {
		
		Optional<Designation> findById = repo.findById(id);
		if (findById != null) {
			Designation olddesignationEntity = findById.get();
			olddesignationEntity.setDesignation(model.getDesignation());
			olddesignationEntity.setSkills(model.getSkills());
			olddesignationEntity.setExperiance(model.getExperiance());
			repo.save(olddesignationEntity);
			logger.debug("Designation ID = " + id + " is updated in to database :: " + olddesignationEntity);
			return true;
		}
		
		logger.error("Designation is not available in to database with ID= " + id);
		return false;
	}

	/**
     * Returns true when Designation data is deleted from database by id
     * @param id - designation id
     * @return - boolean
     */
	@Override
	public boolean deleteDesignation(Long id) {
		
		repo.deleteById(id);
		logger.debug(" Designation record is deleted from database: "+id);
		return true;
	}

}
