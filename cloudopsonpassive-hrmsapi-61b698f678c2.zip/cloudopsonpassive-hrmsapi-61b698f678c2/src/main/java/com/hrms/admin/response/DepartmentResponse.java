package com.hrms.admin.response;

public class DepartmentResponse {
	
	private Long id;
	private String name;
	private String descriptions;
	
	public DepartmentResponse() {
	}
	
	public DepartmentResponse(Long id, String name, String descriptions) {
		this.id = id;
		this.name = name;
		this.descriptions = descriptions;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescriptions() {
		return descriptions;
	}

	public void setDescriptions(String descriptions) {
		this.descriptions = descriptions;
	}
	
}
