package com.hrms.admin.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.Attendance;
import com.hrms.admin.model.AttendanceResponse;


public interface AttendancesRepository extends JpaRepository<Attendance, Long> {
	
	
	Page<Attendance> findAll(Pageable paging);


	

}
