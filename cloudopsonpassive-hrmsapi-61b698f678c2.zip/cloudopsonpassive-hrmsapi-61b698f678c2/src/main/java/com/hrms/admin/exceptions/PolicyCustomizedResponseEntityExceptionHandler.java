package com.hrms.admin.exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
@RestController
public class PolicyCustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {
	@ExceptionHandler(Exception.class)
	public final ResponseEntity<PolicyExceptionResponse> handleAllExceptions(Exception ex, WebRequest request) {
		PolicyExceptionResponse policyExceptionResponse = new PolicyExceptionResponse(new Date(), ex.getMessage(),
				request.getDescription(false));
		return new ResponseEntity<>(policyExceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(PolicyNotFoundException.class)
	public final ResponseEntity<PolicyExceptionResponse> handlePolicyNotFoundException(PolicyNotFoundException ex,
			WebRequest request) {
		PolicyExceptionResponse policyExceptionResponse = new PolicyExceptionResponse(new Date(), ex.getMessage(),
				request.getDescription(false));
		return new ResponseEntity<>(policyExceptionResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(PolicyNotCreateException.class)
	public final ResponseEntity<PolicyExceptionResponse> handlePolicyNotCreatedException(PolicyNotCreateException ex,
			WebRequest request) {
		PolicyExceptionResponse policyExceptionResponse = new PolicyExceptionResponse(new Date(), ex.getMessage(),
				request.getDescription(false));
		return new ResponseEntity<>(policyExceptionResponse, HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(PolicyInvalidInputException.class)
	public final ResponseEntity<PolicyExceptionResponse> handlePolicyNotCreatedException(PolicyInvalidInputException ex,
			WebRequest request) {
		PolicyExceptionResponse policyExceptionResponse = new PolicyExceptionResponse(new Date(), ex.getMessage(),
				request.getDescription(false));
		return new ResponseEntity<>(policyExceptionResponse, HttpStatus.BAD_REQUEST);
	}

}
