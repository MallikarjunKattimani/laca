package com.hrms.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.Project;


public interface ProjectRepository extends JpaRepository<Project, Long> {

	public Project findByname(String name);
	
}
