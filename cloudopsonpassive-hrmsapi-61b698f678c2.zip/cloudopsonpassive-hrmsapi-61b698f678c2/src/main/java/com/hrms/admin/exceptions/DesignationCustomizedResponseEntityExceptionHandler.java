package com.hrms.admin.exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
@RestController
public class DesignationCustomizedResponseEntityExceptionHandler {

	@ExceptionHandler(Exception.class)
	public final ResponseEntity<DesignationExceptionResponse> handleAllExceptions(Exception ex, WebRequest request) {
		DesignationExceptionResponse designationExceptionResponse = new DesignationExceptionResponse(new Date(),
				ex.getMessage(), request.getDescription(false));
		return new ResponseEntity<>(designationExceptionResponse, HttpStatus.INTERNAL_SERVER_ERROR);
	}

	@ExceptionHandler(DesignationRecordNotFoundException.class)
	public final ResponseEntity<DesignationExceptionResponse> handleDepartmentNotFoundException(
			DesignationRecordNotFoundException ex, WebRequest request) {
		DesignationExceptionResponse designationExceptionResponse = new DesignationExceptionResponse(new Date(),
				ex.getMessage(), request.getDescription(false));
		return new ResponseEntity<>(designationExceptionResponse, HttpStatus.NOT_FOUND);
	}

	@ExceptionHandler(DesignationNotCreatedExceptions.class)
	public final ResponseEntity<DesignationExceptionResponse> handleDepartmentNotCreatedException(
			DesignationNotCreatedExceptions ex, WebRequest request) {
		DesignationExceptionResponse designationExceptionResponse = new DesignationExceptionResponse(new Date(),
				ex.getMessage(), request.getDescription(false));
		return new ResponseEntity<>(designationExceptionResponse, HttpStatus.BAD_REQUEST);
	}
}
