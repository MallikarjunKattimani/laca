package com.hrms.admin.service.impl;

import java.math.BigInteger;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Skill;
import com.hrms.admin.model.SkillRequest;
import com.hrms.admin.repository.SkillRepository;
import com.hrms.admin.response.SkillResponse;
import com.hrms.admin.service.SkillService;
/**
 * Contains method to perform DB operation on Skills Record
 * @author {Prabhat}
 *
 */
@Service
public class SkillServiceImpl implements SkillService {

	private static final Logger logger = LoggerFactory.getLogger(SkillServiceImpl.class);

	@Autowired
	private SkillRepository repo;

    /**
     * Returns true when new skill is store in database
     * 
     * @param model - new skill data
     * @return - boolean
     */
	@Override
	public boolean save(SkillRequest model) {
		boolean flag = Boolean.FALSE;
		Skill entity = new Skill();
		 
		BeanUtils.copyProperties(model, entity);
		//setting values
		entity.setSkillSet(model.getSkillSet());
		entity.setDescription(model.getDescriptions());
		entity.setCreatedBy("abc");
		entity.setUpdatedBy("abc");
		Skill savedSkill = repo.save(entity);
		if(!Objects.isNull(savedSkill))
			flag = Boolean.TRUE;
		logger.debug("Skill Added into database :: " + entity);
		return flag;
	}

    /**
     * Returns true when existing skill data is store in database
     * 
     * @param model - new skill data
     * @param id - skill Id
     * @return - boolean
     */
	@Override
	public boolean updateSkill(SkillRequest model, BigInteger id) {
		boolean flag = Boolean.FALSE;
		Optional<Skill> findById = repo.findById(id);
		if (findById.isPresent()) {
			Skill oldSkill = findById.get();
			oldSkill.setSkillSet(model.getSkillSet());
			oldSkill.setDescription(model.getDescriptions());
			oldSkill.setCreatedBy("abc");
			oldSkill.setUpdatedBy("abc");
			Skill updated =repo.save(oldSkill);
			if(!Objects.isNull(updated))
				flag = Boolean.TRUE;
			logger.debug("Skill ID = " + id + " is updated in to database :: " + oldSkill);
			return flag;
		} else {
			logger.error("Skill is not available in to database with ID= " + id);
			return flag;
		}
	}

    /**
     * Returns Skill data when Skill data is available in database by id
     * @param id - skill Id
     * @return - SkillResponse
     */
	@Override
	public SkillResponse getById(BigInteger id) {
		Optional<Skill> optionalEntity = repo.findById(id);
		Skill skillEntity = optionalEntity.get();
		SkillResponse model = new SkillResponse();
		BeanUtils.copyProperties(skillEntity, model);
		logger.debug("Skill found with ID = " + id + " " + skillEntity);
		return model;
	}

    /**
     * Returns Skill data when Skill data is available in database by name
     * @param name - skillSet name
     * @return - DepartmentModel
     */
	@Override
	public SkillResponse getByName(String skillSet) {
		Skill findByName = repo.findByskillSet(skillSet);
		SkillResponse model = new SkillResponse();
		BeanUtils.copyProperties(findByName, model);
		logger.debug("Skill found with Name = " + skillSet + " " + findByName);
		return model;
	}

    /**
     * Returns All Skills data when skill data is available in database
     * @return - List of Skill
     */
	@Override
	public List<SkillResponse> getAllSkill() {
	
		List<Skill> skillEntity = repo.findAll();
		List<SkillResponse> models = skillEntity.stream().map(entity -> {
			SkillResponse model = new SkillResponse();
			BeanUtils.copyProperties(entity, model);
			return model;
		}).collect(Collectors.toList());

		return models;
	}

    /**
     * Returns true when skill data is deleted from database by id
     * @param id - skill id
     * @return - boolean
     */
	@Override
	public boolean deleteSkill(BigInteger id) {
		repo.deleteById(id);
		logger.debug(" Skill record is deleted from database ");
		return true;

	}
}