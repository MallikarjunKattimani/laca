package com.hrms.admin.service;

import java.util.Map;

import com.hrms.admin.model.BranchRequest;
import com.hrms.admin.response.BranchResponse;

public interface BranchService {
	
	public boolean save(BranchRequest branch);

	/* public List<BranchResponse> getAllBranch(); */

	public BranchResponse getById(Long id);

	public boolean deleteBranch(Long id);

	public boolean updateBranch(BranchRequest model, Long id);
	
	public Map<String, Object> getAllBranch(Integer pageNo, Integer pageSize, String sortBy);

}
