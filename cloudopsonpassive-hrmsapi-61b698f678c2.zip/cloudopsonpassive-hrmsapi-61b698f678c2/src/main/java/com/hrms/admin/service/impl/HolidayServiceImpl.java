package com.hrms.admin.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Holiday;
import com.hrms.admin.model.HolidayRequest;
import com.hrms.admin.repository.HolidayRepository;
import com.hrms.admin.response.HolidayResponse;
import com.hrms.admin.service.HolidayService;

@Service
public class HolidayServiceImpl implements HolidayService {

	private static Logger logger = LoggerFactory.getLogger(HolidayServiceImpl.class);

	@Autowired
	private HolidayRepository repo;

	/**
	 * Returns true when new holiday is store in database
	 * 
	 * @param model - new holiday data
	 * @return - boolean
	 */
	@Override
	public boolean save(HolidayRequest model) {
		boolean flag = Boolean.FALSE;
		Holiday entity = new Holiday();
		BeanUtils.copyProperties(model, entity);
		// setting values
		entity.setName(model.getName());
		entity.setDate(model.getDate());
		entity.setCreatedBy("abc");
		entity.setUpdatedBy("abc");
		Holiday h = repo.save(entity);
		if (!Objects.isNull(h))
			flag = Boolean.TRUE;
		logger.debug("holiday Added into database :: " + entity);
		return flag;
	}

	/**
	 * Returns true when existing holiday data is store in database
	 * 
	 * @param model - new holiday data
	 * @param id    - holiday Id
	 * @return - boolean
	 */
	@Override
	public boolean updateHoliday(HolidayRequest model, Long id) {
		boolean flag = Boolean.FALSE;
		Optional<Holiday> findById = repo.findById(id);
		if (findById.isPresent()) {
			Holiday oldHoliday = findById.get();
			oldHoliday.setName(model.getName());
			oldHoliday.setDate(model.getDate());
			oldHoliday.setCreatedBy("abc");
			oldHoliday.setUpdatedBy("abc");
			Holiday h = repo.save(oldHoliday);
			if (!Objects.isNull(h))
				flag = Boolean.TRUE;
			logger.debug("Holiday ID = " + id + " is updated in to database :: " + oldHoliday);
			return flag;
		} else {
			logger.error("Holiday is not available in to database with ID= " + id);
			return flag;
		}
	}

	/**
	 * Returns Holiday data when Holiday data is available in database by id
	 * 
	 * @param id - Holiday Id
	 * @return - HolidayModel
	 */
	@Override
	public HolidayResponse getById(Long id) {
		Optional<Holiday> optionalEntity = repo.findById(id);
		Holiday holidayEntity = optionalEntity.get();
		HolidayResponse model = new HolidayResponse();
		BeanUtils.copyProperties(holidayEntity, model);
		logger.debug("Holiday found with ID = " + id + " " + holidayEntity);
		return model;
	}

	/**
	 * Returns Holiday data when Holiday data is available in database by name
	 * 
	 * @param name - Holiday name
	 * @return - HolidayModel
	 */
	@Override
	public HolidayResponse getByName(String name) {
		Holiday findByHolidayName = repo.findByname(name);
		HolidayResponse model = new HolidayResponse();
		BeanUtils.copyProperties(findByHolidayName, model);
		logger.debug("Holiday found with Name = " + name + " " + findByHolidayName);
		return model;
	}

	/**
	 * Returns All Holiday data when Holiday data is available in database
	 * 
	 * @return - List of HolidayModel
	 */
	@Override
	public List<HolidayResponse> getAllHolidays() {
		logger.info("getAllHolidays() is called from HolidayServiceImpl class");
		List<Holiday> allHolidays = repo.findAll();
		List<HolidayResponse> models = allHolidays.stream().map(entity -> {
			HolidayResponse model = new HolidayResponse();
			BeanUtils.copyProperties(entity, model);
			return model;
		}).collect(Collectors.toList());

		return models;
	}

	/**
	 * Returns true when Holiday data is deleted from database by id
	 * 
	 * @param id - Holiday id
	 * @return - boolean
	 */
	@Override
	public boolean deleteHoliday(Long id) {
		repo.deleteById(id);
		logger.debug(" Holiday record is deleted from database ");
		return true;

	}


	

	/*
	 * // GET ONE
	 * 
	 * @Override public HolidayResponseModel getOneHoliday(Long holidayId) {
	 * logger.info("getOneHoliday() is called from HolidayServiceImpl class");
	 * Optional<HolidaysEntity> findById = repo.findById(holidayId);
	 * HolidayResponseModel holidays = new HolidayResponseModel(); if
	 * (findById.isPresent()) { HolidaysEntity entity = findById.get();
	 * BeanUtils.copyProperties(entity, holidays);
	 * logger.info("getOneHoliday() method is returning one Holidays"); return
	 * holidays; } logger.error("getOneHoliday() returning null value"); return
	 * null; }
	 */

	/*
	 * // DELETE
	 * 
	 * @Override public boolean deleteHoliday(Long holidayId) {
	 * logger.info("deleteHoliday() is called from HolidayServiceImpl class");
	 * repo.deleteById(holidayId);
	 * logger.info("deleteHoliday() is deleted one Holiday"); return true;
	 * 
	 * }
	 */

	/*
	 * // GET ALL
	 * 
	 * @Override public List<HolidayResponseModel> getAllHolidays() {
	 * logger.info("getAllHolidays() is called from HolidayServiceImpl class");
	 * List<HolidaysEntity> allHolidays = repo.findAll(); List<HolidayResponseModel>
	 * holidaytList = new ArrayList<>(); for (HolidaysEntity he : allHolidays) {
	 * HolidayResponseModel holidays = new HolidayResponseModel();
	 * BeanUtils.copyProperties(he, holidays); holidaytList.add(holidays); } return
	 * holidaytList; }
	 */

	/*
	 * @Override public List<HolidaysEntity> getAllHolidaysByPaging(Integer pageNo,
	 * Integer pageSize, String sortBy) {
	 * 
	 * Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));
	 * Page<HolidaysEntity> pagedResult = repo.findAll(paging); return
	 * pagedResult.getContent(); }
	 */
}
