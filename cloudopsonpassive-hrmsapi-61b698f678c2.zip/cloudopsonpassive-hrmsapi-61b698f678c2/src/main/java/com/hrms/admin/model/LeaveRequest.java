package com.hrms.admin.model;

import java.time.LocalDateTime;

public class LeaveRequest {

	private Long id;
	private String description;
	private String leaveType;
	private LocalDateTime createDate;
	private String createdBy;
	private LocalDateTime updateDate;
	private String updatedBy;
	
	public LeaveRequest() {
		super();
	}

	public LeaveRequest(Long id, String description, String leaveType, LocalDateTime createDate, String createdBy,
			LocalDateTime updateDate, String updatedBy) {
		super();
		this.id = id;
		this.description = description;
		this.leaveType = leaveType;
		this.createDate = createDate;
		this.createdBy = createdBy;
		this.updateDate = updateDate;
		this.updatedBy = updatedBy;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getLeaveType() {
		return leaveType;
	}

	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}

	public LocalDateTime getCreateDate() {
		return createDate;
	}

	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDateTime getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(LocalDateTime updateDate) {
		this.updateDate = updateDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	@Override
	public String toString() {
		return "LeaveRequest [id=" + id + ", description=" + description + ", leaveType=" + leaveType + ", createDate="
				+ createDate + ", createdBy=" + createdBy + ", updateDate=" + updateDate + ", updatedBy=" + updatedBy
				+ "]";
	}
	
	
	
}
