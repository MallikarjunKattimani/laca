package com.hrms.admin.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.hrms.admin.util.Constants;

@ControllerAdvice
@RestController
public class ResEntityExceptionHandler extends ResponseEntityExceptionHandler {

  @ExceptionHandler(Exception.class)
  public final ResponseEntity<Response> handleAllExceptions(Exception ex, WebRequest request) {
  return new ResponseEntity<Response>(new Response(ex.getMessage()+" "+Constants.INSERT_FAIL,Constants.FALSE), HttpStatus.BAD_REQUEST);
  }

  @ExceptionHandler(AttendanceNotFoundExceptions.class)
  public final ResponseEntity<Response> handleAttendancesNotFoundException(AttendanceNotFoundExceptions ex, WebRequest request) {
	  return new ResponseEntity<Response>(new Response(ex.getMessage()+" "+Constants.INSERT_FAIL,Constants.FALSE), HttpStatus.NOT_FOUND);
  }

  @ExceptionHandler(AttendanceNotCreatedExceptions.class)
  public final ResponseEntity<Response> handleAttendanceNotCreatedExceptions(AttendanceNotCreatedExceptions ex, WebRequest request) {
	  return new ResponseEntity<Response>(new Response(ex.getMessage()+" "+Constants.INSERT_FAIL,Constants.FALSE), HttpStatus.BAD_REQUEST);
  }
  
  @ExceptionHandler(CompanyNotFoundExceptions.class)
  public final ResponseEntity<Response> handleAttendancesNotFoundException(CompanyNotFoundExceptions ex, WebRequest request) {
	  return new ResponseEntity<Response>(new Response(ex.getMessage()+" "+Constants.INSERT_FAIL,Constants.FALSE), HttpStatus.NOT_FOUND);
  }

  @ExceptionHandler(CompanyNotCreatedExceptions.class)
  public final ResponseEntity<Response> handleAttendanceNotCreatedExceptions(CompanyNotCreatedExceptions ex, WebRequest request) {
	  return new ResponseEntity<Response>(new Response(ex.getMessage()+" "+Constants.INSERT_FAIL,Constants.FALSE), HttpStatus.BAD_REQUEST);
  }
}