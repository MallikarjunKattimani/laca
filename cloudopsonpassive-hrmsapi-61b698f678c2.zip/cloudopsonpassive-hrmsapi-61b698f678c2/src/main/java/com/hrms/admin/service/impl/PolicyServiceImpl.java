package com.hrms.admin.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Policy;
import com.hrms.admin.model.PolicyRequest;
import com.hrms.admin.response.PolicyResponse;
import com.hrms.admin.repository.PolicyRepository;
import com.hrms.admin.service.PolicyService;

/**
 * Contains method to perform DB operation on Department Record
 * 
 * @author {Suresh}
 *
 */
@Service
public class PolicyServiceImpl implements PolicyService {

	private static final Logger logger = LoggerFactory.getLogger(PolicyServiceImpl.class);

	@Autowired
	PolicyRepository policyRepository;

	/**
	 * Returns All Policy data when Policy data is available in database
	 * 
	 * @return - List of PolicyResponse
	 */
	@Override
	public List<PolicyResponse> getAllPolicy() {

		List<Policy> allPolicy = policyRepository.findAll();
		List<PolicyResponse> models = allPolicy.stream().map(entity -> {
			PolicyResponse model = new PolicyResponse();
			BeanUtils.copyProperties(entity, model);
			return model;
		}).collect(Collectors.toList());

		return models;

	}

	/**
	 * Returns true when new Policy is store in database
	 * 
	 * @param model - new Policy data
	 * @return - boolean
	 */
	@Override
	public boolean save(PolicyRequest model) {
		boolean flag = Boolean.FALSE;
		Policy entity = new Policy();
		BeanUtils.copyProperties(model, entity);
		// setting values
		entity.setName(model.getName());
		entity.setDescription(model.getDescription());
		entity.setCreatedBy("abc");
		entity.setUpdatedBy("abc");
		Policy d = policyRepository.save(entity);
		if (!Objects.isNull(d))
			flag = Boolean.TRUE;
		logger.debug("Policy Added into database :: " + entity);
		return flag;

	}

	/**
	 * Returns Policy data when Policy data is available in database by id
	 * 
	 * @param id - Id
	 * @return - PolicyResponse
	 */
	@Override
	public PolicyResponse getPolicyById(Long id) {
		Optional<Policy> optionalEntity = policyRepository.findById(id);
		Policy policyEntity = optionalEntity.get();
		PolicyResponse model = new PolicyResponse();
		BeanUtils.copyProperties(policyEntity, model);
		logger.debug("Policy found with ID = " + id + " " + policyEntity);
		return model;

	}

	/**
	 * Returns true when existing Policy data is store in database
	 * 
	 * @param model - new policy data
	 * @param id    - Policy Id
	 * @return - boolean
	 */
	@Override
	public boolean update(PolicyRequest policyModel, Long id) {
		boolean flag = Boolean.FALSE;
		Optional<Policy> findById = policyRepository.findById(id);
		if (findById.isPresent()) {
			Policy oldPolicy = findById.get();
			oldPolicy.setName(policyModel.getName());
			oldPolicy.setDescription(policyModel.getDescription());
			oldPolicy.setCreatedBy("abc");
			oldPolicy.setUpdatedBy("abc");

			Policy p = policyRepository.save(oldPolicy);
			if (!Objects.isNull(p))
				flag = Boolean.TRUE;
			logger.debug("Policy ID = " + id + " is updated in to database :: " + oldPolicy);
			return flag;
		} else {
			logger.error("Policy is not available in to database with ID= " + id);
			return flag;
		}
	}

	/**
	 * Returns true when department data is deleted from database by id
	 * 
	 * @param id - depatment id
	 * @return - boolean
	 */
	@Override
	public boolean deletePolicy(Long id) {
		policyRepository.deleteById(id);
		logger.debug(" Policy record is deleted from database ");
		return true;
	}

	/**
	 * Returns Policy data when Policy data is available in database by name
	 * 
	 * @param name - Policy name
	 * @return - PolicyResponse
	 */
	@Override
	public PolicyResponse getPolicyByName(String name) {
		Policy findByPolicyName = policyRepository.findByName(name);
		PolicyResponse model = new PolicyResponse();
		BeanUtils.copyProperties(findByPolicyName, model);
		logger.debug("Policy found with Name = " + name + " " + findByPolicyName);
		return model;
	}
}