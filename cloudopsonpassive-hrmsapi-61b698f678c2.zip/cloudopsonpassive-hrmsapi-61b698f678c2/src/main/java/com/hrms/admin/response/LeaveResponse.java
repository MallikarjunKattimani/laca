package com.hrms.admin.response;

public class LeaveResponse {

	private Long id;
	
	private String description;
	
	private String leaveType;
	
	public LeaveResponse() {
		super();
	}
	public LeaveResponse(Long id, String description, String leaveType) {
		super();
		this.id = id;
		this.description = description;
		this.leaveType = leaveType;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getLeaveType() {
		return leaveType;
	}
	public void setLeaveType(String leaveType) {
		this.leaveType = leaveType;
	}
	@Override
	public String toString() {
		return "LeaveResponseModel [id=" + id + ", description=" + description + ", leaveType=" + leaveType + "]";
	}
	
}