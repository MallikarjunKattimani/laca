package com.hrms.admin.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Leaves;
import com.hrms.admin.model.LeaveRequest;
import com.hrms.admin.repository.LeaveRepository;
import com.hrms.admin.response.LeaveResponse;
import com.hrms.admin.service.LeaveService;

@Service
public class LeaveServiceImpl implements LeaveService{
	
	private static final Logger logger = LoggerFactory.getLogger(LeaveServiceImpl.class);

	
	@Autowired
	private LeaveRepository repo; 
	
	@Override
	public boolean save(LeaveRequest model) {
		boolean flag = Boolean.FALSE;
		Leaves entity = new Leaves();
		BeanUtils.copyProperties(model, entity);
		//setting values
		entity.setLeaveType((model.getLeaveType()));
		entity.setDescription((model.getDescription()));
		entity.setCreatedBy("abc");
		entity.setUpdatedBy("abc");
		Leaves d=repo.save(entity);
		if(!Objects.isNull(d)) 
			flag = Boolean.TRUE;
		logger.debug("Leave Added into database :: " + entity);
		return flag;
	}


	 /**
     * Returns true when existing leave data is store in database
     * 
     * @param model - new leave data
     * @param id - leave Id
     * @return - boolean
     */
	
	 /**
     * Returns All Leave data when Leave data is available in database
     * @return - List of LeaveresponseModel
     */
	@Override
	public List<LeaveResponse> getAllLeave() {
	
		List<Leaves> allLeave = repo.findAll();
		List<LeaveResponse> models = allLeave.stream().map(entity -> {
			LeaveResponse model = new LeaveResponse();
			BeanUtils.copyProperties(entity, model);
			return model;
		}).collect(Collectors.toList());

		return models;
	}
	 /**
     * Returns Leave data when branch data is available in database by id
     * @param id - Leave Id
     * @return - LeaveResponseModel
     */
	@Override
	public LeaveResponse getById(Long id) {
		Optional<Leaves> optionalEntity = repo.findById(id);
		Leaves leaveEntity = optionalEntity.get();
		LeaveResponse model = new LeaveResponse();
		BeanUtils.copyProperties(leaveEntity, model);
		logger.debug("Leave found with ID = " + id + " " + leaveEntity);
		return model;
	}
	
	  /**
     * Returns true when leave data is deleted from database by id
     * @param id - leave id
     * @return - boolean
     */
	@Override
	public boolean deleteLeave(Long id) {
		repo.deleteById(id);
		logger.debug(" Leave record is deleted from database ");
		return true;

	}
	
	 /**
    * Returns true when existing Leave data is store in database
    * 
    * @param model - new Leave data
    * @param id - Leave Id
    * @return - boolean
    */
	@Override
	public boolean updateLeave(LeaveRequest model, Long id) {
		boolean flag = Boolean.FALSE;
		Optional<Leaves> findById = repo.findById(id);
		if (findById.isPresent()) {
			Leaves oldLeave = findById.get();
			oldLeave.setLeaveType((model.getLeaveType()));
			oldLeave.setDescription(model.getDescription());
			oldLeave.setCreatedBy("abc");
			oldLeave.setUpdatedBy("abc");
			Leaves d =repo.save(oldLeave);
			if(!Objects.isNull(d))
				flag = Boolean.TRUE;
			logger.debug("Leave ID = " + id + " is updated in to database :: " + oldLeave);
			return flag;
		} else {
			logger.error("Leave is not available in to database with ID= " + id);
			return flag;
		}

}
}