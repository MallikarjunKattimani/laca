package com.hrms.admin.controller;

import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.entity.Project;
import com.hrms.admin.exceptions.ProjectNotFoundExceptions;
import com.hrms.admin.exceptions.Response;
import com.hrms.admin.model.ProjectPagination;
import com.hrms.admin.model.ProjectRequest;
import com.hrms.admin.response.ProjectResponse;
import com.hrms.admin.service.ProjectService;
import com.hrms.admin.util.Constants;

/**
 * Contains method to provide APIs for Project Record
 * 
 * @author {MD Atif}
 *
 */

@RestController
@CrossOrigin
@RequestMapping("/admin/project")
public class ProjectController {

	private static final Logger logger = LoggerFactory.getLogger(ProjectController.class);

	@Autowired
	private ProjectService service;

	/**
	 * Returns status code when new project is created
	 * 
	 * @param model - new project data
	 * @return - ResponseEntity
	 */

	@PostMapping
	public ResponseEntity<Response> add(@RequestBody ProjectRequest model) {

		try {
			service.save(model);
			logger.debug("project Added :: " + model);
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.INSERT_SUCCESS, Constants.TRUE), HttpStatus.CREATED);

		} catch (Exception e) {
			logger.error("Error while adding Project :: ", e);
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}

	/**
	 * Returns All project data when project data is available
	 * 
	 * @return - List of project
	 */
	@GetMapping
	public List<ProjectResponse> getAllProjects() {
		List<ProjectResponse> allProject = service.getAllProject();
		if (allProject != null) {
			logger.debug("Found " + allProject.size() + " Project");
			return allProject;
		}
		logger.error("error while getting all Project Record");
		throw new ProjectNotFoundExceptions("Project not found");
	}

	/**
	 * Returns Project and status code when project data is available by id
	 * 
	 * @param id - project Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<ProjectResponse> getById(@PathVariable Long id) {
		
		try {

			ProjectResponse projectById = service.getById(id);
			logger.debug("project find with ID = " + id + " " + projectById);
			return new ResponseEntity<ProjectResponse>(projectById, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Project by Id :: " + id);
			throw new ProjectNotFoundExceptions("Project");
		}

	}
	/**
	 * Returns project data and status code when project data is available by
	 * name
	 * 
	 * @param name - Project name
	 * @return - ResponseEntity
	 */
	@GetMapping("/name/{name}")
	public ResponseEntity<ProjectResponse> getByName(@PathVariable String name) {

		try {
			ProjectResponse projectByName = service.getByName(name);
			logger.debug("Project found with Name = " + name + " " + projectByName);
			return new ResponseEntity<ProjectResponse>(projectByName, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Project by name :: " + name);
			throw new ProjectNotFoundExceptions("Project not found");
		}

	}

	/**
	 * Returns status code when project data is deleted
	 * 
	 * @param id - project id
	 * @return - ResponseEntity
	 */

	@DeleteMapping("/{id}")
	public ResponseEntity<Response> deleteProject(@PathVariable Long id) {

		ProjectResponse project = service.getById(id);
		if(!Objects.isNull(project)) {
			service.deleteProject(id);
			logger.debug("Project record is Deleted with id " + id);
			return new ResponseEntity<Response>(new Response(project.getName()+" "+Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		}else {
			logger.debug("Project not exist ");
			return new ResponseEntity<Response>(new Response("Project " +" "+Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.NO_CONTENT);
		}
	}

	/**
	 * Returns status code when existing project data is updated
	 * 
	 * @param model - new project data
	 * @param id    - project Id
	 * @return - ResponseEntity
	 */
	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody ProjectRequest model, @PathVariable Long id) {
			boolean updateProject = service.updateProject(model, id);
			if (updateProject) {
				logger.debug("Project ID = " + id + " is updated :: " + model);
				return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);
			} else {
				logger.error("Error while updating Project :: ");
				return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
			}
	}

	// Pagination
	@PostMapping("/paging")
	public ResponseEntity<List<Project>> getAllProjectByPaging(@RequestBody ProjectPagination page) {
		
		int pageNo = page.getPageNo();
		int pageSize = page.getPageSize();
		String sortBy = page.getSortBy();
		List<Project> list = service.getAllProjectAccToPaging(pageNo, pageSize, sortBy);

		return new ResponseEntity<List<Project>>(list, new HttpHeaders(), HttpStatus.OK);
	}

}
