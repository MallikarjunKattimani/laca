package com.hrms.admin.controller;

import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.exceptions.LeaveNotFoundException;
import com.hrms.admin.exceptions.Response;
import com.hrms.admin.model.LeaveRequest;
import com.hrms.admin.response.BranchResponse;
import com.hrms.admin.response.LeaveResponse;
import com.hrms.admin.service.LeaveService;
import com.hrms.admin.util.Constants;

@RestController
@CrossOrigin
@RequestMapping("/admin/leave")
public class LeaveController {

	private static final Logger logger = LoggerFactory.getLogger(LeaveController.class);
	
	@Autowired
	private LeaveService service;	

	/**
	 * Returns status code when new leave is created
	 * 
	 * @param model - new leave data
	 * @return - ResponseEntity
	 */

	@PostMapping
	public ResponseEntity<Response> add(@RequestBody LeaveRequest model) {
		try {
			service.save(model);
			logger.debug("Leave Added :: " + model);
			return new ResponseEntity<Response>(
					new Response("Leave " + " " + Constants.INSERT_SUCCESS, Constants.TRUE), HttpStatus.CREATED);

		} catch (Exception e) {
			logger.error("Error while adding Leave :: ", e);
			return new ResponseEntity<Response>(new Response("Leave " + " " + Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}


	/**
	 * Returns All Leave data when Leave data is available
	 * 
	 * @return - List of LeaveResponseModel
	 */
	@GetMapping
	public List<LeaveResponse> getAll() {
		List<LeaveResponse> allLeave = service.getAllLeave();
		if (allLeave != null) {
			logger.debug("Found " + allLeave.size() + " Leave");
			return allLeave;
		}
		logger.error("error while getting all Leave Record");
		throw new LeaveNotFoundException("Leave not found");
	}

	/**
	 * Returns leave and status code when leave data is available by id
	 * 
	 * @param id - Leave Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<LeaveResponse> getById(@PathVariable Long id) {

		try {
			LeaveResponse leaveById = service.getById((id));
			logger.debug("Leave fond with ID = " + id + " " + leaveById);
			return new ResponseEntity<LeaveResponse>(leaveById, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Leave by Id :: " + id);
			throw new LeaveNotFoundException("Leave");
		}
	}

	/**
	 * Returns status code when existing leave data is updated
	 * 
	 * @param model - new leave data
	 * @param id    - leave Id
	 * @return - ResponseEntity
	 */
	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody LeaveRequest model, @PathVariable Long id) {

		boolean updateLeave = service.updateLeave(model, id);
		if (updateLeave) {
			logger.debug("Leave ID = " + id + " is updated :: " + model);
			return new ResponseEntity<Response>(
					new Response(model.getLeaveType() + " " + Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} else {
			logger.error("Error while updating Branch :: ");
			return new ResponseEntity<Response>(
					new Response(model.getLeaveType() + " " + Constants.UPDATE_FAIL, Constants.FALSE),
					HttpStatus.NOT_FOUND);
		}
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<Response> delete(@PathVariable Long id) {

		LeaveResponse branch = service.getById(id);
		if (!Objects.isNull(branch)) {
			service.deleteLeave(id);
			logger.debug("Leave record is Deleted with id " + id);
			return new ResponseEntity<Response>(
					new Response(branch.getLeaveType() + " " + Constants.DELETE_SUCCESS, Constants.TRUE),
					HttpStatus.OK);
		} else {
			logger.debug("Leave not exist ");
			return new ResponseEntity<Response>(new Response("Leave " + " " + Constants.DELETE_FAIL, Constants.FALSE),
					HttpStatus.NO_CONTENT);
		}

	}
}