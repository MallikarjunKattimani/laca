package com.hrms.admin.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Company;
import com.hrms.admin.model.CompanyRequest;
import com.hrms.admin.model.CompanyResponse;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.service.CompanyService;

/**
 * Contains method to perform DB operation on Department Record
 * 
 * @author {Chandu}
 *
 */
@Service
public class CompanyServiceImpl implements CompanyService {

	private static final Logger logger = LoggerFactory.getLogger(CompanyServiceImpl.class);

	@Autowired
	private CompanyRepository attRepo;
	/**
     * Returns true when new Attendance is store in database
     * 
     * @param model - new Attendance data
     * @return - boolean
     */

	@Override
	public boolean save(CompanyRequest model) {

		boolean flag = Boolean.FALSE;
		Company entity = new Company();
		BeanUtils.copyProperties(model, entity);
		//setting values
		entity.setId(model.getId());
		entity.setCompanyName(model.getCompanyName());
		entity.setDesignation(model.getDesignation());
		entity.setCreatedBy("abc");
		entity.setUpdatedBy("abc");
		Company a=attRepo.save(entity);
		if(!Objects.isNull(a)) 
			flag = Boolean.TRUE;
		logger.debug("Attendance Added into database :: " + entity);
		return flag;
	}

	
	@Override
	public Map<String, Object> getAllCompany(Integer pageIndex, Integer pageSize, String sortBy) {
		
		/*
		 * List<Company> allCompany = attRepo.findAll(); List<CompanyResponse> models =
		 * allCompany.stream().map(entity -> { CompanyResponse model = new
		 * CompanyResponse(); BeanUtils.copyProperties(entity, model); return model;
		 * }).collect(Collectors.toList());
		 * 
		 * return models;
		 */
		
		Pageable paging = PageRequest.of(pageIndex, pageSize, Sort.by(sortBy));

		Page<Company> pagedResult = attRepo.findAll(paging);

		if(pagedResult.hasContent()) {
			//return pagedResult.getContent();
			return mapData(pagedResult);
		} else {
			return new HashMap<String, Object>();
		}
	}

	/**
     * Returns Company data when Company data is available in database by id
     * @param id - Company Id
     * @return - CompanyModel
     */
	@Override
	public CompanyResponse getById(Long id) {
		Optional<Company> optionalEntity = attRepo.findById(id);
		Company companyEntity = optionalEntity.get();
		CompanyResponse model = new CompanyResponse();
		BeanUtils.copyProperties(companyEntity, model);
		logger.debug("Attendance found with ID = " + id + " " + companyEntity);
		return model;
	}

	@Override
	public boolean deleteCompany(Long id) {
		attRepo.deleteById(id);
		logger.debug(" Company record is deleted from database ");
		return true;
	}

	 /**
     * Returns true when existing Company data is store in database
     * 
     * @param model - new Company data
     * @param id - Company Id
     * @return - boolean
     */
	@Override
	public boolean updateCompany(CompanyRequest model, Long id) {
		boolean flag = Boolean.FALSE;
		Optional<Company> findById = attRepo.findById(id);
		if (findById.isPresent()) {
			Company oldCompany = findById.get();
			oldCompany.setId(model.getId());
			oldCompany.setCompanyName(model.getCompanyName());
			oldCompany.setDesignation((model.getDesignation()));
			oldCompany.setCreatedBy("abc");
			oldCompany.setUpdatedBy("abc");
			Company a =attRepo.save(oldCompany);
			if(!Objects.isNull(a))
				flag = Boolean.TRUE;
			logger.debug("Company ID = " + id + " is updated in to database :: " + oldCompany);
			return flag;
		} else {
			logger.error("Company is not available in to database with ID= " + id);
			return flag;
		}
	}
	
	public static Map<String, Object> mapData(Page<Company> pagedResult){

		HashMap<String,Object> response = new HashMap<>();
		List<CompanyResponse> companyModels = pagedResult.stream().map(companyEntity -> { 
			CompanyResponse model =	new CompanyResponse(); BeanUtils.copyProperties(companyEntity, model);
			return	model;}).collect(Collectors.toList());

		response.put("data", companyModels);
		response.put("pageIndex", pagedResult.getNumber());
		response.put("totalRecords", pagedResult.getTotalElements());
		response.put("totalPages", pagedResult.getTotalPages());
		return response;
	}
}


