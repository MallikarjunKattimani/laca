package com.hrms.admin.controller;

import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.exceptions.PolicyNotFoundException;
import com.hrms.admin.exceptions.Response;
import com.hrms.admin.model.PolicyRequest;
import com.hrms.admin.response.PolicyResponse;
import com.hrms.admin.service.PolicyService;
import com.hrms.admin.util.Constants;

/**
 * Contains method to provide APIs for Policy Record
 * 
 * @author {Suresh}
 *
 */
@RestController
@CrossOrigin
@RequestMapping("/admin/policy")
public class PolicyController {

	private static final Logger logger = LoggerFactory.getLogger(PolicyController.class);

	@Autowired
	PolicyService policyService;

	/**
	 * Returns status code when new Policy is created
	 * 
	 * @param model - new policy data
	 * @return - ResponseEntity
	 */
	@PostMapping
	public ResponseEntity<Response> add(@RequestBody PolicyRequest model) {
		try {
			policyService.save(model);
			logger.info("Policy Added :: " + model);
			return new ResponseEntity<Response>(
					new Response("Policy " + " " + Constants.INSERT_SUCCESS, Constants.TRUE), HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error(" new Policy not created");
			return new ResponseEntity<Response>(new Response("Policy " + " " + Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.CREATED);
		}
	}

	/**
	 * Returns All Policy data when policy data is available
	 * 
	 * @return - List of Policy
	 */
	@GetMapping
	public List<PolicyResponse> getAll() {

		List<PolicyResponse> allPolicy = policyService.getAllPolicy();
		if (allPolicy != null) {
			logger.debug("Found " + allPolicy.size() + " Policy");
			return allPolicy;
		}
		logger.error("error while getting all Policy Record");
		throw new PolicyNotFoundException("Policy Not Found");

	}

	/**
	 * Returns Policy and status code when policy data is available by id
	 * 
	 * @param id - Policy Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<PolicyResponse> getById(@PathVariable Long id) {
		try {
			PolicyResponse policyById = policyService.getPolicyById(id);
			logger.debug("Policy fond with ID = " + id + " " + policyById);
			return new ResponseEntity<PolicyResponse>(policyById, HttpStatus.OK);

		} catch (Exception e) {
			logger.error("Error while getting Policy by Id :: " + id);
			throw new PolicyNotFoundException("Policy");
		}

	}

	/**
	 * Returns status code when existing Policy data is updated
	 * 
	 * @param model - new Policy data
	 * @param id    - Policy Id
	 * @return - ResponseEntity
	 */
	@PutMapping(path = "/{id}")
	public ResponseEntity<Response> update(@RequestBody PolicyRequest model, @PathVariable Long id) {
		boolean updatePolicy = policyService.update(model, id);
		if (updatePolicy) {
			logger.debug("Policy ID = " + id + " is updated :: " + model);
			return new ResponseEntity<Response>(
					new Response("Policy " + " " + Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.CREATED);

		} else {
			logger.error("Error while updating Policy :: ");
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * Returns Policy data and status code when policy data is available by name
	 * 
	 * @param name - policy name
	 * @return - ResponseEntity
	 */
	@GetMapping("/name/{name}")
	public ResponseEntity<PolicyResponse> getByName(@PathVariable String name) {

		try {
			PolicyResponse policyByName = policyService.getPolicyByName(name);
			logger.debug("Policy fond with Name = " + name + " " + policyByName);
			return new ResponseEntity<PolicyResponse>(policyByName, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Policy by name :: " + name);
			throw new PolicyNotFoundException("policy not found");
		}

	}

	/**
	 * Returns status code when policy data is deleted
	 * 
	 * @param id - policy id
	 * @return - ResponseEntity
	 */
	@DeleteMapping(path = "/{id}")
	public ResponseEntity<Response> deletePolicy(@PathVariable Long id) {
		PolicyResponse policy = policyService.getPolicyById(id);
		if (!Objects.isNull(policy)) {
			policyService.deletePolicy(id);
			logger.debug("Policy record is Deleted with id " + id);
			return new ResponseEntity<Response>(
					new Response(policy.getName() + " " + Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} else {
			logger.debug("Policy not exist ");
			return new ResponseEntity<Response>(new Response("Policy " + " " + Constants.DELETE_FAIL, Constants.FALSE),
					HttpStatus.NO_CONTENT);
		}
	}

}
