package com.hrms.admin.response;

public class AttendanceResponse {
	private Long id;
	private String companyName;
	private String branchName;
	private String inTime;
	private String outTime;
	public AttendanceResponse() {
		super();
	}
	public AttendanceResponse(Long id, String companyName, String branchName, String inTime, String outTime) {
		super();
		this.id = id;
		this.companyName = companyName;
		this.branchName = branchName;
		this.inTime = inTime;
		this.outTime = outTime;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getInTime() {
		return inTime;
	}
	public void setInTime(String inTime) {
		this.inTime = inTime;
	}
	public String getOutTime() {
		return outTime;
	}
	public void setOutTime(String outTime) {
		this.outTime = outTime;
	}
	@Override
	public String toString() {
		return "AttendanceResponse [id=" + id + ", companyName=" + companyName + ", branchName=" + branchName
				+ ", inTime=" + inTime + ", outTime=" + outTime + "]";
	}
	
	
	
}
