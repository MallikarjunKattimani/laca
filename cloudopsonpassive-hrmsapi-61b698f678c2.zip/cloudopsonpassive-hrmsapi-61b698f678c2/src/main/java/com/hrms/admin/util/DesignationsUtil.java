package com.hrms.admin.util;

import com.hrms.admin.response.DesignationResponse;

public class DesignationsUtil {

	public static void copyNonNullValues(DesignationResponse req, DesignationResponse db) {

		if (req.getDesignation() != null) {
			db.setDesignation(req.getDesignation());
		}
		if (req.getSkills() != null) {
			db.setSkills(req.getSkills());
		}
		if (req.getExperiance() != 0) {
			db.setExperiance(req.getExperiance());
		}

	}
}
