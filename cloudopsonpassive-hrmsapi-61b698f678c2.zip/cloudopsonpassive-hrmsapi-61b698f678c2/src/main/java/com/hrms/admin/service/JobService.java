package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.model.JobRequest;
import com.hrms.admin.response.JobResponse;

public interface JobService {
	
	
	public boolean save(JobRequest model);

	public List<JobResponse> getAllJob();

	public JobResponse getById(Long id);
	
	

	public boolean deleteJob(Long id);

	public boolean updateJob(JobRequest model, Long id);
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

//	/**
//	 * Takes Reg Form data as input and returns job generated
//	 */
//	Long saveJobEntity(Job cmp);
//	
//	/**
//	 * Takes Edit Form data as input and returns job generated
//	 */
//	//void updateCompany(Integer id);
//	void updateJobEntity(Job cmp);
//	
//	/**
//	 * Takes job(ID) as input and perform delete operation
//	 */
//	void deleteJobEntity(Long id);
//	
//	
//	/**
//	 * Provide id as input and returns one row as one object
//	 */
//	Job getOneJobEntity(Long id);
//	
//	/**
//	@Override
//	 * select all rows and give as List<Job>
//	 */
//	List<Job> getAllJobEntity();
//
//	

	

}
