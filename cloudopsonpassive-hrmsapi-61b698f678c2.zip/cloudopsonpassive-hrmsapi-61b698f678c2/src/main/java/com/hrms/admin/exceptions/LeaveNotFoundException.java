package com.hrms.admin.exceptions;

public class LeaveNotFoundException extends RuntimeException{
	
	public LeaveNotFoundException() {
		super();
	}
		public LeaveNotFoundException(String message) {
			super(message);

		}
}
	
	


