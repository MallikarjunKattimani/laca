package com.hrms.admin.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Attendance;
import com.hrms.admin.model.AttendanceRequest;
import com.hrms.admin.model.AttendanceResponse;
import com.hrms.admin.repository.AttendancesRepository;
import com.hrms.admin.service.AttendanceService;

/**
 * Contains method to perform DB operation on Department Record
 * 
 * @author {Chandu}
 *
 */
@Service
public class AttendancesServiceImpl implements AttendanceService {

	private static final Logger logger = LoggerFactory.getLogger(AttendancesServiceImpl.class);

	@Autowired
	private AttendancesRepository attRepo;
	/**
     * Returns true when new Attendance is store in database
     * 
     * @param model - new Attendance data
     * @return - boolean
     */

	@Override
	public boolean save(AttendanceRequest model) {

		boolean flag = Boolean.FALSE;
		Attendance entity = new Attendance();
		BeanUtils.copyProperties(model, entity);
		//setting values
		entity.setCompanyName(model.getCompanyName());
		entity.setBranch(model.getBranch());
		entity.setInTime(model.getInTime());
		entity.setOutTime(model.getOutTime());
		entity.setCreatedBy("abc");
		entity.setUpdatedBy("abc");
		Attendance a=attRepo.save(entity);
		if(!Objects.isNull(a)) 
			flag = Boolean.TRUE;
		logger.debug("Attendance Added into database :: " + entity);
		return flag;
	}

	
	@Override
	public List<AttendanceResponse> getAllAttendnace() {
		List<Attendance> allAttendance = attRepo.findAll();
		List<AttendanceResponse> models = allAttendance.stream().map(entity -> {
			AttendanceResponse model = new AttendanceResponse();
			BeanUtils.copyProperties(entity, model);
			return model;
		}).collect(Collectors.toList());

		return models;
	}

	/**
     * Returns Attendance data when Attendance data is available in database by id
     * @param id - Attendance Id
     * @return - AttendanceModel
     */
	@Override
	public AttendanceResponse getById(Long id) {
		Optional<Attendance> optionalEntity = attRepo.findById(id);
		Attendance attendanceEntity = optionalEntity.get();
		AttendanceResponse model = new AttendanceResponse();
		BeanUtils.copyProperties(attendanceEntity, model);
		logger.debug("Attendance found with ID = " + id + " " + attendanceEntity);
		return model;
	}

	@Override
	public boolean deleteAttendnace(Long id) {
		attRepo.deleteById(id);
		logger.debug(" Attendnace record is deleted from database ");
		return true;
	}

	 /**
     * Returns true when existing Attendance data is store in database
     * 
     * @param model - new Attendance data
     * @param id - Attendance Id
     * @return - boolean
     */
	@Override
	public boolean updateAttendnace(AttendanceRequest model, Long id) {
		boolean flag = Boolean.FALSE;
		Optional<Attendance> findById = attRepo.findById(id);
		if (findById.isPresent()) {
			Attendance oldAttendance = findById.get();
			oldAttendance.setCompanyName(model.getCompanyName());
			oldAttendance.setBranch((model.getBranch()));
			oldAttendance.setInTime(model.getInTime());
			oldAttendance.setOutTime(model.getOutTime());
			oldAttendance.setCreatedBy("abc");
			oldAttendance.setUpdatedBy("abc");
			Attendance a =attRepo.save(oldAttendance);
			if(!Objects.isNull(a))
				flag = Boolean.TRUE;
			logger.debug("Attendance ID = " + id + " is updated in to database :: " + oldAttendance);
			return flag;
		} else {
			logger.error("Attendance is not available in to database with ID= " + id);
			return flag;
		}
	}



}


