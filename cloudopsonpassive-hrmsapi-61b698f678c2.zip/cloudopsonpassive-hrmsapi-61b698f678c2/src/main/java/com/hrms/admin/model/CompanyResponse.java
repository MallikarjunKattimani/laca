package com.hrms.admin.model;

public class CompanyResponse {
	private Long id;
	private String companyName;
	private String designation;
	
	public CompanyResponse() {
	}
	public CompanyResponse(Long id, String companyName, String designation) {
		
		this.id = id;
		this.companyName = companyName;
		this.designation = designation;
		
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	@Override
	public String toString() {
		return "CompanyResponse [id=" + id + ", companyName=" + companyName + ", designation=" + designation + "]";
	}
	
	
		
	
	
}
