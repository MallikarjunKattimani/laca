package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.model.LeaveRequest;
import com.hrms.admin.response.LeaveResponse;

public interface LeaveService {
	
	public boolean save(LeaveRequest branch);

	public List<LeaveResponse> getAllLeave();

	public LeaveResponse getById(Long id);

	public boolean deleteLeave(Long id);

	public boolean updateLeave(LeaveRequest model, Long id);

}


