package com.hrms.admin.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Job;
import com.hrms.admin.model.JobRequest;
import com.hrms.admin.repository.Jobrepository;
import com.hrms.admin.response.JobResponse;
import com.hrms.admin.service.JobService;


@Service
public class JobServiceImpl implements JobService {
	
	private static final Logger logger = LoggerFactory.getLogger(JobServiceImpl.class);

	@Autowired
	Jobrepository jobrepository;

	@Override
	public boolean save(JobRequest model) {

		boolean flag = Boolean.FALSE;
		Job entity = new Job();
		BeanUtils.copyProperties(model, entity);
		//setting values
		entity.setId(model.getId());
		entity.setName(model.getName());
		entity.setDescription(model.getDescription());
		entity.setExperiance(model.getExperiance());
		entity.setCreatedBy("abc");
		entity.setUpdatedBy("abc");
		Job j =jobrepository.save(entity);
		if(!Objects.isNull(j)) 
			flag = Boolean.TRUE;
		logger.debug("Job Added into database :: " + entity);
	
		return flag;	
	}



	public List<JobResponse> getAllJob() {
		
		List<Job> allJob = jobrepository.findAll();
		List<JobResponse> models = allJob.stream().map(entity -> {
			JobResponse model = new JobResponse();
			BeanUtils.copyProperties(entity, model);
			return model;
		}).collect(Collectors.toList());

		return models;
	}
	
	@Override
	public JobResponse getById(Long id) {

		Optional<Job> optionalEntity = jobrepository.findById(id);
	Job jobEntity = optionalEntity.get();
		JobResponse model = new JobResponse();
		BeanUtils.copyProperties(jobEntity, model);
		logger.debug("Job found with ID = " + id + " " + jobEntity);
		return model;	
		
		
	}

	

	@Override
	public boolean deleteJob(Long id) {
		jobrepository.deleteById(id);
		logger.debug(" Job record is deleted from database ");
		return true;		
	}

	public boolean updateJob(JobRequest model, Long id) {

		boolean flag = Boolean.FALSE;
		Optional<Job> findById = jobrepository.findById(id);
		if (findById.isPresent()) {
			Job oldJob = findById.get();
			oldJob.setName(model.getName());
			oldJob.setDescription(model.getDescription());
			oldJob.setExperiance(model.getExperiance());
		
			oldJob.setCreatedBy("abc");
			oldJob.setUpdatedBy("abc");
			Job j =jobrepository.save(oldJob);
			if(!Objects.isNull(j))
				flag = Boolean.TRUE;
			logger.debug("Job ID = " + id + " is updated in to database :: " + oldJob);
			return flag;
		} else {
			logger.error("Job is not available in to database with ID= " + id);
			return flag;
		
	}
	
	
	}
}

	
	
	
	
	
	
	
	
	

	
	

