package com.hrms.admin.response;

import java.math.BigInteger;

public class SkillResponse {
	
	private BigInteger id;
	private String skillSet;
	private String description;
	
	public SkillResponse() {
	}

	public BigInteger getId() {
		return id;
	}

	public void setId(BigInteger id) {
		this.id = id;
	}

	public String getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}

	public String getdescription() {
		return description;
	}

	public void setdescription(String description) {
		this.description = description;
	}
	
	
	

}
