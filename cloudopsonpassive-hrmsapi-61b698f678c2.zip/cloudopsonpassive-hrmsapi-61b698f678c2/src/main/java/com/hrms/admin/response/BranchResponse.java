package com.hrms.admin.response;

import java.time.LocalDateTime;

public class BranchResponse {
	
	private Long id;
	private String name;
	private String description;
	private String location;
	private LocalDateTime createDate;
	private String createdBy;
	private LocalDateTime updateDate;
	private String updatedBy;
	public BranchResponse() {
		super();
	}
	public BranchResponse(Long id, String name, String description, String location, LocalDateTime createDate,
			String createdBy, LocalDateTime updateDate, String updatedBy) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.location = location;
		this.createDate = createDate;
		this.createdBy = createdBy;
		this.updateDate = updateDate;
		this.updatedBy = updatedBy;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public LocalDateTime getCreateDate() {
		return createDate;
	}
	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public LocalDateTime getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(LocalDateTime updateDate) {
		this.updateDate = updateDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	@Override
	public String toString() {
		return "BranchResponse [id=" + id + ", name=" + name + ", description=" + description + ", location=" + location
				+ ", createDate=" + createDate + ", createdBy=" + createdBy + ", updateDate=" + updateDate
				+ ", updatedBy=" + updatedBy + "]";
	}
	
}

