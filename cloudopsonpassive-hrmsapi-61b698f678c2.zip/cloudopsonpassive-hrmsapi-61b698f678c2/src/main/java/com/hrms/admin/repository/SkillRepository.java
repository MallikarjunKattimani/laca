package com.hrms.admin.repository;

import java.math.BigInteger;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.Skill;

public interface SkillRepository extends JpaRepository<Skill, BigInteger> {
	
	public Skill findByskillSet(String skilset);
	public Page<Skill> findAll(Pageable paging);

}
