package com.hrms.admin.service;

import java.util.Map;

import com.hrms.admin.model.CompanyRequest;
import com.hrms.admin.model.CompanyResponse;

public interface CompanyService {
	
	
	public boolean save(CompanyRequest model);

//	public List<CompanyResponse> getAllCompany();

	public CompanyResponse getById(Long id);

	public boolean deleteCompany(Long id);

	public boolean updateCompany(CompanyRequest model, Long id);
	
	public Map<String, Object> getAllCompany(Integer pageNo, Integer pageSize, String sortBy);
	
}
