package com.hrms.admin.service;

import java.math.BigInteger;
import java.util.List;

import com.hrms.admin.model.DepartmentRequest;
import com.hrms.admin.response.DepartmentResponse;

public interface DepartmentService {

	public boolean save(DepartmentRequest model);

	public List<DepartmentResponse> getAllDepartment();

	public DepartmentResponse getById(BigInteger id);
	
	public DepartmentResponse getByName(String name);

	public boolean deleteDepartment(BigInteger id);

	public boolean updateDepartment(DepartmentRequest model, BigInteger id);

}
