import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DataRoutingModule } from './data-routing.module';
import { DataListComponent } from './data-list/data-list.component';


@NgModule({
  declarations: [DataListComponent],
  imports: [
    CommonModule,
    DataRoutingModule
  ]
})
export class DataModule { }
