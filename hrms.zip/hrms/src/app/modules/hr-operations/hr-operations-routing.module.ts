import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DataModule } from './data/data.module';

const routes: Routes = [
  {
    path:'branch',
    loadChildren: () => import('./branch/branch.module').then(m => m.BranchModule)
  },
  {
    path:'company',
    loadChildren: () => import('./company/company.module').then(m => m.CompanyModule)
  },
  {
    path:'department',
    loadChildren: () => import('./department/department.module').then(m => m.DepartmentModule)
  },
  {
    path:'designation',
    loadChildren: () => import('./designation/designation.module').then(m => m.DesignationModule)
  },
  {
    path:'holidays',
    loadChildren: () => import('./holidays/holidays.module').then(m => m.HolidaysModule)
  },
  {
    path:'leave-plan',
    loadChildren: () => import('./leave-plan/leave-plan.module').then(m => m.LeavePlanModule)
  },
  {
    path:'notification',
    loadChildren: () => import('./notification/notification.module').then(m => m.NotificationModule)
  },
  {
    path:'data', 
    loadChildren:()=>import('./data/data.module').then(m=>m.DataModule)
    //loadChildren: ()=>import('./data/data.module').then(m=>m.DataModule)
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HrOperationsRoutingModule { }
