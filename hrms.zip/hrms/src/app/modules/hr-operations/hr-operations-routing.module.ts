import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DepartmentsModule } from '../../pages/departments/departments.module';
//import { EmployeesModule } from 'src/app/pages/employees/employees.module';

const routes: Routes = [
  {
    path: 'company',
    loadChildren: () => import('./company/company.module').then(m => m.CompanyModule)
  },
  { path: 'holidays', loadChildren: () => import('../../pages/holidays/holidays.module').then(m => m.HolidaysModule) },
  {
    path: 'department',
    loadChildren: () => DepartmentsModule
  },
  {
    path: 'employee',
    loadChildren:() => import('../../pages/employees/employees.module').then(m => m.EmployeesModule) 
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HrOperationsRoutingModule { }
