import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LeavePlanListComponent } from './leave-plan-list/leave-plan-list.component';
import { LeavePlanRoutingModule } from './leave-plan-routing.module';



@NgModule({
  declarations: [LeavePlanListComponent],
  imports: [
    CommonModule,
    LeavePlanRoutingModule
  ]
})
export class LeavePlanModule { }
