import { HttpParams } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ModalDismissReasons, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { LeavePolicyService } from 'src/app/services/hr-operations/leave-policy.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-leave-plan-list',
  templateUrl: './leave-plan-list.component.html',
  styleUrls: ['./leave-plan-list.component.css']
})
export class LeavePlanListComponent implements OnInit {

  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['policyName', 'policyDescription', 'action'];
  policyList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  policyForm: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  closeResult: any;
  deletePolicy: any;
  modalHeader: string = '';
  submitted: boolean = false;
  @ViewChild('closeModal', { static: true }) closeModal: ElementRef<HTMLElement>;

  constructor(private _service: LeavePolicyService,
    public dialog: MatDialog,
    public _toast: ToasterService,
    private modalService: NgbModal) { }

  ngOnInit(): void {
    this.policyForm = new FormGroup({
      policyId: new FormControl(''),
      policyName: new FormControl('', [Validators.required]),
      policyDescription: new FormControl('', [Validators.required]),
    });
    this.getAllPolicys();
  }

  getAllPolicys(event?: any, sorting?: any) {
    var params = {};
    params['size'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['number'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortKey'] = (sorting) ? sorting.active : 'policyId'; // by Default id column will sorted
    params['sortOrder'] = (sorting) ? sorting.direction : 'asc'; // be default sorting will be in Ascending order

    this._service.getPolicyList(params).subscribe(
      data => {
        this.policyList = new MatTableDataSource(data);
        this.policyList.sort = this.sort;
        this.pageSize = params['size'];
      });
    console.log(this.filter, "----");
  }
  applyFilter(event) {
    this.getAllPolicys();
  }
  sortTable(event) {
    console.log(event);
    this.getAllPolicys(null, event);
  }
  getPolicyId() {
    if (this.policyForm.value.policyId)
      return this.policyForm.value.policyId;
    else return 0;
  }
  /** 
   * Create ot update policy
  */
  onSubmit() {    
    if (this.policyForm.valid) {
      this.submitted = true;
      if (this.getPolicyId() > 0) {
        // update API call
        var params = new HttpParams();
        params.set('id', this.getPolicyId());
        this._service.updatePolicy(this.policyForm.value, this.getPolicyId()).subscribe(data => {
          console.log(data);
        });
      } else {
        // create API call
        delete this.policyForm.value.policyId;
        this._service.savePolicy(this.policyForm.value).subscribe(data => {
          console.log(data);
        });
      }
      this.getAllPolicys();
      this.modalService.dismissAll();
    } else {
      this.submitted = false;
      this._toast.show('warn', "Please enter mandatory fields");
    }

  }

  open(content, type: boolean, policy?) {
    this.modalService
      .open(content, {
        ariaLabelledBy: "modal-basic-title",
        windowClass: "my-class"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
        }
      );
      this.policyForm.reset()
  }
  openDelete(deleteConfirm, policy?) {
    this.deletePolicy = policy;
    this.modalService
      .open(deleteConfirm, {
        ariaLabelledBy: "modal-basic-title"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
      );
  }

  onDeleteConfirmation() {
    this._service.deletePolicy(this.deletePolicy.policyId).subscribe(
      (data: any) => {
        this.getAllPolicys();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }

  // No need
   
}
