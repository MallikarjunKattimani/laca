import { HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DepartmentService } from 'src/app/services/hr-operations/department.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-department-list',
  templateUrl: './department-list.component.html',
  styleUrls: ['./department-list.component.css']
})
export class DepartmentListComponent implements OnInit {

  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['departmentName', 'departmentDescription', 'action'];
  departmentList = new MatTableDataSource();
  filter: any = {searchKey: ''};
  departmentForm : FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  closeResult : any;
  deleteDepartment : any;
  modalHeader:string = '';
  submitted : boolean = false;


  constructor(private _service:DepartmentService,
              public dialog: MatDialog,
              public _toast : ToasterService,
              private modalService: NgbModal) { }

  ngOnInit(): void {
    this.departmentForm = new FormGroup({
      departmentId : new FormControl(''),
      departmentName : new FormControl('', [Validators.required,Validators.pattern('[A-Za-z]{3,}'),Validators.minLength(3)]),
      departmentDescription : new FormControl('', [Validators.required,Validators.minLength(10)])
    });
    this.getAllDepartments(null, null);
  }

  getAllDepartments(event?: any, sorting?: any) {
    var params = {};
    params['size'] = (event) ? event.pageSize : this.pageSize;
    params['number'] = (event) ? event.pageIndex : this.pageIndex;
    params['searchKey'] = this.filter.searchKey;
    params['sortKey'] = (sorting) ? sorting.active : 'departmentId';
    params['sortOrder'] = (sorting) ? sorting.direction : 'asc';

    this._service.getDepartmentList(params).subscribe(
      data => {
        this.departmentList = new MatTableDataSource(data);
        this.departmentList.sort = this.sort;
        this.pageSize = params['size'];
      },
      error => {

      });
    console.log(this.filter, "----");
  }
  applyFilter(event) {
    var filterValue = (event.target as HTMLInputElement).value;
    this.getAllDepartments(null, null);
  }
  sortTable(event) {
    console.log(event);
    this.getAllDepartments(null, event);
  }
  getDepartmentId(){
    if(this.departmentForm.value.departmentId)
      return this.departmentForm.value.departmentId;
    else return 0;
  }
  /** 
   * Create ot update department 
  */
  onSubmit(){
    this.dialog.closeAll();
    if(this.departmentForm.valid){
      this.submitted = true;
      if(this.getDepartmentId()>0){
        // update API call
        var params = new HttpParams();
        params.set('id',this.getDepartmentId());
        this._service.updateDepartment(this.departmentForm.value,this.getDepartmentId()).subscribe(data => {
          console.log(data);
        });
      }else{
        // create API call
        delete this.departmentForm.value.departmentId;
        this._service.saveDepartment(this.departmentForm.value).subscribe(data => {
          console.log(data);
        });
      }
      this.getAllDepartments();
    }else{
      this.submitted = false;
      this._toast.show('warn',"Please enter mandatory fields");
    }
  }
  open(content, type: boolean, department?) {
    this.modalHeader = type ? "Create": "Update";
    this.departmentForm.reset();
    if (!type) {
      console.log("department--",department);
      this.departmentForm.patchValue(department, { onlySelf: true });
      /*this.departmentForm.setValue({
        departmentId : department.departmentId,
        name : department.departmentName,
        location : department.departmentLocation,
        description : department.departmentDescription
      });*/
    }
    this.modalService
      .open(content, {
        ariaLabelledBy: "modal-basic-title",
        windowClass: "my-class"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
        }
      );
  }
  openDelete(deleteConfirm, department?) {
    this.deleteDepartment = department;
    this.modalService
      .open(deleteConfirm, {
        ariaLabelledBy: "modal-basic-title"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  onDeleteConfirmation() {
    this._service.deleteDepartment(this.deleteDepartment.departmentId).subscribe(
      (data: any) => {
        this.getAllDepartments();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }
}
