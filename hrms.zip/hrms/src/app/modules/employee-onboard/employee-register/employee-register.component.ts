import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-employee-register',
  templateUrl: './employee-register.component.html',
  styleUrls: ['./employee-register.component.css']
})
export class EmployeeRegisterComponent implements OnInit, OnDestroy {

  genders = ['male', 'female', 'other']
  employeeForm: FormGroup
  imagePreview
  file
  fileChosen
  formate = ['png', 'jpg', 'txt', 'pdf']
  maxSize = 500000
  minSize = 10000
  employeeData = []
  constructor(private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.employeeForm = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.pattern("[+A-Za-z ]{3,15}")]),
      mobile: new FormControl('', [Validators.required, Validators.pattern("[0-9]{10,10}")]),
      email: new FormControl('', [Validators.required, Validators.email]),
      bloodGroup: new FormControl('', [Validators.required, Validators.pattern("[A-Z+-]{2,3}")]),
      designation: new FormControl('', [Validators.required, Validators.pattern("[+A-Za-z ]{3,25}")]),
      gender: new FormControl('', [Validators.required]),
      accountNo: new FormControl('', [Validators.required, Validators.pattern("[0-9]{3,25}")]),
      IFscCode: new FormControl('', [Validators.required, Validators.pattern("[A-Z0-9]{6,15}")]),
      attachments: new FormControl('', [Validators.required]),
    })
  }
  back() {
    this.router.navigate(['employee-onboard'])
    //  this.router.navigate(['../',{relativeTo:this.route}])
  }
  onAttachmentPicked(event: Event) {
    const file = (event.target as HTMLInputElement).files[0];
    //this.employeeForm.patchValue({ attachments: file });
    console.log(this.employeeForm)
    var ext = file.name.substring(file.name.lastIndexOf('.') + 1);
    console.log(ext)
    let i
    for (i = 0; i < this.formate.length; i++) {
      if (ext.toLowerCase() == this.formate[i]) {
        this.fileChosen = true
        break
      } else {
        this.fileChosen = false
        console.log('called')
      }
    }
    if ((this.fileChosen == true) && file.size < this.maxSize) {
      this.employeeForm.get("attachments").updateValueAndValidity();
      const reader = new FileReader();
      console.log(this.employeeForm.get("attachments"))

      console.log(file)
      this.file = file.name
     // console.log('sdfghjhgfdsasdfghn')
      reader.onload = () => {
        this.imagePreview = reader.result;
        //console.log(this.imagePreview)
      };
      reader.readAsDataURL(file);
    } else {
      this.employeeForm.get('attachments').reset()
      this.fileChosen = false
      this.file = null
    }
  }
  onSubmit() {
    if (this.employeeForm.valid) {
      this.employeeData.push(
        this.employeeForm.value)
      this.employeeForm.reset()
      this.file = null
      console.log('submit')
    }
  }
  ngOnDestroy() {
    this.fileChosen = null
    this.file = null
  }
}
