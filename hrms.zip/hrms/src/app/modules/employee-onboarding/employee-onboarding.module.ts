import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmployeeOnboardingRoutingModule } from './employee-onboarding-routing.module';
import { EmployeeComponent } from './employee/employee.component';
import { ResourceComponent } from './resource/resource.component';
import { ProjectComponent } from './project/project.component';
import { PolicyComponent } from './policy/policy.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from 'src/app/_helpers/material/material.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MaterialFileInputModule } from 'ngx-material-file-input';


@NgModule({
  declarations: [EmployeeComponent, ResourceComponent, ProjectComponent, PolicyComponent],
  imports: [
    CommonModule,
    EmployeeOnboardingRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    NgbModule,
     MaterialFileInputModule
  ]
})
export class EmployeeOnboardingModule { }
