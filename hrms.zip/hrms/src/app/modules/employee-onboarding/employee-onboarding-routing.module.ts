import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { resourceUsage } from 'process';
import { EmployeeComponent } from './employee/employee.component';
import { PolicyComponent } from './policy/policy.component';
import { ProjectComponent } from './project/project.component';
import { ResourceComponent } from './resource/resource.component';

const routes: Routes = [
  {path:'employee',
component:EmployeeComponent
},
{
  path:'policy',
  component:PolicyComponent
},
{
  path:'project',
  component:ProjectComponent
},
{
  path:'resource',
  component:ResourceComponent
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmployeeOnboardingRoutingModule { }
