import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  constructor(private _toaster: ToasterService,private toastr: ToastrService) { }

  ngOnInit(): void {
    /*
    this._toaster.show('success','Added Successfully');
    this._toaster.show('error','Something went wrong!!');
    this._toaster.show('info','This is information');
    this._toaster.show('warn','Please enter mandatory fields');
    */
  }
}
