import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders, } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs';
import { Department } from './department';
@Injectable({
  providedIn: 'root'
})
export class DepartmentService {

  private _url = 'api/departments'

  constructor(private http: HttpClient) { }

  private user: Department[] = [];
  private updateUser = new Subject<Department[]>();
  editDepartment: boolean
  departmentId

  addUser(name: string, description: string) {
    const user: Department = { id: null,name:name,description:description };
    return this.http.post<any>(this._url, user).subscribe((resp => {
      this.getUsers()
    }), error => {
      //this.errorHand(error);
      console.log(error)
    })
  }

  updateUserListener() {
    return this.updateUser.asObservable();
  }
  getUsers() {
    this.http
      .get<any>(
        this._url
      )
      .subscribe((transformedPosts => {
        this.user = transformedPosts;
        console.log(this.user)
        this.updateUser.next([...this.user]);
      }), error => {
        //this.errorHand(error);
        console.log(error)
      });
  }

  deleteUser(usersId) {
    this.http.delete(this._url + '/' + usersId)
      .subscribe((() => {
        this.getUsers()
      }), error => {
        //this.errorHand(error);
        console.log(error)
      });
  }
  editUser(post: any) {
    console.log(this.departmentId)
    const user1:Department = { id: this.departmentId, name:post.name,description:post.description }
    console.log(user1);
    this.http.put(this._url + '/' + this.departmentId, user1).subscribe((res => {
      this.getUsers()
    }), error => {
     // this.errorHand(error);
      console.log(error)
    })
  }
}
