import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { DepartmentService } from '../department.service';
import { NotificationService } from 'src/app/services/notification.service';
import { Department } from '../department';
import { Subscription } from 'rxjs';
import { AddComponent } from '../add/add.component';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent implements OnInit {

  closeResult: string;
  departments:Department[] = []
  userSub: Subscription;
  id

  constructor(private userS:DepartmentService, private dialog: MatDialog,
    private notificationService :NotificationService) { }

  ngOnInit() {
    this.userS.getUsers();
    this.userSub = this.userS.updateUserListener().subscribe((user: Department[]) => {
      this.departments = user
    })
    // console.log('OnInit called')
  }

  ngOnDestroy() {
    this.userSub.unsubscribe();
  }

  add() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    //dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    this.dialog.open(AddComponent, dialogConfig);
    this.userS.editDepartment = false
  }
  edit(id) {
    this.userS.departmentId = id
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = "60%";
    this.dialog.open(AddComponent, dialogConfig)
    this.userS.editDepartment = true
  }

  delete(id) {
    if(confirm('are you sure delete this record')){
      this.userS.deleteUser(id)
      this.notificationService.warn('! Deleted successfully');
    }
  }
}
