import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder } from '@angular/forms';
import { DepartmentService } from '../department.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  name = ''
  details = ''
  isEdit
  submited = false
  data
  myForm=this.fb.group({
   name:['',Validators.required,],
    description:['',Validators.required,]
  })
  constructor( private departmentService:DepartmentService,
    private dialogRef: MatDialogRef<AddComponent>,private fb:FormBuilder) { }
  ngOnInit() {
    this.isEdit = this.departmentService.editDepartment
    if (this.isEdit == true) {
      this.name = 'edit'
      this.details = 'Edit your information'
    }
    else {
      this.name = 'Submit'
      this.details = 'Add your details'
    }
  }
 onSubmit() {
   console.log(this.myForm)
    const details = { name: this.myForm.value.name, description: this.myForm.value.description}
    if (this.name == 'edit') {
      this.departmentService.editUser(details)
      this.submited = true
      this.data = ' your details updated successfully'
    }
    else {
      this.departmentService.addUser(this.myForm.value.name, this.myForm.value.description)
      this.submited = true
      this.data = 'successfully submited employee details'
    }

    this.myForm.reset()
  }
  close() {

    this.dialogRef.close();
  }
}
