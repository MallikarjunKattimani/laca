import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DepartmentComponent } from './department/department.component';
import { Routes, RouterModule } from '@angular/router';
import { DepartmentsDataListService } from '../../services/departments-data-list.service';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { AddComponent } from './add/add.component';
import { MaterialModule } from 'hrms/src/app/_helpers/material/material.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { DepartmentService } from './department.service';
import { NotificationService } from 'src/app/services/notification.service';

const route:Routes=[
  {
    path:'',
    component:DepartmentComponent
  }
]

@NgModule({
  declarations: [DepartmentComponent, AddComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(route),
    MaterialModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
   InMemoryWebApiModule.forRoot(DepartmentsDataListService)
  ],
  providers:[
DepartmentService,
NotificationService
  ]
})
export class DepartmentsModule { }
