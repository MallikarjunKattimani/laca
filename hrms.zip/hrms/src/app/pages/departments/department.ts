export interface Department {
    id,
    name,
    description
}
