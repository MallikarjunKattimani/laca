export interface Employee {
    id ;
    title: string,
    content:string,
    gender:string
}
