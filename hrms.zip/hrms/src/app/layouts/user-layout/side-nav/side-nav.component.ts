import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';

/**
 * @author Swetha P
 * @created  06-10-2020
 * @description Compoent of Side Navigation for user (user side menu)
 */
@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.css']
})
export class SideNavComponent implements OnInit {

  @ViewChild('sidenav') sidenav: MatSidenav;

  isExpanded = false;
  showSubmenu: boolean = false;
  isShowing = false;
  showSubSubMenu: boolean = false;
  public expandedIndex = -1;

  constructor() { }
  menuItems = [
    { title: 'Dashbaord', path: 'dashboard', icon: 'fa fa-tachometer', childs: [], showSubmenu: false },
    // { title: 'Masters', path: 'masters', icon: 'fa fa-cogs', childs: [], showSubmenu: false },
    {
      title: 'HR Operations', path: 'hr-operations', icon: 'fa fa-cog',
      childs: [
        { title: 'Branch', path: 'hr-operations/branch', icon: 'language' },
        { title: 'Company', path: 'hr-operations/company', icon: 'language' },
        { title: 'Department', path: 'hr-operations/department', icon: 'language' },
        { title: 'Designation', path: 'hr-operations/designation', icon: 'language' },
        { title: 'Leave Plan', path: 'hr-operations/leave-plan', icon: 'language' },
        { title: 'Notification', path: 'hr-operations/notification', icon: 'language' },
        { title: 'Project', path: 'hr-operations/project', icon: 'language' },
        { title: 'Yearly Holidays', path: 'hr-operations/holidays', icon: 'language' },
        
      ], showSubmenu: false
    },
    {
      title: 'Employee-Onboarding', path: 'employee', icon: 'fa fa-cog',
      childs: [
        { title: 'employee', path: 'employee-onboarding/employee', icon: 'language' },
        { title: 'policy', path: 'employee-onboarding/policy', icon: 'language' },
        { title: 'project', path: 'employee-onboarding/project', icon: 'language' },
        { title: 'resource', path: 'employee-onboarding/resource', icon: 'language' },
      ], showSubmenu: false
    }
  ];
  ngOnInit() {
  }
}
