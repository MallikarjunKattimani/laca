import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UserLayoutComponent } from './layouts/user-layout/user-layout.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { EmployeeOnboardingModule } from './modules/employee-onboarding/employee-onboarding.module';
import { PageNotFoundComponent } from './modules/page-not-found/page-not-found.component';
import { AuthGuard } from './util/auth.guard';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full',
    canActivate: [AuthGuard]
  },
  {
    path:'login',
    loadChildren: () => import('./modules/onboard/onboard.module').then(m => m.OnboardModule)
  },
  {
    path: '',
    component: UserLayoutComponent,
    children:[
      {
        path:'dashboard',
        component: DashboardComponent,
        canActivate: [AuthGuard]
      },
      {
        path:'hr-operations',
        loadChildren: () => import('./modules/hr-operations/hr-operations.module').then(m => m.HrOperationsModule),
        canActivate: [AuthGuard]
      },
      {
        path:'employee-onboarding',
        loadChildren:()=>EmployeeOnboardingModule
      },
    ]
  },
  { 
    path: '**',
    redirectTo: 'dashboard'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
