import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
@Injectable({
  providedIn: 'root'
})
export class DepartmentsDataListService implements InMemoryDbService {

  constructor() { }
  createDb() {
    let departments =   [
        { id: 1, name: 'Developing', description:'sdfg' },
        { id: 2, name: 'Testing', description:'sdfg' },
        { id: 3,  name: 'back-end', description:'sdfg' }
      ]
    
    return { departments };
  }
}