import { TestBed } from '@angular/core/testing';

import { DepartmentsDataListService } from './departments-data-list.service';

describe('DepartmentsDataListService', () => {
  let service: DepartmentsDataListService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DepartmentsDataListService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
