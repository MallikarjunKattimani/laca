import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClientService } from 'src/app/util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  subApiUrl = 'api/company/';
  constructor(private _http: HttpClientService) { }

  getCompanyList(params: any): Observable<any> {
    console.log(params);
    return this._http.get(this.subApiUrl + 'all', params).pipe(
      map(data => {
        return data;
      }));
  }

  saveCompany(params: any): Observable<any>{
    return this._http.post(this.subApiUrl + 'save', params).pipe(
      map(data => {
        return data;
      }));
  }

  updateCompany(params: any, urlParams :any): Observable<any>{
    return this._http.put(this.subApiUrl + ''+'/'+urlParams, params).pipe(
      map(data => {
        return data;
      }));
  }

  deleteCompany(params: any): Observable<any>{
    return this._http.delete(this.subApiUrl + '/'+ params).pipe(
      map(data => {
        return data;
      }));
  }
}
