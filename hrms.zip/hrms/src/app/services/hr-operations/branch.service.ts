import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClientService } from 'src/app/util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class BranchService {

  subApiUrl = 'branches';
  httpOptions= new HttpHeaders()
  
  constructor(private _http: HttpClientService) { }

  getBranchList(params: any): Observable<any> {
    console.log(params);
    this.httpOptions.append("Access-Control-Allow-Origin", "*")
    this.httpOptions.append('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE')

console.log(this.httpOptions)
    console.log('kjhvcvbnm')
    return this._http.get(this.subApiUrl + '', params,{headers:this.httpOptions}).pipe(
      map(data => {
        return data;
      }));
  }

  saveBranch(params: any): Observable<any>{
    console.log('asdfgbnhgfdsasdfgb')
    return this._http.post(this.subApiUrl + '', params).pipe(
      map(data => {
        return data;
      }));
  }

  updateBranch(params: any, urlParams :any): Observable<any>{
    return this._http.put(this.subApiUrl + ''+'/'+urlParams, params).pipe(
      map(data => {
        return data;
      }));
  }

  deleteBranch(params: any): Observable<any>{
    return this._http.delete(this.subApiUrl + '/'+ params).pipe(
      map(data => {
        return data;
      }));
  }
}
