import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClientService } from 'src/app/util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  SubApiUrl=''
  constructor(private _http:HttpClientService) { }

  getAllEmployee(params:any): Observable<any> {
    return this._http.get(this.SubApiUrl,params).pipe(
      map(data=>{
        return data;
      })
    );
  }

saveEmployee(params:any): Observable<any>{
  return this._http.post(this.SubApiUrl+'',params).pipe(
    map(data=>{
      return data;
    })
  );
}

updateEmployee(params:any, urlParams:any): Observable<any>{
return this._http.put(this.SubApiUrl+''+'/'+urlParams,urlParams).pipe(
  map(data=>{
    return data;
  })
);
}

deleteEmployee(params:any): Observable<any>{
  return this._http.delete(this.SubApiUrl +'/'+ params).pipe(
    map(data=>{
      return data;
    })
  );
}

}

