import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {  Subject } from 'rxjs';
// import { Observable } from 'rxjs/Observable';
import { map } from 'rxjs/operators';
import { Employee } from './employee';
import {Observable } from 'rxjs/Observable'
import 'rxjs/add/observable/throw';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService { 

  private _url = 'http://localhost:3000/api/user';  //1st to add webapi

  constructor(private http: HttpClient) { }

  private employee: Employee[] = []; // 2nd step to add interface[]

  private updateEmployee = new Subject<Employee[]>();  // 3rd step to add subject

  updateEmployeeListener() {
    return this.updateEmployee.asObservable();   //4th steps to add observable
  }

  getfun() {
    this.http.get<{ posts: any }>(this._url)  //5th step to add get method

      .pipe(map((postData) => {
        return postData.posts.map(post => {
          return {
            id: post._id,
            gender: post.gender,
            title: post.title,
            content: post.content
          };
        });
      }))
      .subscribe((transformedPosts => {
        this.employee = transformedPosts
        // console.log(this.employee)
        this.updateEmployee.next([...this.employee]);
      }), error => {
        // console.log(error)
      });
  }

  addEmployee(title:string, content:string, gender:string){
    const employees:Employee ={id:null, title:title, content:content, gender:gender};
    return this.http.post<any>(this._url,employees).subscribe((res=>{
      console.log(res)
      this.employee.push(employees);
      this.getfun()
      this.updateEmployee.next([...this.employee]);
    }), error=>{
      
    })
  }

  delete(empId){
    this.http.delete(this._url + '/' + empId)
    .subscribe((()=>{
      const updateEmployee=this.employee.filter(post=> post.id !==empId);
      this.employee=updateEmployee;
      this.updateEmployee.next([...this.employee]);
    }), error => {
      
      this.errorHnad(error);
      console.log(error)
    })
  }

  edit(id:any,post:any){
    const emp1:Employee={id:id, title:post.title, content:post.content, gender:post.gender}
    console.log(emp1);
    this.http.put(this._url + '/' + id, emp1).subscribe((res =>{
      const empUpdate =[...this.employee];

      const oldEmpIndx = empUpdate.findIndex(p=>p.id===id);
      empUpdate[oldEmpIndx]=emp1
      this.employee=empUpdate;
      this.updateEmployee.next([...this.employee]);
      console.log(this.employee)
    }), error => {

    })
  }

  errorHnad(error:HttpErrorResponse){
    console.log("Hi Bunny " + error.message)
    //return Observable.throw(error.message || "Server Not Found") 
    return Observable.throw(error.message || 'Server not found')
   
  }

}
