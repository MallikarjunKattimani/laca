import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DepartmentsModule } from 'src/app/pages/departments/departments.module';
// import { EmployeeComponent } from 'src/app/pages/employees/employee/employee.component';
import { EmployeesModule } from 'src/app/pages/employees/employees.module';
import { HolidaysModule } from '../../pages/holidays/holidays.module';

const routes: Routes = [
  {
    path:'company',
    loadChildren: () => import('./company/company.module').then(m => m.CompanyModule)
  },
  { path: 'holidays', loadChildren: () => HolidaysModule },
  {path:'department', loadChildren:() => DepartmentsModule},
  {path:'employees', loadChildren: () => EmployeesModule}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HrOperationsRoutingModule { }
