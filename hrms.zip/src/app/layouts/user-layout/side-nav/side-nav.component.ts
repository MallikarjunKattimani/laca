import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MatSidenav } from '@angular/material/sidenav';
import { Observable, Subscription } from 'rxjs';
import { MediaChange, MediaObserver } from '@angular/flex-layout';
@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html',
  styleUrls: ['./side-nav.component.css']
})
export class SideNavComponent implements OnInit {

  @ViewChild('sidenav') sidenav: MatSidenav;
  isExpanded = false;
  showSubmenu: boolean = false;
  isShowing = false;
  showSubSubMenu: boolean = false;
  public expandedIndex = -1;
  constructor() { }
  menuItems = [
    { title: 'Dashbaord', path: 'dashboard', icon: 'fa fa-tachometer', childs: [], showSubmenu: false },
    { title: 'Masters', path: 'masters', icon: 'fa fa-cogs', childs: [], showSubmenu: false },
    
    {
      title: 'HR-operations', path: 'HR-operations', icon: 'fa fa-cog',
      childs: [
        { title: 'Company', path: 'HR-operations/company', icon: 'language' },
        { title: 'Company1', path: 'HR-operations/company1', icon: 'language' },
        { title: 'Holidays', path: 'HR-operations/holidays', icon: 'language'},
        { title: 'Departments', path: 'HR-operations/department', icon: 'language'},
        { title: 'Employees', path: 'HR-operations/employees', icon: 'language'}
      ], showSubmenu: true
    },
    {
      title: 'HR-Admin', path: 'HR-operations', icon: 'fa fa-building-o',
      childs: [
        { title: 'Branch', path: 'HR-operations/branch', icon: 'language' },
      ], showSubmenu: true
    }
  ];

  public toggleMenu(): void {
    if (document.body.classList.contains('show-menu')) {
      document.body.classList.remove('show-menu');
    } else {
      document.body.classList.add('show-menu');
    }
    if (window.innerWidth <= 800) {
      if (document.body.classList.contains('stage-menu-open')) {
        document.body.classList.remove('stage-menu-open')
      }
    }
  }
  ngOnInit() {
  }
}
