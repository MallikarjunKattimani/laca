import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeComponent } from './employee/employee.component';
import { RouterModule, Routes } from '@angular/router';
import {  HttpClientModule } from '@angular/common/http';
import { EmployeeService } from '../../modules/shared/employee.service';
import { AddComponent } from './add/add.component';
import { EditComponent } from './edit/edit.component';
import { FormsModule } from '@angular/forms';

const route:Routes=[
  {
    path:'',
    component:EmployeeComponent
  }
]

@NgModule({
  declarations: [EmployeeComponent, AddComponent, EditComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forChild(route)
  ],
  providers:[
    EmployeeService
  ]
})
export class EmployeesModule { }
