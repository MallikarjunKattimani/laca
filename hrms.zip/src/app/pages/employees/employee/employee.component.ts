import { Component, OnInit } from '@angular/core';
import { Subscription } from 'rxjs';
import { Employee } from '../../../modules/shared/employee';
import { EmployeeService } from '../../../modules/shared/employee.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  employee:Employee[]=[];  // 1st to add interface array

  employeeSub:Subscription; // 2nd step to add subscription

  constructor(private employees:EmployeeService) { }  //3rd step to add employee service

  ngOnInit(): void {
    this.employees.getfun();
    this.employeeSub=this.employees.updateEmployeeListener()
    .subscribe((employee:Employee[])=> {
      this.employee=employee;
      console.log(' hi ' + this.employee);
    })
  
  }

}
