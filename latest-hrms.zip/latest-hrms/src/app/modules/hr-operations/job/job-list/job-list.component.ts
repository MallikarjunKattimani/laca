import { HttpParams } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { JobService } from 'src/app/services/hr-operations/job.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-job-list',
  templateUrl: './job-list.component.html',
  styleUrls: ['./job-list.component.css']
})
export class JobListComponent implements OnInit {

  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  dummyData=[]
  tableHeaders: string[] = ['name', 'experiance','description', 'action'];
  jobList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  jobForm: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  closeResult: any;
  deleteJob: any;
  modalHeader: string = '';
  submitted: boolean = false;
  @ViewChild('closeModal', { static: true }) closeModal: ElementRef<HTMLElement>;

  constructor(private _service: JobService,
    public dialog: MatDialog,
    public _toast: ToasterService,
    private modalService: NgbModal) { }

  ngOnInit(): void {
    this.jobForm = new FormGroup({
      id: new FormControl(''),
      name: new FormControl('', [Validators.required,
                                 Validators.minLength(3),
                                 Validators.pattern('[-a-zA-Z ]*')]),
      experiance: new FormControl('', [Validators.required,Validators.pattern('[0-9. ]{1,4}')]),
      description: new FormControl('',[Validators.required])
    });
    this.getAllJobs();
  }

  getAllJobs(event?: any, sorting?: any) {
    var params = {};
    params['size'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['number'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'id'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? sorting.direction : 'asc'; // be default sorting will be in Ascending order

    this._service.getJobList(params).subscribe(
      data => {
        this.jobList = new MatTableDataSource(data);
        this.jobList.sort = this.sort;
        this.pageSize = params['size'];
      });
    console.log(this.filter, "----");
  }
  applyFilter(event) {
    this.getAllJobs();
  }
  sortTable(event) {
    console.log(event);
    this.getAllJobs(null, event);
  }
  getJobId() {
    if (this.jobForm.value.id)
      return this.jobForm.value.id;
    else return 0;
  }
  /** 
   * Create ot update job 
  */
  onSubmit() {
    if (this.jobForm.valid) {
      this.submitted = true;
      this.dummyData.push(this.jobForm.value)
      this.jobList = new MatTableDataSource(this.dummyData);
      if (this.getJobId() > 0) {
        // update API call
        var params = new HttpParams();
        params.set('id', this.getJobId());
        this._service.updateJob(this.jobForm.value, this.getJobId()).subscribe(data => {
          console.log(data);
          this.getAllJobs();
        });
      } else {
        // create API call
        delete this.jobForm.value.id;
        this._service.saveJob(this.jobForm.value).subscribe(data => {
          console.log(data);
          this.getAllJobs();
        });
      }
      this.modalService.dismissAll();
    } else {
      this.submitted = false;
      this._toast.show('warn', "Please enter mandatory fields");
    }

  }

  open(content, type: boolean, job?) {
    this.modalHeader = type ? "Create" : "Update";
    this.jobForm.reset();
    if (!type) {
      console.log("job--", job);
      this.jobForm.patchValue(job, { onlySelf: true });

    }
    this.modalService
      .open(content, {
        ariaLabelledBy: "modal-basic-title",
        windowClass: "my-class"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
        }
      );
  }
  openDelete(deleteConfirm, job?) {
    this.deleteJob = job;
    this.modalService
      .open(deleteConfirm, {
        ariaLabelledBy: "modal-basic-title"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  onDeleteConfirmation() {
    this._service.deleteJob(this.deleteJob.id).subscribe(
      (data: any) => {
        this.getAllJobs();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }

  // No need
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }

  public hasError = (controlName: string, errorName: string) =>{
    return this.jobForm.controls[controlName].hasError(errorName);
  }
}
