import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-policy',
  templateUrl: './employee-policy.component.html',
  styleUrls: ['./employee-policy.component.css']
})
export class EmployeePolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
