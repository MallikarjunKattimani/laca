import { HttpParams } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ModalDismissReasons, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { BranchService } from 'src/app/services/hr-operations/branch.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-branch-list',
  templateUrl: './branch-list.component.html',
  styleUrls: ['./branch-list.component.css']
})
export class BranchListComponent implements OnInit {

  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  dummyData=[]
  tableHeaders: string[] = ['name', 'location','description', 'action'];
  branchList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  branchForm: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  closeResult: any;
  deleteBranch: any;
  modalHeader: string = '';
  submitted: boolean = false;
  loading: boolean = true;
  @ViewChild('closeModal', { static: true }) closeModal: ElementRef<HTMLElement>;

  constructor(private _service: BranchService,
    public dialog: MatDialog,
    public _toast: ToasterService,
    private modalService: NgbModal) { }

  ngOnInit(): void {
    this.branchForm = new FormGroup({
      id: new FormControl(''),
      name: new FormControl('', [Validators.required,
      Validators.minLength(3),
      Validators.pattern('[a-zA-Z ]*')]),
      location: new FormControl('', [Validators.required,
      Validators.minLength(2),
      Validators.pattern('[a-zA-Z ]*')]),
      description: new FormControl('')
    });
    this.getAllBranches();
  }

  getAllBranches(event?: any, sorting?: any) {
    var params = {};
    params['size'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['number'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'id'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? sorting.direction : 'asc'; // be default sorting will be in Ascending order

    this._service.getBranchList(params).subscribe(
      data => {
        this.branchList = new MatTableDataSource(data);
        this.branchList.sort = this.sort;
        this.pageSize = params['size'];
      });
    console.log(this.filter, "----");
  }
  applyFilter(event) {
    this.getAllBranches();
  }
  sortTable(event) {
    console.log(event);
    this.getAllBranches(null, event);
  }
  getBranchId() {
    if (this.branchForm.value.id)
      return this.branchForm.value.id;
    else return 0;
  }
  /** 
   * Create ot update branch 
  */
  onSubmit() {
    if (this.branchForm.valid) {
      this.submitted = true;
      this.dummyData.push(this.branchForm.value)
      this.branchList = new MatTableDataSource(this.dummyData);
      if (this.getBranchId() > 0) {
        // update API call
        var params = new HttpParams();
        params.set('id', this.getBranchId());
        this._service.updateBranch(this.branchForm.value, this.getBranchId()).subscribe(data => {
          console.log(data);
          this.getAllBranches();
        });
      } else {
        // create API call
        delete this.branchForm.value.id;
        this._service.saveBranch(this.branchForm.value).subscribe(data => {
          console.log(data);
          this.getAllBranches();
        });
      }      
      this.modalService.dismissAll();
    } else {
      this.submitted = false;
      this._toast.show('warn', "Please enter mandatory fields");
    }
  }

  open(content, type: boolean, branch?) {
    this.modalHeader = type ? "Create": "Update";
    this.branchForm.reset();
    if (!type) {
      console.log("branch--",branch);
      this.branchForm.patchValue(branch, { onlySelf: true });
    }

    this.modalService
      .open(content, {
        ariaLabelledBy: "modal-basic-title",
        windowClass: "my-class"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
        }
      );
  }
  openDelete(deleteConfirm, branch?) {
    this.deleteBranch = branch;
    this.modalService
      .open(deleteConfirm, {
        ariaLabelledBy: "modal-basic-title"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  onDeleteConfirmation() {
    this._service.deleteBranch(this.deleteBranch.id).subscribe(
      (data: any) => {
        this.getAllBranches();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }
  // No need
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }
  public hasError = (controlName: string, errorName: string) => {
    return this.branchForm.controls[controlName].hasError(errorName);
  }
}
