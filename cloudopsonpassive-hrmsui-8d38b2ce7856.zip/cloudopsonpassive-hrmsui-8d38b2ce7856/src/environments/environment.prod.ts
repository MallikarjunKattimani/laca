export const environment = {
  production: true,
  baseApiUrl : '',
  storageKey :'sessionUser',
  encrypt:true
};
