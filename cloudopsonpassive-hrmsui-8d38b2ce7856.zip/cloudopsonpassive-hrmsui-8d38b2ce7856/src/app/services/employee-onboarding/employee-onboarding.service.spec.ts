import { TestBed } from '@angular/core/testing';

import { EmployeeOnboardingService } from './employee-onboarding.service';

describe('EmployeeOnboardingService', () => {
  let service: EmployeeOnboardingService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EmployeeOnboardingService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
