import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClientService } from 'src/app/util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class DesignationService {

  subApiUrl = 'designation';

  constructor(private _http: HttpClientService) { }

  getDesignationList(params: any): Observable<any> {
    console.log(params);
    return this._http.get(this.subApiUrl, params);
  }

  saveDesignation(params: any): Observable<any>{
    return this._http.post(this.subApiUrl, params);
  }

  updateDesignation(params: any, urlParams :any): Observable<any>{
    return this._http.put(this.subApiUrl + '/'+urlParams, params);
  }

  deleteDesignation(params: any): Observable<any>{
    return this._http.delete(this.subApiUrl + '/'+ params);
  }
}
