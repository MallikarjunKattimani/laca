import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { LocalStorageService } from 'src/app/util/local-storage.service';

/**
 * @author Swetha P
 * @date 01-10-2020
 * @description NavbarComponent for user-layout
 */
@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  constructor(private _service: AuthenticationService,
               private _ls : LocalStorageService,
               private _router: Router) { }

  ngOnInit(): void {
  }
  /**
   * @author Swetha P
   * @date 06-10-2020
   * @description toggles side menu 
   * @memberof NavBarComponent
   */
  public toggleMenu(): void {
    if (document.body.classList.contains('show-menu')) {
      document.body.classList.remove('show-menu');
    } else {
      document.body.classList.add('show-menu');
    }
    if (window.innerWidth <= 800) {
      if (document.body.classList.contains('stage-menu-open')) {
        document.body.classList.remove('stage-menu-open')
      }
    }
  }

  /**
   * @author Swetha P
   * @date 06-10-2020
   * @description ends the session of loggedIn user and redirects to login page
   * @memberof NavBarComponent
   */
  logout(){
    this._ls.removeUser("user");
    this._router.navigate(['login']);
    /*this._service.logout().subscribe(data=>{
      if(data){
        this._ls.removeUser("user");
        this._router.navigate(['login']);
      }
    });*/
  }
}
