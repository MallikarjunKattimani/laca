import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmployeeOnboardRoutingModule } from './employee-onboard-routing.module';
import { EmployeesListComponent } from './employees-list/employees-list.component';
import { EmployeePolicyComponent } from './employee-policy/employee-policy.component';
import { EmployeeProjectComponent } from './employee-project/employee-project.component';
import { EmployeeResourcesComponent } from './employee-resources/employee-resources.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MaterialModule } from 'src/app/_helpers/material/material.module';
import { EmployeeRegisterComponent } from './employee-register/employee-register.component';


@NgModule({
  declarations: [
    EmployeesListComponent,
    EmployeePolicyComponent,
    EmployeeProjectComponent,
    EmployeeResourcesComponent,
    EmployeeRegisterComponent
  ],
  imports: [
    CommonModule,
    EmployeeOnboardRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    MaterialModule
  ]
})
export class EmployeeOnboardModule { }
