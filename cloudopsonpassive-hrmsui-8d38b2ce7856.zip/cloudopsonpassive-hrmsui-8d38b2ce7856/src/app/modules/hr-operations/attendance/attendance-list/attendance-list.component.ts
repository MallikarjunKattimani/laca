import { HttpParams } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { AttendenceService } from 'src/app/services/hr-operations/attendence.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-attendance-list',
  templateUrl: './attendance-list.component.html',
  styleUrls: ['./attendance-list.component.css']
})
export class AttendanceListComponent implements OnInit {
  minTime: Date;
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['companyName', 'branchName', 'inTime', 'outTime', 'action'];
  attendencesList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  attendanceForm: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  closeResult: any;
  deleteCompany: any;
  modalHeader: string = '';
  submitted: boolean = false;


  constructor(private _service: AttendenceService,
              public dialog: MatDialog,
              public _toast: ToasterService,
              private modalService: NgbModal) {
    const currentTime = new Date();
    this.minTime = new Date();
  }

  ngOnInit(): void {
    this.attendanceForm = new FormGroup({
      id: new FormControl(''),
      companyName: new FormControl('', [Validators.required]),
      branchName: new FormControl('', [Validators.required]),
      inTime: new FormControl('', [Validators.required]),
      outTime: new FormControl('', [Validators.required])
    });
    this.getAllAttendences();
  }

  getAllAttendences(event?: any, sorting?: any) {
    var params = {};
    params['size'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['number'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'id'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? sorting.direction : 'asc'; // be default sorting will be in Ascending order

    this._service.getAttendenceList(params).subscribe(
      data => {
        this.attendencesList = new MatTableDataSource(data);
        this.attendencesList.sort = this.sort;
        this.pageSize = params['size'];
      });
    console.log(this.filter, "----");
  }
  applyFilter(event) {
    this.getAllAttendences();
  }
  sortTable(event) {
    console.log(event);
    this.getAllAttendences(null, event);
  }
  getAttendenceId() {
    if (this.attendanceForm.value.id)
      return this.attendanceForm.value.id;
    else return 0;
  }
  /** 
   * Create ot update branch 
  */
  onSubmit() {
    this.dialog.closeAll();
    if (this.attendanceForm.valid) {
      this.submitted = true;
      if (this.getAttendenceId() > 0) {
        // update API call
        var params = new HttpParams();
        params.set('id', this.getAttendenceId());
        this._service.updateAttendence(this.attendanceForm.value, this.getAttendenceId()).subscribe(data => {
          console.log(data);
          this.getAllAttendences();
        });
      } else {
        // create API call
        delete this.attendanceForm.value.id;
        this._service.saveAttendence(this.attendanceForm.value).subscribe(data => {
          console.log(data);
          this.getAllAttendences();
        });
      }
      
    } else {
      this.submitted = false;
      this._toast.show('warn', "Please enter mandatory fields");
    }
  }
  open(content, type: boolean, attendance?) {
    this.modalHeader = type ? "Create" : "Update";
    this.attendanceForm.reset();
    if (!type) {
      console.log("attendance--", attendance);
      this.attendanceForm.patchValue(attendance, { onlySelf: true });
    }
    this.modalService
      .open(content, {
        ariaLabelledBy: "modal-basic-title",
        windowClass: "my-class"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
        }
      );
  }
  openDelete(deleteConfirm, attendance?) {
    this.deleteCompany = attendance;
    this.modalService
      .open(deleteConfirm, {
        ariaLabelledBy: "modal-basic-title"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  onDeleteConfirmation() {
    this._service.deleteAttendence(this.deleteCompany.id).subscribe(
      (data: any) => {
        this.getAllAttendences();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }

  // No need
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }
}
