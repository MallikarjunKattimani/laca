import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm, FormBuilder,Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
 // @ViewChild('myForm') myForm: NgForm
  genders = ['male', 'female']
  name = ''
  details = ''
  isEdit
  submited = false
  data
  myForm=this.fb.group({
    title:['',Validators.required,],
    content:['',Validators.required,],
    gender:['',Validators.required]
  })
  constructor(private router: Router, private employeeService: EmployeeService,
    private dialogRef: MatDialogRef<AddComponent>,private fb:FormBuilder) { }
  ngOnInit() {
    this.isEdit = this.employeeService.editEmployee
    if (this.isEdit == true) {
      this.name = 'edit'
      this.details = 'Edit your information'
    }
    else {
      this.name = 'Submit'
      this.details = 'Add your details'
    }
  }
 onSubmit() {
   console.log(this.myForm)
    const details = { title: this.myForm.value.title, content: this.myForm.value.content, gender: this.myForm.value.gender }
    if (this.name == 'edit') {
      this.employeeService.editUser(details)
      this.submited = true
      this.data = ' your details updated successfully'
    }
    else {
      this.employeeService.addUser(this.myForm.value.title, this.myForm.value.content, this.myForm.value.gender)
      this.submited = true
      this.data = 'successfully submited employee details'
    }

    this.myForm.reset()
  }
  close() {

    this.dialogRef.close();
  }

}
