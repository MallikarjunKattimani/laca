import { Injectable } from '@angular/core';
import { Employee } from './employee';
import { HttpClient, HttpErrorResponse, HttpHeaders, } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs';
//import 'rxjs/add/operator/catch';
//import 'rxjs/add/observable/throw'
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private _url = 'api/employee'

  constructor(private http: HttpClient) { }

  private user: Employee[] = [];
  private updateUser = new Subject<Employee[]>();
  editEmployee: boolean
  employeeId

  addUser(title: string, content: string, gender: string) {
    const user: Employee = { id: null, title: title, content: content, gender: gender };
    return this.http.post<any>(this._url, user).subscribe((resp => {
      this.getUsers()
    }), error => {
      this.errorHand(error);
      console.log(error)
    })
  }

  updateUserListener() {
    return this.updateUser.asObservable();
  }
  getUsers() {
    this.http
      .get<any>(
        this._url
      )
      .subscribe((transformedPosts => {
        this.user = transformedPosts;
        console.log(this.user)
        this.updateUser.next([...this.user]);
      }), error => {
        this.errorHand(error);
        console.log(error)
      });
  }

  deleteUser(usersId) {
    this.http.delete(this._url + '/' + usersId)
      .subscribe((() => {
        this.getUsers()
      }), error => {
        this.errorHand(error);
        console.log(error)
      });
  }
  editUser(post: any) {
    console.log(this.employeeId)
    const user1: Employee = { id: this.employeeId, title: post.title, content: post.content, gender: post.gender }
    console.log(user1);
    this.http.put(this._url + '/' + this.employeeId, user1).subscribe((res => {
      this.getUsers()
    }), error => {
      this.errorHand(error);
      console.log(error)
    })
  }
  errorHand(error: HttpErrorResponse) {
    // console.log("Hi there  " + error.message)
    // return Observable.throw(error.message || "server not  ")
  }
}
