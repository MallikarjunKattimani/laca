import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeComponent } from './employee/employee.component';
import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EmployeeService } from './employee.service';
import { AddComponent } from './add/add.component';
import { MaterialModule } from 'src/app/_helpers/material/material.module';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { EmployeeDetailsService } from 'src/app/services/employee-details.service';
import { NotificationService } from 'src/app/services/notification.service';

const router: Routes = [
  { path: '', component: EmployeeComponent },
  { path: 'add', component: AddComponent }
]

@NgModule({
  declarations: [EmployeeComponent, AddComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    RouterModule.forChild(router),
    InMemoryWebApiModule.forRoot(EmployeeDetailsService)
  ],
  providers: [
    EmployeeService,
    NotificationService
  ]
})
export class EmployeesModule { }
