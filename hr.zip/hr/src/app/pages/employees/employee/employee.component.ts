import { Component, OnInit, OnDestroy } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';
import { Subscription } from 'rxjs';
//import { Router } from '@angular/router';
import { MatDialog, MatDialogConfig } from "@angular/material/dialog"
//import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddComponent } from '../add/add.component';
import { NotificationService } from 'src/app/services/notification.service';
@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit, OnDestroy {
  closeResult: string;
  user: Employee[] = []
  userSub: Subscription;
  id

  constructor(private userS: EmployeeService, private dialog: MatDialog,
    private notificationService :NotificationService) { }

  ngOnInit() {
    this.userS.getUsers();
    this.userSub = this.userS.updateUserListener().subscribe((user: Employee[]) => {
      this.user = user
    })
    // console.log('OnInit called')
  }

  ngOnDestroy() {
    this.userSub.unsubscribe();
  }

  add() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    //dialogConfig.autoFocus = true;
    dialogConfig.width = "60%";
    this.dialog.open(AddComponent, dialogConfig);
    this.userS.editEmployee = false
  }
  edit(id) {
    this.userS.employeeId = id
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose = true;
    dialogConfig.width = "60%";
    this.dialog.open(AddComponent, dialogConfig)
    this.userS.editEmployee = true
  }

  delete(id) {
    if(confirm('are you sure delete this record')){
      this.userS.deleteUser(id)
      this.notificationService.warn('! Deleted successfully');
    }
  }

}
