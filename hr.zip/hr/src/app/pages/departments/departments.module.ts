import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DepartmentComponent } from './department/department.component';
import { Routes, RouterModule } from '@angular/router';
import { DepartmentsDataListService } from '../../services/departments-data-list.service';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';
import { MaterialModule } from '../../_helpers/material/material.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { DepartmentService } from './department.service';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

const route: Routes = [
  {
    path: '',
    component: DepartmentComponent
  }
]

@NgModule({
  declarations: [DepartmentComponent,],
  imports: [
    CommonModule,
    RouterModule.forChild(route),
    MaterialModule,
    ReactiveFormsModule,
    FormsModule,
    HttpClientModule,
    ToastrModule.forRoot(), 
    NgbModule,
    InMemoryWebApiModule.forRoot(DepartmentsDataListService)
  ],
  providers: [
    DepartmentService,
    ToastrService,
  ]
})
export class DepartmentsModule { }
