import { Component, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { DepartmentService } from '../department.service';
import { Department } from '../department';
import { Subscription } from 'rxjs';
import { Validators, FormBuilder } from '@angular/forms';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { MatDialogRef } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-department',
  templateUrl: './department.component.html',
  styleUrls: ['./department.component.css']
})
export class DepartmentComponent implements OnInit {

  closeResult: string;
  departments:Department[] = []
  userSub: Subscription;
  isNew:boolean
  departmentHeading
  deletingDepartment
  name

  constructor(private depS:DepartmentService, 
    private dialog: MatDialog,
    private fb:FormBuilder,
    private modalService: NgbModal,
    private toastr: ToastrService) { }
   
    myForm=this.fb.group({
      id:[null],
      name:['',Validators.required,],
       description:['',Validators.required,]
     })

  ngOnInit() {
    this.depS.getUsers();
    this.userSub = this.depS.updateUserListener().subscribe((user: Department[]) => {
      this.departments = user
      console.log(this.departments)
    })
    // console.log('OnInit called')
  }

onSubmit(){
  if(this.isNew){
    this.depS.addUser(this.myForm.value);
    this.myForm.reset();
    this.toastr.success('department created', 'Success');
  }
  else{
    this.depS.editUser(this.myForm.value,this.myForm.get('id').value)
    this.myForm.reset();
    this.toastr.success('department updated', 'Success');
  }
  this.modalService.dismissAll()
}

openDelete(deleteConfirm, department){
  this.deletingDepartment=department
  this.modalService.open(deleteConfirm, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
    this.closeResult = `Closed with: ${result}`;
  }, (reason) => {
    this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
  });
}


onDeleteConfirmation() {
this.depS.deleteUser(this.deletingDepartment.id)
      this.modalService.dismissAll("on fail");
     // this.toastr.success('School Deleted', 'Success');
}
  open(content, type:boolean,department?) {
    this.isNew=type
    this.departmentHeading =this.isNew? 'add your department details':'edit your department details';
    this.name=this.isNew?'save':'update'
    if( this.isNew){
      this.myForm.reset()
    }
else{
  this.myForm.patchValue(department,{ onlySelf:true})
}
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }




  ngOnDestroy() {
    this.userSub.unsubscribe();
  }

  // add() {
  //   const dialogConfig = new MatDialogConfig();
  //   dialogConfig.disableClose = true;
  //   //dialogConfig.autoFocus = true;
  //   dialogConfig.width = "60%";
  //   this.dialog.open(AddComponent, dialogConfig);
  //   this.userS.editDepartment = false
  // }
  // edit(id) {
  //   this.userS.departmentId = id
  //   const dialogConfig = new MatDialogConfig();
  //   dialogConfig.disableClose = true;
  //   dialogConfig.width = "60%";
  //   this.dialog.open(AddComponent, dialogConfig)
  //   this.userS.editDepartment = true
  // }

  // delete(id) {
  //   if(confirm('are you sure delete this record')){
  //     this.userS.deleteUser(id)
  //     this.notificationService.warn('! Deleted successfully');
  //   }
  // }
}
