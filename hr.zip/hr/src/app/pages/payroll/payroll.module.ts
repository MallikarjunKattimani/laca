import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PayrollComponent } from './payroll.component';
import { MaterialModule } from 'src/app/_helpers/material/material.module';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, Router, Routes } from '@angular/router';
import { InMemoryWebApiModule } from 'angular-in-memory-web-api';

const router:Routes =[
  {path:'',}
]

@NgModule({
  declarations: [PayrollComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    RouterModule.forChild(router),
   // InMemoryWebApiModule.forRoot()
  ]
})
export class PayrollModule { }
