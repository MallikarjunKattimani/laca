import { Injectable } from '@angular/core';
import { InMemoryDbService } from 'angular-in-memory-web-api';
@Injectable({
  providedIn: 'root'
})
export class EmployeeDetailsService implements InMemoryDbService {

  constructor() { }
  createDb() {
    let employee =   [
        { id: 1, title: 'hi', content: 'zxcv', gender: 'male' },
        { id: 2, title: 'john', content: 'zxcv', gender: 'male' },
        { id: 3, title: 'anthony', content: 'zxcv', gender: 'male' }
      ]

    
    return { employee };
  }
}
