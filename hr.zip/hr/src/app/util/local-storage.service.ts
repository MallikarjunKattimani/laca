import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LocalStorageService {

  constructor() { }

  getLoggedInUser(key:any,json:boolean){
    if(json)
      return JSON.parse(localStorage.getItem(key));
    else localStorage.getItem(key);
  }

  setLoggedInUser(data:any, json:boolean){
    if(json)
      localStorage.setItem("currentUser", JSON.stringify(JSON.parse(data)));
    else localStorage.setItem("currentUser", data);
  }

  removeUser(){
    localStorage.removeItem("currentUser");
  }

  isLoggedIn(){
    if(localStorage.getLoggedInUser(true)){
      return true;
    }else return false;
  }
}
