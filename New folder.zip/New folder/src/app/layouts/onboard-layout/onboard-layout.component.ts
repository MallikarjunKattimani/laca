import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-onboard-layout',
  templateUrl: './onboard-layout.component.html',
  styleUrls: ['./onboard-layout.component.css']
})
export class OnboardLayoutComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
