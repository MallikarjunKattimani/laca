import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CompanyService } from 'src/app/services/hr-operations/company.service';

@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.css']
})
export class CompanyListComponent implements OnInit {

  dataSource: any = [];
  displayedColumns: string[] = ['companyId', 'name' ,'action'];
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  totalRecords: number = 0;
  pageIndex: number = 0;
  pageSize: number = 5;
  
  closeResult: string;
  title='';

  constructor(private _service: CompanyService,private modalService: NgbModal) { }

  ngOnInit(): void {
    this.getCompanyList(null);
  }
  getCompanyList(event) {
    this.dataSource = [
      { name: 'ONPassive', companyId: 1 },
      { name: 'Twitter', companyId: 2 },
      { name: 'Facebook', companyId: 3 },
      { name: 'WhatsApp', companyId: 4 },
      { name: 'Skype', companyId: 5 },
      { name: 'Intsgram', companyId: 6 },
      { name: 'Amazon', companyId: 7 },
      { name: 'Flipkart', companyId: 8 },
      { name: 'Mintra', companyId: 9 },
      { name: 'Zomato', companyId: 10 },
      { name: 'Swiggy', companyId: 11 },
      { name: 'Naturals', companyId: 12 },
      { name: 'Hindustan', companyId: 13 },
      { name: 'Dabur', companyId: 14 },
      { name: 'Google 1', companyId: 15 },
      { name: 'Google 2', companyId: 16 },
      { name: 'Google 3', companyId: 17 }
    ];
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.totalRecords = this.dataSource.length;
    if(event){
      this.pageIndex = event.pageIndex;
      this.pageSize = event.pageSize;
      console.log(event);
    }
  }
  applyFilter(event){

  }
  addCompany(actionType){
    if(actionType=='add'){
      this.title='Add';
    }else this.title='Edit';
  }
  showModal(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
      console.log(result);
      this.closeResult = `Closed with: ${result}`;
    }, (reason) => {
      console.log("reason",reason);
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }
}
