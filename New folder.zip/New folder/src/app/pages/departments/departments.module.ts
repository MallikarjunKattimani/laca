import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DepartmentComponent } from './department/department.component';
import { RouterModule, Routes } from '@angular/router';

const route: Routes = [
  {
    path: '',
    component: DepartmentComponent
  }
]

@NgModule({
  declarations: [DepartmentComponent],
  imports: [
    CommonModule,
    RouterModule.forChild(route)
  ]
})
export class DepartmentsModule { }
