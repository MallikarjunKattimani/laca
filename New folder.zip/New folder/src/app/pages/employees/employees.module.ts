import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeComponent } from './employee/employee.component';
import { RouterModule, Routes } from '@angular/router';
import {  HttpClientModule } from '@angular/common/http';
import { EmployeeService } from '../../modules/shared/employee.service';
// import { AddComponent } from './add/add.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from 'src/app/_helpers/material/material.module';
import { AddComponent } from './add/add.component';

const route:Routes=[
  {
    path:'',
    component:EmployeeComponent
  }
]

@NgModule({
  declarations: [
    EmployeeComponent, 
    AddComponent
  ],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    MaterialModule,
    ReactiveFormsModule,
    RouterModule.forChild(route)
  ],
  providers:[
    EmployeeService
  ]
})
export class EmployeesModule { }
