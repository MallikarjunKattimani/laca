import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
// import { title } from 'process';
import { EmployeeService } from 'src/app/modules/shared/employee.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {

  genders=['male','female'];
  name='';
  details='';
  isEdit
  submitted =false
  data

  addForm=this.fb.group({
    title:['',[ Validators.required]],
    content:[''],
    gender:['',[Validators.required]],
  })
  

  constructor(private dialogRef:MatDialogRef<AddComponent>, private employ:EmployeeService,
    private fb:FormBuilder) { }

  ngOnInit(): void {
    this.isEdit=this.employ.editEmployee
    if(this.isEdit== true){
this.name='edit'
      this.details="edit your information"
    }  else{
      this.name='submit';
      this.details='Add your Details'
    }
  }

  onSubmit(){
    const details ={title:this.addForm.value.title,content:this.addForm.value.content,ender:this.addForm.value.gender}

    if(this.name=='edit'){
      this.employ.edit(details)
      this.submitted=true
      this.data='your data submitted successfully';
    } else{
      this.employ.addEmployee(this.addForm.value.title,this.addForm.value.content,this.addForm.value.gender)
      this.submitted=true
      this.data='your data submitted successfully';
    }
  }

  close(){
    this.dialogRef.close();
  }


}
