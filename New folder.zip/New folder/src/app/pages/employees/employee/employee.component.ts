import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { Subscription } from 'rxjs';
import { Employee } from '../../../modules/shared/employee';
import { EmployeeService } from '../../../modules/shared/employee.service';
import { AddComponent } from '../add/add.component';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit,OnDestroy{

  genders:['male','female'];
  Edit:false;
  isOpen:false;

  employee:Employee[]=[];  // 1st to add interface array

  employeeSub:Subscription; // 2nd step to add subscription

  constructor(private employees:EmployeeService, private dialog:MatDialog) { }  //3rd step to add employee service

  ngOnInit(): void {
    this.employees.getfun();
    this.employeeSub=this.employees.updateEmployeeListener()
    .subscribe((employee:Employee[])=> {
      this.employee=employee;
       console.log(' hi ' + this.employee);
    })
  }

  ngOnDestroy(){
    this.employeeSub.unsubscribe();
  }

  add(){
    const dialogConfig =new MatDialogConfig();
    dialogConfig.disableClose=true;
    dialogConfig.width="60%";
    this.dialog.open(AddComponent,dialogConfig);
    this.employees.editEmployee=false;
  }

edit(id){
  this.employees.Id= id;
  const dialogConfig =new MatDialogConfig();
    dialogConfig.disableClose=true;
    dialogConfig.width="60%";
    this.dialog.open(AddComponent,dialogConfig);
    this.employees.editEmployee=true;
}  

delete(id){
  this.employees.delete(id);
}

}
