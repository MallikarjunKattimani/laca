import { Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { EmployeeOnboardingService } from 'src/app/services/employee-onboarding/employee-onboarding.service';

@Component({
  selector: 'app-employees-list',
  templateUrl: './employees-list.component.html',
  styleUrls: ['./employees-list.component.css']
})
export class EmployeesListComponent implements OnInit {
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['departmentName', 'departmentDescription','image', 'action'];
  departmentList = new MatTableDataSource();
  filter: any = {searchKey: ''};
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  constructor(private _service:EmployeeOnboardingService,
    private router:Router ) { }

  ngOnInit(): void { 
    
  }
  getAllDepartments(event?: any, sorting?: any) {
    var params = {};
    params['size'] = (event) ? event.pageSize : this.pageSize;
    params['number'] = (event) ? event.pageIndex : this.pageIndex;
    params['searchKey'] = this.filter.searchKey;
    params['sortKey'] = (sorting) ? sorting.active : 'departmentId';
    params['sortOrder'] = (sorting) ? sorting.direction : 'asc';

    this._service.getEmployeesList(params).subscribe(
      data => {
        this.departmentList = new MatTableDataSource(data);
        this.departmentList.sort = this.sort;
        this.pageSize = params['size'];
      },
      error => {

      });
    console.log(this.filter, "----");
  }
  applyFilter(event) {
    var filterValue = (event.target as HTMLInputElement).value;
    this.getAllDepartments(null, null);
  }
  sortTable(event) {
    console.log(event);
    this.getAllDepartments(null, event);
  }
   
  open(){
    this.router.navigate(['employee-onboard/register'])
  }
  
}
