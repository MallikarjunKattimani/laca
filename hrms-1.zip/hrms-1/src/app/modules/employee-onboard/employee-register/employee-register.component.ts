import { Component, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-employee-register',
  templateUrl: './employee-register.component.html',
  styleUrls: ['./employee-register.component.css']
})
export class EmployeeRegisterComponent implements OnInit, OnDestroy {
  @ViewChild('checkForm') myform: NgForm
  genders = ['male', 'female', 'other']
  // policys = ['policy1', 'policy2', 'policy3', 'policy5']
  // policy = []
  // checkbox(a) {
  //  // console.log(a)
  //   //this.policy.push(a)
  //   for (let k = 0; k < this.policy.length; k++) {
  //     if (this.policy[k] === a) {
  //       console.log(a)
  //       this.policy = this.policy.filter(p => {
  //         p != a
  //       })
  //     }
  //     else { 
  //       console.log(a)
  //       this.policy.push(a)
  //       console.log(this.policy) 
  //     }
  //   } 
  //  //this.policy.push(a)
  // }

  // submitted() {
    
  //    return this.policy=[]
  // }
  bloodGroups = ['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-']
  employeeForm: FormGroup
  imagePreview = []
  file = []
  fileError = ''
  fileChosen
  formate = ['png', 'jpg', 'pdf']
  maxSize = 500000
  minSize = 10000
  employeeData = []
  constructor(private fb: FormBuilder,
    private router: Router,
    private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.employeeForm = new FormGroup({
      name: new FormControl('', [Validators.required, Validators.pattern("[+A-Za-z ]{3,15}")]),
      mobile: new FormControl('', [Validators.required, Validators.pattern("[0-9]{10,12}")]),
      email: new FormControl('', [Validators.required, Validators.email]),
      bloodGroup: new FormControl('', [Validators.required, Validators.pattern("[A-Z+-]{2,3}")]),
      designation: new FormControl('', [Validators.required, Validators.pattern("[+A-Za-z ]{3,25}")]),
      gender: new FormControl('male', [Validators.required]),
      accountNo: new FormControl('', [Validators.required, Validators.pattern("[0-9]{3,25}")]),
      IFscCode: new FormControl('', [Validators.required, Validators.pattern("[A-Z0-9]{6,15}")]),
      //attachments: new FormControl('', [Validators.required]),
      attachments: new FormArray([], [Validators.required])
    })
  }
  back() {
    this.router.navigate(['employee-onboard'])
    //  this.router.navigate(['../',{relativeTo:this.route}])
  }
  onAttachmentPicked(event: Event) {
    let fileName = ''
    const file = (event.target as HTMLInputElement).files;
    for (let j = 0; j < file.length; j++) {
      //this.employeeForm.patchValue({ attachments: file });
      console.log(this.employeeForm)
      var ext = file[j].name.substring(file[j].name.lastIndexOf('.') + 1);
      console.log(ext)
      let i
      for (i = 0; i < this.formate.length; i++) {
        if (ext.toLowerCase() == this.formate[i]) {
          this.fileChosen = true
          fileName = null
          break
        } else {
          this.fileChosen = false
          fileName = ext
          //this.fileError = 'please chose image or pdf  and size not more than 500kb'
          console.log(this.fileError)
        }
      }
      if ((this.fileChosen == true)) {
        if (file[j].size < this.maxSize) {
          //this.employeeForm.get("attachments").updateValueAndValidity();
          //var fArray = this.employeeForm.get("attachments") as FormArray
          //fArray.push(this.fb.group({ file: file[j] }))
          //fArray.push(this.fb.group(file)) 
          const reader = new FileReader();

          //console.log(file)
          this.file.push(file[j].name)
          console.log(this.file)
          this.fileError = ''
          reader.onload = () => {
            let fArray = this.employeeForm.get("attachments") as FormArray
            this.imagePreview.push(reader.result);
            fArray.push(this.fb.group({ file: file[j], url: this.imagePreview[j] }))
            console.log(this.employeeForm.get("attachments").value)
          };

          reader.readAsDataURL(file[j]);
        }
        else {
          alert('your file size is too large, please select a file less than 450kb')
        }

      } else {
        //this.employeeForm.get('attachments')
        this.fileChosen = false
        if (fileName == ext) {
          alert(ext + ' is not a valid format')
          return fileName = ''
        }
        //this.file = null
      }
      //console.log(this.fileError)
      console.log(this.employeeForm.get("attachments").value)
    }
  }
  deleteFile(name) {
    console.log(this.employeeForm.get("attachments").value)
    const files = [...this.employeeForm.get("attachments").value]
    for (let i = 0; i < files.length; i++) {
      if (files[i].file.name == name) {
        const updatedFiles = files.filter((p) => {
          p.file.name != name
        })
      }
    }
    this.file = this.file.filter(p =>
      p != name)
    console.log(this.file)
    const arrayFiles = this.employeeForm.get("attachments") as FormArray
    const index = files.findIndex((p) => {
      p.file.name == name
    })
    arrayFiles.removeAt(index)
    console.log(this.employeeForm.get("attachments").value)
  }
  onSubmit() {
    if (this.employeeForm.valid) {
      this.employeeData.push(
        this.employeeForm.value)
      const fArray = this.employeeForm.get("attachments") as FormArray
      for (let i = fArray.length - 1; i >= 0; i--) {
        fArray.removeAt(i)
      }
      this.employeeForm.reset()
      this.file = []
      this.fileChosen = null
      console.log('submitted')
      console.log(this.employeeData)
    }
  }
  ngOnDestroy() {
    this.fileChosen = null
    this.file = null
  }
}
