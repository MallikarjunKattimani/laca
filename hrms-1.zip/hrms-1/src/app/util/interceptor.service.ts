import { HttpEvent, HttpHandler, HttpRequest, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ToasterService } from '../_helpers/toaster/toaster.service';
import { LocalStorageService } from './local-storage.service';

@Injectable({
  providedIn: 'root'
})
export class InterceptorService {
  constructor(private _ls: LocalStorageService, private _router: Router, private _toast: ToasterService) { }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    let currentUser = this._ls.getLoggedInUser("user",true);
    // console.log(currentUser);
      if (currentUser!=null) {
        if(currentUser.token){
          req = req.clone({
            setHeaders: {
                Authorization: "Bearer " + currentUser.token,
                'content-type': 'application/json',
                'Access-Control-Allow-Origin':'*'
            }
          });
        }
      }
      return next.handle(req).pipe(
        map((event: HttpEvent<any>) => {
            if (event instanceof HttpResponse) {
               event = event.clone({ body: this.handleResponse(event.body) });
            }
            return event;
        }));
  }
    /**
   * @private
   * @author P Swetha
   * @param {any} res
   * @description handling Http Response 
   * @returns json object
   * @memberof HttpInterceptor
   */
  private handleResponse(res) {
    const resJson = res;
    if (resJson.status) {
      if (resJson.message) {
        this._toast.show('success',resJson.message);
      }
    } else {
      if(resJson.Authentication != undefined){}
      else this._toast.show('error',resJson.message);
    }
    return resJson;
  }
}
