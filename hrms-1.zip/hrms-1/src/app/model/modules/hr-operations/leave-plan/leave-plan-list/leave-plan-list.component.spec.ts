import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LeavePlanListComponent } from './leave-plan-list.component';

describe('LeavePlanListComponent', () => {
  let component: LeavePlanListComponent;
  let fixture: ComponentFixture<LeavePlanListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LeavePlanListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LeavePlanListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
