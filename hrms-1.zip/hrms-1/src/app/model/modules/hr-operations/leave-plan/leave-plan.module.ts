import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LeavePlanListComponent } from './leave-plan-list/leave-plan-list.component';
import { LeavePlanRoutingModule } from './leave-plan-routing.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MaterialModule } from 'src/app/_helpers/material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';



@NgModule({
  declarations: [LeavePlanListComponent],
  imports: [
    CommonModule,
    LeavePlanRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule,
    NgbModule
  ]
})
export class LeavePlanModule { }
