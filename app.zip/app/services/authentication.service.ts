import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClientService } from '../util/http-client.service';
import { LocalStorageService } from '../util/local-storage.service';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  constructor(private _ls: LocalStorageService, private _http: HttpClientService) { }

  login(formData: any): Observable<any> {
    return this._http.post('/login', formData).pipe(
      map(data => {
        return data;
      }));
  }
  logout(params:any): Observable<any>{
    return this._http.post('/logout', params).pipe(
      map(data => {
        return data;
      }));
  }
}
