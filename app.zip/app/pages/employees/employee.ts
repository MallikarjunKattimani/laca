export interface Employee {
    id:string;
    title: string,
    content:string,
    gender:string
}
