import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeComponent } from './employee/employee.component';
import { Routes, RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EmployeeService } from './employee.service';
import { AddComponent } from './add/add.component';
import { EditComponent } from './edit/edit.component';

const router: Routes = [
  { path: '', component: EmployeeComponent },
  { path: 'add', component: AddComponent }
]

@NgModule({
  declarations: [EmployeeComponent, AddComponent, EditComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule.forChild(router)
  ],
  providers: [
    EmployeeService
  ]
})
export class EmployeesModule { }
