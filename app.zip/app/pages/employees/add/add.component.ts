import { Component, OnInit,ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
  @ViewChild('myForm') myForm: NgForm
  gender=['male','female']
  country ={title: '',content:'',gender:''}
  constructor(private router:Router, private countryService:EmployeeService) { }
  count:number
  ngOnInit() {
        
  }
  addDetails(){
this.countryService.addUser( this.myForm.value.title, this.myForm.value.content, this.myForm.value.gender)
  
 this.myForm.reset()
  }
close(){
  this.router.navigate(['/HR-operations/employee'])
}

}
