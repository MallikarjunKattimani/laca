import { Injectable } from '@angular/core';
import { Employee } from './employee';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw'
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  private _url = 'http://localhost:3000/api/usr'

  constructor(private http: HttpClient) { }

  private user:Employee[] = [];
  private updateUser = new Subject<Employee[] >();

  addUser(title: string, content: string, gender: string) {
    const user:Employee= { id: null, title: title, content: content, gender: gender };
    return this.http.post<any>(this._url, user).subscribe((resp => {
      console.log(resp)
      this.user.push(user);
      this.getUsers()
      this.updateUser.next([...this.user]);
    }), error => {
      this.errorHand(error);
      console.log(error)
    })
  }

  updateUserListener() {
    return this.updateUser.asObservable();
  }
  getUsers() {
    this.http
      .get<{ posts: any }>(
        this._url
      )
      .pipe(map((postData) => {
        return postData.posts.map(post => {
          return {
            title: post.title,
            content: post.content,
            id: post._id,
            gender: post.gender
          };
        });
      }))
      .subscribe((transformedPosts => {
        this.user = transformedPosts;
        console.log(this.user)
        this.updateUser.next([...this.user]);
      }), error => {
        this.errorHand(error);
        console.log(error)
      });
  }

  deleteUser(usersId) {
    this.http.delete(this._url + '/' + usersId)
      .subscribe((() => {
        const updatedPosts = this.user.filter(post => post.id !== usersId);
        this.user = updatedPosts;
        this.updateUser.next([...this.user]);
      }), error => {
        this.errorHand(error);
        console.log(error)
      });
  }
  editUser(  post: any) {
    const user1:Employee = { id: post.id, title: post.title, content: post.content, gender: post.gender }
    console.log(user1);
    this.http.put(this._url + '/' + post.id, user1).subscribe((res => {
      const userUpdate = [...this.user];

      const oldUserIndx = userUpdate.findIndex(p => p.id === post.id);
      userUpdate[oldUserIndx] = user1
      this.user = userUpdate;
      this.updateUser.next([...this.user]);
      console.log(this.user)
    }), error => {
      this.errorHand(error);
      console.log(error)
    })


  }
  errorHand(error: HttpErrorResponse) {
    console.log("Hi there  " + error.message)
    return Observable.throw(error.message || "server not  ")
  }
}
