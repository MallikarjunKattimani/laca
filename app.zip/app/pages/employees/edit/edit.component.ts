import { Component, OnInit, ViewChild, EventEmitter, Output } from '@angular/core';
import { NgForm } from '@angular/forms';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  @ViewChild('myForm') myForm:NgForm
  @Output('details') countryDetails=new EventEmitter()
edited= true
gender=['male','female']
country ={title: '',content:'',gender:''}
  constructor( ) { }

  ngOnInit() {
  }
editDetails(){
 this.countryDetails.emit( 
   this.country)
 this.edited =false
}
   

}
