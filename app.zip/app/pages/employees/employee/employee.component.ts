import { Component, OnInit,OnDestroy } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee';
import { Subscription } from 'rxjs';
import { Router } from '@angular/router';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit , OnDestroy {

  user:Employee[]=[]
  userSub:Subscription;
id
isOpen=false

  constructor( private userS:EmployeeService, private router:Router) { }

  ngOnInit() {
    this.userS.getUsers();
   this.userSub=this.userS.updateUserListener().subscribe((user:Employee[])=>{
     this.user=user
   })
  // console.log('OnInit called')
 }

 ngOnDestroy(){
   this.userSub.unsubscribe();
 }

 add(){
this.router.navigate(['/HR-operations/employee/add'])
 }
 onClose(){
  this.isOpen=false
 }
 edit( ){
  // this.id=id
   this.isOpen = true
 }
 delete(id){}
 updateDetails(data){
  //console.log(data)
  const details ={id:this.id,title:data.title,content:data.content,gender:data.gender}
  this.userS.editUser(details)
 }
}
