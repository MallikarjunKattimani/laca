import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClientService } from 'src/app/util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class LeavePlanService {
  subApiUrl = 'policy';

  constructor(private _http: HttpClientService) { }

  getPolicyList(params: any): Observable<any> {
    console.log(params);
    console.log('Policy  working ')
    return this._http.get(this.subApiUrl + '', params).pipe(
      map(data => {
        return data;
      }));
  }

  savePolicy(params: any): Observable<any>{
    console.log('asdfgbnhgfdsasdfgb')
    return this._http.post(this.subApiUrl + '', params).pipe(
      map(data => {
        return data;
      }));
  }

  updatePolicy(params: any, urlParams :any): Observable<any>{
    return this._http.put(this.subApiUrl + ''+'/'+urlParams, params).pipe(
      map(data => {
        return data;
      }));
  }

  deletePolicy(params: any): Observable<any>{
    return this._http.delete(this.subApiUrl + '/'+ params).pipe(
      map(data => {
        return data;
      }));
  }
}
