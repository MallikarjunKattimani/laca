import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-resources',
  templateUrl: './employee-resources.component.html',
  styleUrls: ['./employee-resources.component.css']
})
export class EmployeeResourcesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
