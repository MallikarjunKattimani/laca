import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeePolicyComponent } from './employee-policy/employee-policy.component';
import { EmployeeProjectComponent } from './employee-project/employee-project.component';
import { EmployeeRegisterComponent } from './employee-register/employee-register.component';
import { EmployeeResourcesComponent } from './employee-resources/employee-resources.component';
import { EmployeesListComponent } from './employees-list/employees-list.component';

const routes: Routes = [
  {
    path:'',
    redirectTo: 'list'
  },
  {
    path:'list',
    component: EmployeesListComponent    
  },
  {
    path:'register',
    component: EmployeeRegisterComponent,
    data:{
      breadcrumb :'Register Employee'
    }
  },
  {
    path:'policy',
    component: EmployeePolicyComponent
  },
  {
    path:'project',
    component: EmployeeProjectComponent
  },
  {
    path:'resources',
    component: EmployeeResourcesComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmployeeOnboardRoutingModule { }
