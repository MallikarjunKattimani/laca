import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LeavePlanListComponent } from './leave-plan-list/leave-plan-list.component';

const routes: Routes = [
  {
    path:'',
    component: LeavePlanListComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LeavePlanRoutingModule { }
