import { HttpParams } from '@angular/common/http';
import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CompanyService } from 'src/app/services/hr-operations/company.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-company-list',
  templateUrl: './company-list.component.html',
  styleUrls: ['./company-list.component.css']
})
export class CompanyListComponent implements OnInit {

  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['name','description', 'action'];
  dummyData=[]
  companiesList = new MatTableDataSource();
  filter: any = {searchKey: ''};
  companyForm : FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  closeResult : any;
  deleteCompany : any;
  modalHeader:string = '';
  submitted : boolean = false;


  constructor(private _service: CompanyService,
              public dialog: MatDialog,
              public _toast : ToasterService,
              private modalService: NgbModal) { }

  ngOnInit(): void {
    this.companyForm = new FormGroup({
      id : new FormControl(''),
      name : new FormControl('', [Validators.required,Validators.pattern('[-a-zA-Z ]{3,30}')]),
      description : new FormControl('',[Validators.required])
    });
    this.getAllCompanies();
  }

  getAllCompanies(event?: any, sorting?: any) {
    var params = {};
    params['size'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['number'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'id'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? sorting.direction : 'asc'; // be default sorting will be in Ascending order

    this._service.getCompanyList(params).subscribe(
      data => {
        this.companiesList = new MatTableDataSource(data);
        this.companiesList.sort = this.sort;
        this.pageSize = params['size'];
      });
    console.log(this.filter, "----");
  }
  applyFilter(event) {
    this.getAllCompanies();
  }
  sortTable(event) {
    console.log(event);
    this.getAllCompanies(null, event);
  }
  getCompanyId(){
    if(this.companyForm.value.id)
      return this.companyForm.value.id;
    else return 0;
  }
  /** 
   * Create ot update branch 
  */
  onSubmit(){
    this.dialog.closeAll();
    if(this.companyForm.valid){
      this.dummyData.push(this.companyForm.value)
      this.companiesList = new MatTableDataSource(this.dummyData)
      this.submitted = true;
      if(this.getCompanyId()>0){
        // update API call
        var params = new HttpParams();
        params.set('id',this.getCompanyId());
        this._service.updateCompany(this.companyForm.value,this.getCompanyId()).subscribe(data => {
          console.log(data);
          this.getAllCompanies();
        });
      }else{
        // create API call
        delete this.companyForm.value.id;
        this._service.saveCompany(this.companyForm.value).subscribe(data => {
          console.log(data);
          this.getAllCompanies();
        });
      }
      this.modalService.dismissAll();
    }else{
      this.submitted = false;
      this._toast.show('warn',"Please enter mandatory fields");
    }
  }
  open(content, type: boolean, company?) {
    this.modalHeader = type ? "Create": "Update";
    this.companyForm.reset();
    if (!type) {
      console.log("company--",company);
      this.companyForm.patchValue(company, { onlySelf: true });
    }
    this.modalService
      .open(content, {
        ariaLabelledBy: "modal-basic-title",
        windowClass: "my-class"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
        }
      );
  }
  openDelete(deleteConfirm, company?) {
    this.deleteCompany = company;
    this.modalService
      .open(deleteConfirm, {
        ariaLabelledBy: "modal-basic-title"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  onDeleteConfirmation() {
    this._service.deleteCompany(this.deleteCompany.id).subscribe(
      (data: any) => {
        this.getAllCompanies();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }

  // No need
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }

  public hasError = (controlName: string, errorName: string) =>{
    return this.companyForm.controls[controlName].hasError(errorName);
  }
}
