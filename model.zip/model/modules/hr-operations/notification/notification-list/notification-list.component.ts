import { HttpParams } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { NotificationService } from 'src/app/services/hr-operations/notification.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-notification-list',
  templateUrl: './notification-list.component.html',
  styleUrls: ['./notification-list.component.css']
})
export class NotificationListComponent implements OnInit {

  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  dummyData=[]
  tableHeaders: string[] = ['subject','description', 'action'];
  notificationList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  notificationForm: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  closeResult: any;
  deleteNotification: any;
  modalHeader: string = '';
  submitted: boolean = false;
  @ViewChild('closeModal', { static: true }) closeModal: ElementRef<HTMLElement>;

  constructor(private _service: NotificationService,
    public dialog: MatDialog,
    public _toast: ToasterService,
    private modalService: NgbModal) { }

  ngOnInit(): void {
    this.notificationForm = new FormGroup({
      id: new FormControl(''),
      subject: new FormControl('', [Validators.required,
                                    Validators.minLength(3),
                                    Validators.pattern('[-a-zA-Z ]*')]),
      description: new FormControl('')
    });
    this.getAllNotifications();
  }

  getAllNotifications(event?: any, sorting?: any) {
    var params = {};
    params['size'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['number'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'notificationId'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? sorting.direction : 'asc'; // be default sorting will be in Ascending order

    this._service.getNotificationList(params).subscribe(
      data => {
        this.notificationList = new MatTableDataSource(data);
        this.notificationList.sort = this.sort;
        this.pageSize = params['size'];
      });
    console.log(this.filter, "----");
  }
  applyFilter(event) {
    this.getAllNotifications();
  }
  sortTable(event) {
    console.log(event);
    this.getAllNotifications(null, event);
  }
  getNotificationId() {
    if (this.notificationForm.value.id)
      return this.notificationForm.value.id;
    else return 0;
  }
  /** 
   * Create ot update notification 
  */
  onSubmit() {    
    if (this.notificationForm.valid) {
      this.submitted = true;
      this.dummyData.push(this.notificationForm.value)
      this.notificationList = new MatTableDataSource(this.dummyData);
      if (this.getNotificationId() > 0) {
        // update API call
        var params = new HttpParams();
        params.set('id', this.getNotificationId());
        this._service.updateNotification(this.notificationForm.value, this.getNotificationId()).subscribe(data => {
          console.log(data);
          this.getAllNotifications();
        });
      } else {
        // create API call
        delete this.notificationForm.value.notificationId;
        this._service.saveNotification(this.notificationForm.value).subscribe(data => {
          console.log(data);
          this.getAllNotifications();
        });
      }
      this.modalService.dismissAll();
    } else {
      this.submitted = false;
      this._toast.show('warn', "Please enter mandatory fields");
    }

  }

  open(content, type: boolean, notification?) {
    this.modalHeader = type ? "Create": "Update";
    this.notificationForm.reset();
    if (!type) {
      console.log("notification--",notification);
      this.notificationForm.patchValue(notification, { onlySelf: true });
    }
    this.modalService
      .open(content, {
        ariaLabelledBy: "modal-basic-title",
        windowClass: "my-class"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
        }
      );
  }
  openDelete(deleteConfirm, notification?) {
    this.deleteNotification = notification;
    this.modalService
      .open(deleteConfirm, {
        ariaLabelledBy: "modal-basic-title"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  onDeleteConfirmation() {
    
    this._service.deleteNotification(this.deleteNotification.id).subscribe(
      (data: any) => {
        this.getAllNotifications();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }

  // No need
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }

  public hasError = (controlName: string, errorName: string) =>{
    return this.notificationForm.controls[controlName].hasError(errorName);
  }
}
