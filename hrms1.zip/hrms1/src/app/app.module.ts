import { BrowserModule } from '@angular/platform-browser';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';

import { HttpClientModule, HTTP_INTERCEPTORS, HttpClient } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { InterceptorService } from './util/interceptor.service';
import { HttpClientService, HttpClientServiceCreator } from './util/http-client.service';
import { UserLayoutComponent } from './layouts/user-layout/user-layout.component';
// import { OnboardLayoutComponent } from './layouts/onboard-layout/onboard-layout.component';
import { SideNavComponent } from './layouts/user-layout/side-nav/side-nav.component';
import { NavBarComponent } from './layouts/user-layout/nav-bar/nav-bar.component';
import { FooterComponent } from './layouts/user-layout/footer/footer.component';
import { MaterialModule } from './_helpers/material/material.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { PageNotFoundComponent } from './modules/page-not-found/page-not-found.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ToastrModule } from 'ngx-toastr';
import { BreadcrumbModule } from './_helpers/breadcrumb/breadcrumb.module';


@NgModule({
  declarations: [
    AppComponent,
    UserLayoutComponent,
    // OnboardLayoutComponent,
    SideNavComponent,
    NavBarComponent,
    FooterComponent,
    DashboardComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    HttpClientModule,
    MaterialModule,
    NgbModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot(),
    BreadcrumbModule
    // FlexLayoutModule,
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: InterceptorService, multi: true },
    { provide: HttpClientService, useFactory: HttpClientServiceCreator, deps: [HttpClient] }
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
