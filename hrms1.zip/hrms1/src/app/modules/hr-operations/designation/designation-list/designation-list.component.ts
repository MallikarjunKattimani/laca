import { HttpParams } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { DesignationService } from 'src/app/services/hr-operations/designation.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-designation-list',
  templateUrl: './designation-list.component.html',
  styleUrls: ['./designation-list.component.css']
})
export class DesignationListComponent implements OnInit {

  
  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['designation', 'skills','experiance', 'action'];
  designationList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  designationForm: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  closeResult: any;
  deleteDesignation: any;
  modalHeader: string = '';
  submitted: boolean = false;
  @ViewChild('closeModal', { static: true }) closeModal: ElementRef<HTMLElement>;

  constructor(private _service: DesignationService,
    public dialog: MatDialog,
    public _toast: ToasterService,
    private modalService: NgbModal) { }

  ngOnInit(): void {
    this.designationForm = new FormGroup({
      id: new FormControl(''),
      designation: new FormControl('', [Validators.required,Validators.minLength(3),Validators.pattern('[a-zA-Z ]*')]),
      skills: new FormControl('', [Validators.required,Validators.minLength(3),Validators.pattern('[a-zA-Z ,.]*')]),
      experiance: new FormControl('', [Validators.required,,Validators.minLength(1),Validators.pattern('[/^[0-9]+([,.][0-9]+)?$/]*')]),
    }); 
    this.getAllDesignations();
  }

  getAllDesignations(event?: any, sorting?: any) {
    var params = {};
    params['size'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['number'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'id'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? sorting.direction : 'asc'; // be default sorting will be in Ascending order

    this._service.getDesignationList(params).subscribe(
      data => {
        this.designationList = new MatTableDataSource(data);
        this.designationList.sort = this.sort;
        this.pageSize = params['size'];
      });
    console.log(this.filter, "----");
  }
  applyFilter(event) {
    this.getAllDesignations();
  }
  sortTable(event) {
    console.log(event);
    this.getAllDesignations(null, event);
  }
  getDesignationId() {
    if (this.designationForm.value.designationId)
      return this.designationForm.value.designationId;
    else return 0;
  }
  /** 
   * Create ot update designation
  */
  onSubmit() {    
    if (this.designationForm.valid) {
      this.submitted = true;
      if (this.getDesignationId() > 0) {
        // update API call
        var params = new HttpParams();
        params.set('id', this.getDesignationId());
        this._service.updateDesignation(this.designationForm.value, this.getDesignationId()).subscribe(data => {
          console.log(data);
          this.getAllDesignations();
        });
      } else {
        // create API call
        delete this.designationForm.value.designationId;
        this._service.saveDesignation(this.designationForm.value).subscribe(data => {
          console.log(data);
          this.getAllDesignations();
        });
      }
      this.modalService.dismissAll();
    } else {
      this.submitted = false;
      this._toast.show('warn', "Please enter mandatory fields");
    }

  }

  open(content, type: boolean, designation?) {
    this.modalHeader = type ? "Create": "Update";
    this.modalService
      .open(content, {
        ariaLabelledBy: "modal-basic-title",
        windowClass: "my-class"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
        }
      );
  }
  openDelete(deleteConfirm, designation?) {
    this.deleteDesignation = designation;
    this.modalService
      .open(deleteConfirm, {
        ariaLabelledBy: "modal-basic-title"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  onDeleteConfirmation() {
    this._service.deleteDesignation(this.deleteDesignation.id).subscribe(
      (data: any) => {
        this.getAllDesignations();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }

  // No need
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }

  public hasError = (controlName: string, errorName: string) =>{
    return this.designationForm.controls[controlName].hasError(errorName);
  }



}
