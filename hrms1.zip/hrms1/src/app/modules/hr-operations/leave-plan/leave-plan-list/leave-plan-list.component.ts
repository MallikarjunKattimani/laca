import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leave-plan-list',
  templateUrl: './leave-plan-list.component.html',
  styleUrls: ['./leave-plan-list.component.css']
})
export class LeavePlanListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
