import { HttpParams } from '@angular/common/http';
import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { MAT_MOMENT_DATE_ADAPTER_OPTIONS,
         MAT_MOMENT_DATE_FORMATS, 
         MomentDateAdapter} from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { HolidayService } from 'src/app/services/hr-operations/holiday.service';
import { ToasterService } from 'src/app/_helpers/toaster/toaster.service';

@Component({
  selector: 'app-holidays-list',
  templateUrl: './holidays-list.component.html',
  styleUrls: ['./holidays-list.component.css'],
  providers: [
    {provide: MAT_DATE_LOCALE, useValue: 'en-IN'},
    
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS]
    },
    {provide: MAT_DATE_FORMATS, useValue: MAT_MOMENT_DATE_FORMATS},
  ],
})
export class HolidaysListComponent implements OnInit {

  pageIndex = 0;
  pageSize = 10;
  totalRecords = 0;
  tableHeaders: string[] = ['name', 'date', 'action'];
  holidayList = new MatTableDataSource();
  filter: any = { searchKey: '' };
  holidayForm: FormGroup;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;


  closeResult: any;
  deleteHoliday: any;
  modalHeader: string = '';
  submitted: boolean = false;
  @ViewChild('closeModal', { static: true }) closeModal: ElementRef<HTMLElement>;

  minDate: Date;
  maxDate: Date;

  constructor(private _service: HolidayService,
    public dialog: MatDialog,
    public _toast: ToasterService,
    private modalService: NgbModal) {
      const currentYear = new Date().getFullYear();
      this.minDate = new Date(currentYear, 0, 1);
      this.maxDate = new Date(currentYear, 11, 31);
  }

  ngOnInit(): void {
    this.holidayForm = new FormGroup({
      id: new FormControl(''),
      name: new FormControl('', [Validators.required,Validators.minLength(3),Validators.pattern('[a-zA-Z]*')]),
      date: new FormControl( [Validators.required]),
    });
    this.getAllHolidays();
  }

  getAllHolidays(event?: any, sorting?: any) {
    var params = {};
    params['size'] = (event) ? event.pageSize : this.pageSize; // pagination page size
    params['number'] = (event) ? event.pageIndex : this.pageIndex; // pagination page number
    params['searchKey'] = this.filter.searchKey; // Search key filter
    params['sortBy'] = (sorting) ? sorting.active : 'holidayId'; // by Default id column will sorted
    params['orderBy'] = (sorting) ? sorting.direction : 'asc'; // be default sorting will be in Ascending order

    this._service.getHolidayList(params).subscribe(
      data => {
        this.holidayList = new MatTableDataSource(data);
        this.holidayList.sort = this.sort;
        this.pageSize = params['size'];
      });
    console.log(this.filter, "----");
  }
  applyFilter(event) {
    this.getAllHolidays();
  }
  sortTable(event) {
    console.log(event);
    this.getAllHolidays(null, event);
  }
  getHolidayId() {
    if (this.holidayForm.value.id)
      return this.holidayForm.value.id;
    else return 0;
  }
  /** 
   * Create ot update holiday
  */
  onSubmit() {    
    if (this.holidayForm.valid) {
      this.submitted = true;
      if (this.getHolidayId() > 0) {
        // update API call
        var params = new HttpParams();
        params.set('id', this.getHolidayId());
        this._service.updateHoliday(this.holidayForm.value, this.getHolidayId()).subscribe(data => {
          console.log(data);
          this.getAllHolidays();
        });
      } else {
        // create API call
        delete this.holidayForm.value.holidayId;
        this._service.saveHoliday(this.holidayForm.value).subscribe(data => {
          console.log(data);
          this.getAllHolidays();
        });
      }
      this.getAllHolidays();
      this.modalService.dismissAll();
    } else {
      this.submitted = false;
      this._toast.show('warn', "Please enter mandatory fields");
    }

  }

  open(content, type: boolean, holiday?) {
    this.modalHeader = type ? "Create": "Update";
    this.holidayForm.reset();
    if (!type) {
      console.log("holiday--",holiday);
      this.holidayForm.patchValue(holiday, { onlySelf: true });
    }
    
    this.modalService
      .open(content, {
        ariaLabelledBy: "modal-basic-title",
        windowClass: "my-class"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
        }
      );
  }
  openDelete(deleteConfirm, holiday?) {
    this.deleteHoliday = holiday;
    this.modalService
      .open(deleteConfirm, {
        ariaLabelledBy: "modal-basic-title"
      })
      .result.then(
        result => {
          this.closeResult = `Closed with: ${result}`;
        },
        reason => {
          this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
        }
      );
  }

  onDeleteConfirmation() {
    this._service.deleteHoliday(this.deleteHoliday.id).subscribe(
      (data: any) => {
        this.getAllHolidays();
        this.modalService.dismissAll("on fail");
      },
      (error: any) => {
        console.log(error);
        this.modalService.dismissAll("on fail");
      }
    );
  }

  // No need
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return "by pressing ESC";
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return "by clicking on a backdrop";
    } else {
      return `with: ${reason}`;
    }
  }

  public hasError = (controlName: string, errorName: string) =>{
    return this.holidayForm.controls[controlName].hasError(errorName);
  }

}
