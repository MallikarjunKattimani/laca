import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-project',
  templateUrl: './employee-project.component.html',
  styleUrls: ['./employee-project.component.css']
})
export class EmployeeProjectComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
