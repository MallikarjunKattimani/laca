import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { HttpClientService } from 'src/app/util/http-client.service';

@Injectable({
  providedIn: 'root'
})
export class EmployeeOnboardingService {

  constructor(private _http : HttpClientService) { }

  getEmployeesList(params:any): Observable<any> {
    console.log(params);
    return this._http.get('', params).pipe(
      map(data => {
        return data;
      }));
  }
}
