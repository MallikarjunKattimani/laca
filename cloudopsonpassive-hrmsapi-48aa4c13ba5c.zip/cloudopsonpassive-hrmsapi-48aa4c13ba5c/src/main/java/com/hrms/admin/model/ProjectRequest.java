package com.hrms.admin.model;

public class ProjectRequest {
	
	private String name;
	private String description;
	
	public ProjectRequest() {

	}

	public ProjectRequest(String name, String description) {
		super();
		this.name = name;
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getdescription() {
		return description;
	}

	public void setdescription(String description) {
		this.description = description;
	}
	
	

}
