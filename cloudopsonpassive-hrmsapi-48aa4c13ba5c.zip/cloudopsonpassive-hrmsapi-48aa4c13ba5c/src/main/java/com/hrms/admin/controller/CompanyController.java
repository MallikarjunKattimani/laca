package com.hrms.admin.controller;

import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.exceptions.CompanyNotFoundException;
import com.hrms.admin.exceptions.Response;
import com.hrms.admin.model.CompanyRequest;
import com.hrms.admin.response.CompanyResponse;
import com.hrms.admin.service.CompanyService;
import com.hrms.admin.util.Constants;
/**
 * Contains method to provide APIs for Company Record
 * 
 * @author {Benarji}
 *
 */

@RestController
@RequestMapping("/admin/company")
@CrossOrigin
public class CompanyController {
	private static final Logger logger = LoggerFactory.getLogger(CompanyController.class);

	@Autowired
	private CompanyService service;
	/**
	 * Returns status code when new company is created
	 * 
	 * @param model - new company data
	 * @return - ResponseEntity
	 */

	@PostMapping
	public ResponseEntity<Response> add(@RequestBody CompanyRequest model) {
		try {
			service.save(model);
			logger.debug("Company Added :: " + model);
			return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.INSERT_SUCCESS,Constants.TRUE), HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Error while adding Company :: ", e);
			return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	/**
	 * Returns status code when existing company data is updated
	 * 
	 * @param model - new company data
	 * @param id    - company Id
	 * @return - ResponseEntity
	 */
	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody CompanyRequest model, @PathVariable Long id) {
		
		boolean updateCompany = service.updateCompany(model, id);
		if (updateCompany) {
			logger.debug("Company ID = " + id + " is updated :: " + model);
			return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} else {
			logger.error("Error while updating Company :: ");
			return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
		}
	}
	/**
	 * Returns Company and status code when company data is available by id
	 * 
	 * @param id - company Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<CompanyResponse> getById(@PathVariable Long id) {

		try {
			CompanyResponse companyById = service.getById(id);
			logger.debug("Company fond with ID = " + id + " " + companyById);
			return new ResponseEntity<CompanyResponse>(companyById, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Company by Id :: " + id);
			throw new CompanyNotFoundException("Company");
		}
	}
	/**
	 * Returns Company data and status code when company data is available by
	 * name
	 * 
	 * @param name - company name
	 * @return - ResponseEntity
	 */
	@GetMapping("/name/{name}")
	public ResponseEntity<CompanyResponse> getByName(@PathVariable String name) {

		try {
			CompanyResponse companyByName = service.getByName(name);
			logger.debug("Company fond with Name = " + name + " " + companyByName);
			return new ResponseEntity<CompanyResponse>(companyByName, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Company by name :: " + name);
			throw new CompanyNotFoundException("Company not found");
		}

	}
	/**
	 * Returns All Company data when company data is available
	 * 
	 * @return - List of CompanyModel
	 */
	@GetMapping
	public List<CompanyResponse> getAll() {
		List<CompanyResponse> allCompany = service.getAllCompany();
		if (allCompany != null) {
			logger.debug("Found " + allCompany.size() + "Company");
			return allCompany;
		}
		logger.error("error while getting all Company Record");
		throw new CompanyNotFoundException("Company not found");
	}
	/**
	 * Returns status code when company data is deleted
	 * 
	 * @param id - company id
	 * @return - ResponseEntity
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<Response> delete(@PathVariable Long id) {
		
			CompanyResponse company = service.getById(id);
			if(!Objects.isNull(company)) {
				service.deleteCompany(id);
				logger.debug("Company record is Deleted with id " + id);
				return new ResponseEntity<Response>(new Response(company.getCompanyName()+" "+Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
			}else {
				logger.debug("Company not exist ");
				return new ResponseEntity<Response>(new Response("Company " +" "+Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.NO_CONTENT);
			}
	}


}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

