package com.hrms.admin.service;

import java.math.BigInteger;
import java.util.List;
import com.hrms.admin.model.NotificationRequest;
import com.hrms.admin.response.NotificationResponse;



public interface NotificationService {
	
	public boolean save(NotificationRequest model);

	public List<NotificationResponse> getAllNotifications();

	public NotificationResponse getById(BigInteger id);
	
	public NotificationResponse getBySubject(String subject);

	public boolean deleteNotification(BigInteger id);

	public boolean updateNotification(NotificationRequest model, BigInteger id);


}
