package com.hrms.admin.model;

public class DepartmentRequest {
	
	private String name;
	private String descriptions;
	
	public DepartmentRequest() {
	}

	public DepartmentRequest(String name, String descriptions) {
		this.name = name;
		this.descriptions = descriptions;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescriptions() {
		return descriptions;
	}

	public void setDescriptions(String descriptions) {
		this.descriptions = descriptions;
	}	
}
