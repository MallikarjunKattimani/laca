package com.hrms.admin.util;

import com.hrms.admin.model.CompanyRequest;

public class CompanyUtil {
	public static void copyNonNullValues(CompanyRequest req, CompanyRequest db) {

		if (req.getId() != null) {
			db.setId((req.getId()));
		}
		if (req.getName() != null) {
			db.setName(req.getName());
		}
		if (req.getDescription() != null) {
			db.setDescription(req.getDescription());

		}
		

	}
}
