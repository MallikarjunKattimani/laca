package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.model.PolicyRequest;
import com.hrms.admin.response.PolicyResponse;

public interface PolicyService {

	public boolean save(PolicyRequest model);

	public List<PolicyResponse> getAllPolicy();

	public PolicyResponse getPolicyById(Long id);

	public PolicyResponse getPolicyByName(String name);

	public boolean deletePolicy(Long id);

	public boolean update(PolicyRequest policyModel, Long id);

}
