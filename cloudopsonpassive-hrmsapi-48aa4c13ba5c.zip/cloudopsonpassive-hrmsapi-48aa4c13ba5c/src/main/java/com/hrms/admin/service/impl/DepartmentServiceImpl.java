package com.hrms.admin.service.impl;

import java.math.BigInteger;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Department;
import com.hrms.admin.model.DepartmentRequest;
import com.hrms.admin.response.DepartmentResponse;
import com.hrms.admin.repository.DepartmentRepository;
import com.hrms.admin.service.DepartmentService;
/**
 * Contains method to perform DB operation on Department Record
 * @author {Prabhat}
 *
 */
@Service
public class DepartmentServiceImpl implements DepartmentService {

	private static final Logger logger = LoggerFactory.getLogger(DepartmentServiceImpl.class);

	@Autowired
	private DepartmentRepository repo;

    /**
     * Returns true when new department is store in database
     * 
     * @param model - new department data
     * @return - boolean
     */
	@Override
	public boolean save(DepartmentRequest model) {
		boolean flag = Boolean.FALSE;
		Department entity = new Department();
		BeanUtils.copyProperties(model, entity);
		//setting values
		entity.setName(model.getName());
		entity.setDescription(model.getDescriptions());
		entity.setCreatedBy("abc");
		entity.setUpdatedBy("abc");
		Department d=repo.save(entity);
		if(!Objects.isNull(d)) 
			flag = Boolean.TRUE;
		logger.debug("Department Added into database :: " + entity);
		return flag;
	}

    /**
     * Returns true when existing department data is store in database
     * 
     * @param model - new department data
     * @param id - depatment Id
     * @return - boolean
     */
	@Override
	public boolean updateDepartment(DepartmentRequest model, BigInteger id) {
		boolean flag = Boolean.FALSE;
		Optional<Department> findById = repo.findById(id);
		if (findById.isPresent()) {
			Department oldDepartment = findById.get();
			oldDepartment.setName(model.getName());
			oldDepartment.setDescription(model.getDescriptions());
			oldDepartment.setCreatedBy("abc");
			oldDepartment.setUpdatedBy("abc");
			Department d =repo.save(oldDepartment);
			if(!Objects.isNull(d))
				flag = Boolean.TRUE;
			logger.debug("Department ID = " + id + " is updated in to database :: " + oldDepartment);
			return flag;
		} else {
			logger.error("Department is not available in to database with ID= " + id);
			return flag;
		}
	}

    /**
     * Returns Department data when department data is available in database by id
     * @param id - depatment Id
     * @return - DepartmentModel
     */
	@Override
	public DepartmentResponse getById(BigInteger id) {
		Optional<Department> optionalEntity = repo.findById(id);
		Department departmentEntity = optionalEntity.get();
		DepartmentResponse model = new DepartmentResponse();
		BeanUtils.copyProperties(departmentEntity, model);
		logger.debug("Department found with ID = " + id + " " + departmentEntity);
		return model;
	}

    /**
     * Returns Department data when department data is available in database by name
     * @param name - depatment name
     * @return - DepartmentModel
     */
	@Override
	public DepartmentResponse getByName(String name) {
		Department findByDepartmentName = repo.findByname(name);
		DepartmentResponse model = new DepartmentResponse();
		BeanUtils.copyProperties(findByDepartmentName, model);
		logger.debug("Department found with Name = " + name + " " + findByDepartmentName);
		return model;
	}

    /**
     * Returns All Department data when department data is available in database
     * @return - List of DepartmentModel
     */
	@Override
	public List<DepartmentResponse> getAllDepartment() {
	
		List<Department> allDepartment = repo.findAll();
		List<DepartmentResponse> models = allDepartment.stream().map(entity -> {
			DepartmentResponse model = new DepartmentResponse();
			BeanUtils.copyProperties(entity, model);
			return model;
		}).collect(Collectors.toList());

		return models;
	}

    /**
     * Returns true when department data is deleted from database by id
     * @param id - depatment id
     * @return - boolean
     */
	@Override
	public boolean deleteDepartment(BigInteger id) {
		repo.deleteById(id);
		logger.debug(" Department record is deleted from database ");
		return true;

	}
}