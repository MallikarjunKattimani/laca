package com.hrms.admin.exceptions;

import java.util.Date;

public class NotificationSuccessResponse {
	private Date timestamp;
	  private String message;
	public NotificationSuccessResponse(Date timestamp, String message) {
		super();
		this.timestamp = timestamp;
		this.message = message;
	}
	public Date getTimestamp() {
		return timestamp;
	}
	
	public String getMessage() {
		return message;
	}

	  
}
