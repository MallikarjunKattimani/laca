package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.model.BranchRequest;
import com.hrms.admin.response.BranchResponse;

public interface BranchService {
	
	public boolean save(BranchRequest branch);

	public List<BranchResponse> getAllBranch();

	public BranchResponse getById(Long id);

	public boolean deleteBranch(Long id);

	public boolean updateBranch(BranchRequest model, Long id);

}
