package com.hrms.admin.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.Attendance;
import com.hrms.admin.response.AttendanceResponse;

@Repository
public interface AttendancesRepository extends JpaRepository<Attendance, Long> {
	
   public AttendanceResponse findBycompanyName(String companyName);
	
	Page<Attendance> findAll(Pageable paging);
	
	/* @Modifying */
	/*@Query("UPDATE Product SET prodCode=:code WHERE id=:id")
	Integer updateProductCodeById(String code,Integer id);*/


}
