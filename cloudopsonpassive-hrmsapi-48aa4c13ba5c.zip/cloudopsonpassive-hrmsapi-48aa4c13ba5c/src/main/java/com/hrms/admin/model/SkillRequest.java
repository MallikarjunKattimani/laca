package com.hrms.admin.model;

public class SkillRequest {

	private String skillSet;
	private String description;
	
	public SkillRequest() {
	}

	public String getSkillSet() {
		return skillSet;
	}

	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}

	public String getDescriptions() {
		return description;
	}

	public void setDescriptions(String descriptions) {
		this.description = descriptions;
	}
	
	
}