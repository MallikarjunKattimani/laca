 package com.hrms.admin.controller;

import java.math.BigInteger;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.exceptions.NotificationNotFoundException;
import com.hrms.admin.exceptions.Response;
import com.hrms.admin.model.NotificationRequest;
import com.hrms.admin.response.NotificationResponse;
import com.hrms.admin.service.NotificationService;
import com.hrms.admin.util.Constants;

@RestController
@CrossOrigin
@RequestMapping("/admin/notification")
public class NotificationController {

	private static final Logger logger = LoggerFactory.getLogger(NotificationController.class);
	
	@Autowired
	private NotificationService service;
	/**
	 * Returns status code when new notification is created
	 * 
	 * @param model - new notification data
	 * @return - ResponseEntity
	 */
	@PostMapping
	public ResponseEntity<Response> add(@RequestBody NotificationRequest model) {
		try {
			service.save(model);
			logger.debug("Notification Added :: " + model);
			return new ResponseEntity<Response>(new Response(model.getSubject()+" "+Constants.INSERT_SUCCESS,Constants.TRUE), HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Error while adding Notification :: ", e);
			return new ResponseEntity<Response>(new Response(model.getSubject()+" "+Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}
	/**
	 * Returns status code when existing notification data is updated
	 * 
	 * @param model - new notification data
	 * @param id    - notification Id
	 * @return - ResponseEntity
	 */
	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody NotificationRequest model, @PathVariable BigInteger id) {

		boolean updateNotification = service.updateNotification(model, id);
		if (updateNotification) {
			logger.debug("Notification ID = " + id + " is updated :: " + model);

			return new ResponseEntity<Response>(new Response(model.getSubject()+" "+Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);

		} else {
			logger.error("Error while updating Notification :: ");
			return new ResponseEntity<Response>(new Response(model.getSubject()+" "+Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
		}
	}
	/**
	 * Returns Department and status code when notification data is available by id
	 * 
	 * @param id - notification Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<NotificationResponse> getById(@PathVariable BigInteger id) {

		try {
			NotificationResponse notificationById = service.getById(id);
			logger.debug("Notification fond with ID = " + id + " " + notificationById);
			return new ResponseEntity<NotificationResponse>(notificationById, HttpStatus.OK);

		} catch (Exception e) {
			logger.error("Error while getting Notification by Id :: " + id);
			throw new NotificationNotFoundException("notification is not available for Id ::" + id);
		}

	}
	/**
	 * Returns Department data and status code when department data is available by
	 * name
	 * 
	 * @param subject - subject
	 * @return - ResponseEntity
	 */
	@GetMapping("/{subject}")
	public ResponseEntity<NotificationResponse> getBySubject(@PathVariable String subject) {

		try {
			NotificationResponse notificationBySubject = service.getBySubject(subject);
			logger.debug("Notification fond with subject = " + subject + " " + notificationBySubject);
			return new ResponseEntity<NotificationResponse>(notificationBySubject, HttpStatus.OK);
		} catch (Exception e) {
			throw new NotificationNotFoundException("notification is not available for Subject :: " + subject);
		}

	}
	/**
	 * Returns All Notifications data when department data is available
	 * 
	 * @return - List of DepartmentModel
	 */
	@GetMapping
	public List<NotificationResponse> getNotificationlist() {
		List<NotificationResponse> allNotification = service.getAllNotifications();
		if (allNotification != null) {
			logger.debug("Found " + allNotification.size() + " Notification");
			return allNotification;
		}
		logger.error("error while getting all Notification Record");
		throw new NotificationNotFoundException("Notification not found");
	}
	/**
	 * Returns status code when notification data is deleted
	 * 
	 * @param id - notification id
	 * @return - ResponseEntity
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<Response> deleteNotification(@PathVariable BigInteger id) {
		NotificationResponse notification = service.getById(id);
		if(!Objects.isNull(notification)) {
			service.deleteNotification(id);
			logger.debug("Notification record is Deleted with id " + id);
			return new ResponseEntity<Response>(new Response(notification.getSubject()+" "+Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		}else {
			logger.debug("Notification not exist ");
			return new ResponseEntity<Response>(new Response("Notification " +" "+Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.NO_CONTENT);
		}
	}
	
}