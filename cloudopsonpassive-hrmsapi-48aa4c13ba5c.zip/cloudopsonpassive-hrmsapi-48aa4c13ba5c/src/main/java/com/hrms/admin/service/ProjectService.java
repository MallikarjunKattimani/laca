package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.entity.Project;
import com.hrms.admin.model.ProjectRequest;
import com.hrms.admin.response.ProjectResponse;

public interface ProjectService {
	
	
	
	public boolean save(ProjectRequest model);
	
	public List<ProjectResponse> getAllProject(); 
	
	public ProjectResponse getById(Long id); 
	
	public ProjectResponse getByName(String name);
	
	public boolean deleteProject(Long id);

	public List<Project> getAllProjectAccToPaging(Integer pageNo, Integer pageSize, String sortBy); 
	
	public boolean updateProject(ProjectRequest model, Long id);  
	

}
