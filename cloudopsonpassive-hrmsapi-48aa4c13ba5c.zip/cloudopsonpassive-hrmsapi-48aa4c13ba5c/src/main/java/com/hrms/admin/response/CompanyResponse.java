package com.hrms.admin.response;

public class CompanyResponse {

	private Long id;
	private String companyName;
	private String description;

	public CompanyResponse() {

	}

	public CompanyResponse(Long id, String companyName, String description) {
		super();
		this.id = id;
		this.companyName = companyName;
		this.description = description;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	@Override
	public String toString() {
		return "CompanyResponse [id=" + id + ", companyName=" + companyName + ", description=" + description + "]";
	}

	

}
