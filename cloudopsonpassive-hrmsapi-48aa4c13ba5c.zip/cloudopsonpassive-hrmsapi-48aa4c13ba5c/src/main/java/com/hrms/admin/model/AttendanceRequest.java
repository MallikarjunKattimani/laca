package com.hrms.admin.model;

import java.time.LocalDateTime;

public class AttendanceRequest {
	
	private String companyName;
	private String branchName;
	
	private LocalDateTime inTime;
	private LocalDateTime  outTime;
	public AttendanceRequest() {
		
	}
	public AttendanceRequest(String companyName, String branchName, LocalDateTime inTime, LocalDateTime outTime) {
		super();
		this.companyName = companyName;
		this.branchName = branchName;
		this.inTime = inTime;
		this.outTime = outTime;
	}
	public String getCompanyName() {
		return companyName;
	}
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}
	public String getBranch() {
		return branchName;
	}
	public void setBranch(String branchName) {
		this.branchName = branchName;
	}
	public LocalDateTime getInTime() {
		return inTime;
	}
	public void setInTime(LocalDateTime inTime) {
		this.inTime = inTime;
	}
	public LocalDateTime getOutTime() {
		return outTime;
	}
	public void setOutTime(LocalDateTime outTime) {
		this.outTime = outTime;
	}
	
	
}
