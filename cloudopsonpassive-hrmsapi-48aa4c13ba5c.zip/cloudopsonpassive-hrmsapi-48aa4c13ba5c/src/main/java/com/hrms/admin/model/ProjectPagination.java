package com.hrms.admin.model;

public class ProjectPagination {
	
	private Integer pageNo;  
	private Integer pageSize;
	private String sortBy;
	
	
	public ProjectPagination() {
	
	}

	public ProjectPagination(Integer pageNo, Integer pageSize, String sortBy) {
		super();
		this.pageNo = pageNo;
		this.pageSize = pageSize;
		this.sortBy = sortBy;
	}

	public Integer getPageNo() {
		return pageNo;
	}

	public void setPageNo(Integer pageNo) {
		this.pageNo = pageNo;
	}

	public Integer getPageSize() {
		return pageSize;
	}

	public void setPageSize(Integer pageSize) {
		this.pageSize = pageSize;
	}

	public String getSortBy() {
		return sortBy;
	}

	public void setSortBy(String sortBy) {
		this.sortBy = sortBy;
	}
	
	
	
}
