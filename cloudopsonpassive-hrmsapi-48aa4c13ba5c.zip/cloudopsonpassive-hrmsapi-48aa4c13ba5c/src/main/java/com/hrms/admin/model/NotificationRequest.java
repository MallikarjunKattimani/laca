package com.hrms.admin.model;

public class NotificationRequest {
	
	private String subject;

	private String description;
	
	public NotificationRequest() {
	}

	public NotificationRequest(String subject, String descriptions) {
		super();
		this.subject = subject;
		this.description = descriptions;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}

	