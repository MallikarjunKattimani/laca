package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.model.CompanyRequest;
import com.hrms.admin.response.CompanyResponse;

public interface CompanyService {

	
	public boolean save(CompanyRequest model);
	
	public List<CompanyResponse> getAllCompany();

	public CompanyResponse getById(Long id);

	public CompanyResponse getByName(String name);
	
	public boolean deleteCompany(Long id);
	
	public boolean updateCompany(CompanyRequest model, Long id);

	/**
	 * Returns Department data when company data is available in database by id
	 * @param id - company Id
	 * @return - CompanyModel
	 */

	/*
	 * public List<CompanyResponse> getAllCompanyAccToPaging(Integer pageNo, Integer
	 * pageSize, String sortBy);
	 * 
	 *//**
		 * It returns the List of Company based on seach
		 *//*
			 * //public List<CompanyResonseModel> listAll(String keyword);
			 */

}
