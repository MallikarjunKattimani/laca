package com.hrms.admin.entity;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name ="ATTENDANCE")
public class Attendance {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "ID")
	private Long id;
	
	@Column(name = "COMPANYNAME")
	private String companyName;
	
	@Column(name = "BRANCHNAME")
	private String branchName;
	
	@Column(name = "IN_TIME", columnDefinition = "TIMESTAMP")
	private LocalDateTime inTime;
	
	@Column(name = "OUT_TIME", columnDefinition = "TIMESTAMP")
	private LocalDateTime outTime;
	
	@Column(name = "CREATED_DATE", columnDefinition = "TIMESTAMP")
	private LocalDateTime createDate;
	
	@Column(name = "CREATED_BY")
	private String createdBy;
	
	@Column(name = "UPDATED_DATE", columnDefinition = "TIMESTAMP")
	private LocalDateTime updateDate;
	
	@Column(name = "UPDATED_BY")
	private String updatedBy;
	
	

	public Attendance() {
		
	}



	public Long getId() {
		return id;
	}



	public void setId(Long id) {
		this.id = id;
	}



	public String getCompanyName() {
		return companyName;
	}



	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}



	public String getBranchName() {
		return branchName;
	}



	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}



	public LocalDateTime getInTime() {
		return inTime;
	}



	public void setInTime(LocalDateTime inTime) {
		this.inTime = inTime;
	}



	public LocalDateTime getOutTime() {
		return outTime;
	}



	public void setOutTime(LocalDateTime outTime) {
		this.outTime = outTime;
	}



	public LocalDateTime getCreateDate() {
		return createDate;
	}



	public void setCreateDate(LocalDateTime createDate) {
		this.createDate = createDate;
	}



	public String getCreatedBy() {
		return createdBy;
	}



	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}



	public LocalDateTime getUpdateDate() {
		return updateDate;
	}



	public void setUpdateDate(LocalDateTime updateDate) {
		this.updateDate = updateDate;
	}



	public String getUpdatedBy() {
		return updatedBy;
	}



	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}



	public Attendance(Long id, String companyName, String branchName, LocalDateTime inTime, LocalDateTime outTime,
			LocalDateTime createDate, String createdBy, LocalDateTime updateDate, String updatedBy) {
		super();
		this.id = id;
		this.companyName = companyName;
		this.branchName = branchName;
		this.inTime = inTime;
		this.outTime = outTime;
		this.createDate = createDate;
		this.createdBy = createdBy;
		this.updateDate = updateDate;
		this.updatedBy = updatedBy;
	}



	@Override
	public String toString() {
		return "Attendance [id=" + id + ", companyName=" + companyName + ", branchName=" + branchName + ", inTime="
				+ inTime + ", outTime=" + outTime + ", createDate=" + createDate + ", createdBy=" + createdBy
				+ ", updateDate=" + updateDate + ", updatedBy=" + updatedBy + "]";
	}



	


	
}
