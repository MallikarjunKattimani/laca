package com.hrms.admin.controller;

import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.exceptions.BranchNotFoundException;
import com.hrms.admin.exceptions.Response;
import com.hrms.admin.model.BranchRequest;
import com.hrms.admin.response.BranchResponse;
import com.hrms.admin.service.BranchService;
import com.hrms.admin.util.Constants;

@RestController
@CrossOrigin
@RequestMapping("/admin/branch")
public class BranchController {

	private static final Logger logger = LoggerFactory.getLogger(BranchController.class);

	@Autowired
	private BranchService service;

//	@Autowired
//	private  BranchUtil util;
//	

	/**
	 * Returns status code when new branch is created
	 * 
	 * @param model - new branch data
	 * @return - ResponseEntity
	 */

	@PostMapping
	public ResponseEntity<Response> add(@RequestBody BranchRequest model) {
		try {
			service.save(model);
			logger.debug("Branch Added :: " + model);
			return new ResponseEntity<Response>(
					new Response("Branch " + " " + Constants.INSERT_SUCCESS, Constants.TRUE), HttpStatus.CREATED);

		} catch (Exception e) {
			logger.error("Error while adding branch :: ", e);
			return new ResponseEntity<Response>(new Response("Branch " + " " + Constants.INSERT_FAIL, Constants.FALSE),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	/**
	 * Returns All Department data when branch data is available
	 * 
	 * @return - List of BranchResponseModel
	 */
	@GetMapping
	public List<BranchResponse> getAll() {
		List<BranchResponse> allBranch = service.getAllBranch();
		if (allBranch != null) {
			logger.debug("Found " + allBranch.size() + " Branch");
			return allBranch;
		}
		logger.error("error while getting all Branch Record");
		throw new BranchNotFoundException("Branch not found");
	}

	/**
	 * Returns branch and status code when branch data is available by id
	 * 
	 * @param id - branch Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<BranchResponse> getById(@PathVariable Long id) {

		try {
			BranchResponse branchById = service.getById((id));
			logger.debug("Branch fond with ID = " + id + " " + branchById);
			return new ResponseEntity<BranchResponse>(branchById, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Branch by Id :: " + id);
			throw new BranchNotFoundException("Branch");
		}
	}

	/**
	 * Returns status code when existing branch data is updated
	 * 
	 * @param model - new branch data
	 * @param id    - branch Id
	 * @return - ResponseEntity
	 */
	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody BranchRequest model, @PathVariable Long id) {

		boolean updateDepartment = service.updateBranch(model, id);
		if (updateDepartment) {
			logger.debug("Branch ID = " + id + " is updated :: " + model);
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.UPDATE_SUCCESS, Constants.TRUE),
					HttpStatus.OK);
		} else {
			logger.error("Error while updating Branch :: ");
			return new ResponseEntity<Response>(
					new Response(model.getName() + " " + Constants.UPDATE_FAIL, Constants.FALSE),
					HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * Returns status code when branch data is deleted
	 * 
	 * @param id - branch id
	 * @return - ResponseEntity
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<Response> delete(@PathVariable Long id) {

		BranchResponse branch = service.getById(id);
		if (!Objects.isNull(branch)) {
			service.deleteBranch(id);
			logger.debug("Branch record is Deleted with id " + id);
			return new ResponseEntity<Response>(
					new Response(branch.getName() + " " + Constants.DELETE_SUCCESS, Constants.TRUE),
					HttpStatus.OK);
		} else {
			logger.debug("Branch not exist ");
			return new ResponseEntity<Response>(new Response("Branch " + " " + Constants.DELETE_FAIL, Constants.FALSE),
					HttpStatus.NO_CONTENT);
		}
	}
}
