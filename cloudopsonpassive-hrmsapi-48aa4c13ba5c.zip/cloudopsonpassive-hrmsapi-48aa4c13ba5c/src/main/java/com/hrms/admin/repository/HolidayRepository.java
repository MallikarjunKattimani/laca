package com.hrms.admin.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.Holiday;

public interface HolidayRepository extends JpaRepository<Holiday, Long> {

	public Holiday findByname(String name);

}