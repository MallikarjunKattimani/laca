package com.hrms.admin.repository;

import java.math.BigInteger;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.Notification;



public interface NotificationRepository extends JpaRepository<Notification, BigInteger> {
	
	public Notification findBysubject(String subject);
	
	
	Page<Notification> findAll(Pageable paging);

}
