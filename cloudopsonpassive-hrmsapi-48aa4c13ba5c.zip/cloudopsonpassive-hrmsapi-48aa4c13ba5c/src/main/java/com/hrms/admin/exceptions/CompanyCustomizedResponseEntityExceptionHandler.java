package com.hrms.admin.exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.hrms.admin.util.Constants;
@ControllerAdvice
@RestController
public class CompanyCustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {
	@ExceptionHandler(Exception.class)
	  public final ResponseEntity<Response> handleAllExceptions(Exception ex, WebRequest request) {
		  return new ResponseEntity<Response>(new Response(ex.getMessage()+" "+Constants.INSERT_FAIL,Constants.FALSE), HttpStatus.BAD_REQUEST);
	  }

	  @ExceptionHandler(CompanyNotCreatedExceptions.class)
	  public final ResponseEntity<CompanyExceptionResponse> handleCompanyNotFoundException(CompanyNotFoundException ex, WebRequest request) {
		  CompanyExceptionResponse companyExceptionResponse = new CompanyExceptionResponse(new Date(), ex.getMessage(),
	        request.getDescription(false));
	    return new ResponseEntity<>(companyExceptionResponse, HttpStatus.NOT_FOUND);
	  }

	  @ExceptionHandler(CompanyNotFoundException.class)
	  public final ResponseEntity<Response> handleCompanyNotCreatedException(CompanyNotCreatedExceptions ex) {
		  return new ResponseEntity<Response>(new Response(
				  ex.getMessage()+" "+Constants.INSERT_FAIL,
				  Constants.FALSE),
				  HttpStatus.BAD_REQUEST);
	  }
	

}
