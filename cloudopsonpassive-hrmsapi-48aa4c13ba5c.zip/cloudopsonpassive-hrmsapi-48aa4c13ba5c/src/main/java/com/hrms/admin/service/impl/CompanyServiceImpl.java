package com.hrms.admin.service.impl;

import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Company;
import com.hrms.admin.model.CompanyRequest;
import com.hrms.admin.response.CompanyResponse;
import com.hrms.admin.repository.CompanyRepository;
import com.hrms.admin.service.CompanyService;

@Service
public class CompanyServiceImpl implements CompanyService {
	private static final Logger logger = LoggerFactory.getLogger(CompanyServiceImpl.class);

	@Autowired
	private CompanyRepository companyRepository;
	
	 /**
     * Returns true when new company is store in database
     * 
     * @param model - new company data
     * @return - boolean
     */
	@Override
	public boolean save(CompanyRequest model) {
		boolean flag = Boolean.FALSE;
		Company entity = new Company();
		BeanUtils.copyProperties(model, entity);
		//setting values
		entity.setName(model.getName());
		entity.setDescription(model.getDescription());
		entity.setCreatedBy("abc");
		entity.setUpdatedBy("abc");
		Company c=companyRepository.save(entity);
		if(!Objects.isNull(c)) 
			flag = Boolean.TRUE;
		logger.debug("Department Added into database :: " + entity);
		return flag;
	}
	
	 /**
     * Returns All Department data when company data is available in database
     * @return - List of CompanytModel
     */

	@Override
	public List<CompanyResponse> getAllCompany() {
		List<Company> allCompany = companyRepository.findAll();
		List<CompanyResponse> models = allCompany.stream().map(entity -> {
			CompanyResponse model = new CompanyResponse();
			BeanUtils.copyProperties(entity, model);
			return model;
		}).collect(Collectors.toList());

		return models;	}
    	
    /**
     * Returns Department data when company data is available in database by id
     * @param id - company Id
     * @return - CompanyModel
     */
	@Override
	public CompanyResponse getById(Long id) { 
		Optional<Company> optionalEntity = companyRepository.findById(id);
		Company companyEntity = optionalEntity.get();
		CompanyResponse model = new CompanyResponse();
		BeanUtils.copyProperties(companyEntity, model);
		logger.debug("Company found with ID = " + id + " " + companyEntity);
		return model;
		
	}
	/**
     * Returns Department data when company data is available in database by name
     * @param name - company name
     * @return - CompanyModel
     */
	@Override
	public CompanyResponse getByName(String name) {
		Company findByCompanytName = companyRepository.findByname(name);
		CompanyResponse model = new CompanyResponse();
		BeanUtils.copyProperties(findByCompanytName, model);
		logger.debug("Companyfound with Name = " + name + " " + findByCompanytName);
		return model;	
		}
	/**
     * Returns true when company data is deleted from database by id
     * @return - boolean
     */

	@Override
	public boolean deleteCompany(Long id) {
		companyRepository.deleteById(id);
		logger.debug(" Company record is deleted from database ");
		return true;
	}
   
	 /**
     * Returns true when existing department data is store in database
     * 
     * @param model - new company data
     * @param id - company Id
     * @return - boolean
     */
	@Override
	public boolean updateCompany(CompanyRequest model, Long id) {
		boolean flag = Boolean.FALSE;
		Optional<Company> findById = companyRepository.findById(id);
		if (findById.isPresent()) {
			Company oldCompany = findById.get();
			oldCompany.setName(model.getName());
			oldCompany.setDescription(model.getDescription());
			oldCompany.setCreatedBy("abc");
			oldCompany.setUpdatedBy("abc");
			Company c =companyRepository.save(oldCompany);
			if(!Objects.isNull(c))
				flag = Boolean.TRUE;
			logger.debug("Company ID = " + id + " is updated in to database :: " + oldCompany);
			return flag;
		} else {
			logger.error("Company is not available in to database with ID= " + id);
			return flag;
		}
	}

	
	
	
}
