package com.hrms.admin.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.hrms.admin.entity.Company;


public interface CompanyRepository extends JpaRepository<Company, Long> {
    
	public Company findByname(String name);
	
	Page<Company> findAll(Pageable paging);

	/*
	 * @Query("SELECT c FROM company_entity c WHERE c.id, LIKE %?1%" +
	 * " OR c.company_name LIKE %?1%" + " OR c.description LIKE %?1%")
	 * 
	 * public List<CompanyResonseModel> search(String keyword);
	 */
	
	


}
