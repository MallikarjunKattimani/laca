package com.hrms.admin.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.hrms.admin.entity.Job;

@Repository
public interface Jobrepository extends JpaRepository<Job, Long> {

public Job findByname(String name);
	
	Page<Job> findAll(Pageable paging);
	
}
