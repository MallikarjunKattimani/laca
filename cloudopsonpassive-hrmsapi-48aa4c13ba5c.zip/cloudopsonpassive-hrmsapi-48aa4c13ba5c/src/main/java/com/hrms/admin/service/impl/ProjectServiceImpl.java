package com.hrms.admin.service.impl;


import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Project;
import com.hrms.admin.model.ProjectRequest;
import com.hrms.admin.repository.ProjectRepository;
import com.hrms.admin.response.ProjectResponse;
import com.hrms.admin.service.ProjectService;

/**
 * Contains method to perform DB operation on Project Record
 * @author {MD Atif}
 *
 */


@Service
public class ProjectServiceImpl implements ProjectService {

	private static Logger logger = LoggerFactory.getLogger(ProjectServiceImpl.class);

	@Autowired
	private ProjectRepository repo;

	
	 /**
     * Returns true when new Project is store in database
     * 
     * @param model - new project data
     * @return - boolean
     */
	
	@Override
	public boolean save(ProjectRequest model) {
		boolean flag = Boolean.FALSE;
		Project entity = new Project();
		BeanUtils.copyProperties(model, entity);
		//setting values
		entity.setName(model.getName());
		entity.setDescription(model.getdescription());
		entity.setCreatedBy("abc");
		entity.setUpdatedBy("abc");
		Project d = repo.save(entity);
		
		if(!Objects.isNull(d)) 
			flag = Boolean.TRUE;
		logger.debug("Project Added into database :: " + entity);
		return flag;
	}

	 /**
     * Returns All Project data when project data is available in database
     * @return - List of Project
     */
	@Override
	public List<ProjectResponse> getAllProject() {

		List<Project> allProject = repo.findAll();
		List<ProjectResponse> models = allProject.stream().map(entity -> {
			ProjectResponse model = new ProjectResponse();
			BeanUtils.copyProperties(entity, model);
			return model;
		}).collect(Collectors.toList());

		return models;
	}

	  /**
     * Returns Project data when project data is available in database by id
     * @param id - project Id
     * @return - ProjectResponse
     */
	@Override
	public ProjectResponse getById(Long id) {
		Optional<Project> optionalEntity = repo.findById(id);
		Project projectEntity = optionalEntity.get();
		ProjectResponse model = new ProjectResponse();
		BeanUtils.copyProperties(projectEntity, model);
		logger.debug("Project found with ID = " + id + " " + projectEntity);
		return model;
	}

	
	/**
     * Returns true when project data is deleted from database by id
     * @param id - project id
     * @return - boolean
     */
	@Override
	public boolean deleteProject(Long id) {
		repo.deleteById(id);
		logger.debug(" project record is deleted from database ");
		return true;

	}

	/**
     * Returns project data when Project data is available in database by name
     * @param name - project name
     * @return - Project
     */
	@Override
	public ProjectResponse getByName(String name) {
		Project findByProjectName = repo.findByname(name);
		ProjectResponse model = new ProjectResponse();
		BeanUtils.copyProperties(findByProjectName, model);
		logger.debug("Project found with Name = " + name + " " + findByProjectName);
		return model;
	}
	
	
	   /**
     * Returns true when existing project data is store in database
     * 
     * @param model - new project data
     * @param id - project Id
     * @return - boolean
     */
	@Override
	public boolean updateProject(ProjectRequest model, Long id) {
		boolean flag = Boolean.FALSE;
		logger.info("insert into updateDesignationById method in ProjectServiceImpl class ");
		Optional<Project> findById = repo.findById(id);
		if (findById.isPresent()) {
			Project oldProject = findById.get();
			oldProject.setName(model.getName());
			oldProject.setDescription(model.getdescription());
			oldProject.setCreatedBy("abc");
			oldProject.setUpdatedBy("abc");
			Project d =repo.save(oldProject);
			if(!Objects.isNull(d))
				flag = Boolean.TRUE;
			logger.debug("Project ID = " + id + " is updated in to database :: " + oldProject);
			return flag;
		}else {
			logger.error("Project is not available in to database with ID= " + id);
			return flag;
		}
	}
	
	
	@Override
	public List<Project> getAllProjectAccToPaging(Integer pageNo, Integer pageSize, String sortBy) {
		Pageable paging = PageRequest.of(pageNo, pageSize, Sort.by(sortBy));

		Page<Project> pagedResult = repo.findAll(paging);

			return pagedResult.getContent();
	}
	
}
