package com.hrms.admin.controller;

import java.math.BigInteger;
import java.util.List;
import java.util.Objects;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hrms.admin.exceptions.DepartmentNotFoundExceptions;
import com.hrms.admin.response.Response;
import com.hrms.admin.model.DepartmentRequest;
import com.hrms.admin.response.DepartmentResponse;
import com.hrms.admin.service.DepartmentService;
import com.hrms.admin.util.Constants;


/**
 * Contains method to provide APIs for Department Record
 * 
 * @author {Prabhat}
 *
 */
@RestController
@CrossOrigin
@RequestMapping("/admin/department")
public class DepartmentController {

	private static final Logger logger = LoggerFactory.getLogger(DepartmentController.class);

	@Autowired
	private DepartmentService service;

	/**
	 * Returns status code when new department is created
	 * 
	 * @param model - new department data
	 * @return - ResponseEntity
	 */
	@PostMapping
	public ResponseEntity<Response> add(@RequestBody DepartmentRequest model) {
		try {
			service.save(model);
			logger.debug("Department Added :: " + model);
			return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.INSERT_SUCCESS,Constants.TRUE), HttpStatus.CREATED);
		} catch (Exception e) {
			logger.error("Error while adding Department :: ", e);
			return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.INSERT_FAIL, Constants.FALSE), HttpStatus.INTERNAL_SERVER_ERROR);
		}	
	}

	/**
	 * Returns status code when existing department data is updated
	 * 
	 * @param model - new department data
	 * @param id    - depatment Id
	 * @return - ResponseEntity
	 */
	@PutMapping("/{id}")
	public ResponseEntity<Response> update(@RequestBody DepartmentRequest model, @PathVariable BigInteger id) {
		
		boolean updateDepartment = service.updateDepartment(model, id);
		if (updateDepartment) {
			logger.debug("Department ID = " + id + " is updated :: " + model);
			return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.UPDATE_SUCCESS, Constants.TRUE), HttpStatus.OK);
		} else {
			logger.error("Error while updating Department :: ");
			return new ResponseEntity<Response>(new Response(model.getName()+" "+Constants.UPDATE_FAIL, Constants.FALSE), HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * Returns Department and status code when department data is available by id
	 * 
	 * @param id - depatment Id
	 * @return - ResponseEntity
	 */
	@GetMapping("/{id}")
	public ResponseEntity<DepartmentResponse> getById(@PathVariable BigInteger id) {

		try {
			DepartmentResponse departmentById = service.getById(id);
			logger.debug("Department fond with ID = " + id + " " + departmentById);
			return new ResponseEntity<DepartmentResponse>(departmentById, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Department by Id :: " + id);
			throw new DepartmentNotFoundExceptions("Department");
		}
	}

	/**
	 * Returns Department data and status code when department data is available by
	 * name
	 * 
	 * @param name - depatment name
	 * @return - ResponseEntity
	 */
	@GetMapping("/name/{name}")
	public ResponseEntity<DepartmentResponse> getByName(@PathVariable String name) {

		try {
			DepartmentResponse departmentByName = service.getByName(name);
			logger.debug("Department fond with Name = " + name + " " + departmentByName);
			return new ResponseEntity<DepartmentResponse>(departmentByName, HttpStatus.OK);
		} catch (Exception e) {
			logger.error("Error while getting Department by name :: " + name);
			throw new DepartmentNotFoundExceptions("Department not found");
		}

	}

	/**
	 * Returns All Department data when department data is available
	 * 
	 * @return - List of DepartmentModel
	 */
	@GetMapping
	public List<DepartmentResponse> getAll() {
		List<DepartmentResponse> allDepartment = service.getAllDepartment();
		if (allDepartment != null) {
			logger.debug("Found " + allDepartment.size() + " Department");
			return allDepartment;
		}
		logger.error("error while getting all Department Record");
		throw new DepartmentNotFoundExceptions("Department not found");
	}

	/**
	 * Returns status code when department data is deleted
	 * 
	 * @param id - depatment id
	 * @return - ResponseEntity
	 */
	@DeleteMapping("/{id}")
	public ResponseEntity<Response> delete(@PathVariable BigInteger id) {
		
			DepartmentResponse department = service.getById(id);
			if(!Objects.isNull(department)) {
				service.deleteDepartment(id);
				logger.debug("Department record is Deleted with id " + id);
				return new ResponseEntity<Response>(new Response(department.getName()+" "+Constants.DELETE_SUCCESS, Constants.TRUE), HttpStatus.OK);
			}else {
				logger.debug("Department not exist ");
				return new ResponseEntity<Response>(new Response("Department " +" "+Constants.DELETE_FAIL, Constants.FALSE), HttpStatus.NO_CONTENT);
			}
	}
}