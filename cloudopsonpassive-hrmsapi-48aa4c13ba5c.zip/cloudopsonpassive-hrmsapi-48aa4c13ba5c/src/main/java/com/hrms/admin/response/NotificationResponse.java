package com.hrms.admin.response;

import java.math.BigInteger;

public class NotificationResponse {
	private BigInteger id;
	private String subject;
	private String description;

	public NotificationResponse() {

	}

	public NotificationResponse(BigInteger id, String subject, String descriptions) {
		super();
		this.id = id;
		this.subject = subject;
		this.description = descriptions;
	}

	public BigInteger getId() {
		return id;
	}

	public void setId(BigInteger id) {
		this.id = id;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getDescriptions() {
		return description;
	}

	public void setDescriptions(String description) {
		this.description = description;
	}

}
