package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.model.AttendanceRequest;
import com.hrms.admin.response.AttendanceResponse;

public interface AttendanceService {
	
	
	public boolean save(AttendanceRequest model);

	public List<AttendanceResponse> getAllAttendnace();

	public AttendanceResponse getById(Long id);
	
	public AttendanceResponse getByName(String companyName);

	public boolean deleteAttendnace(Long id);

	public boolean updateAttendnace(AttendanceRequest model, Long id);

	
}
