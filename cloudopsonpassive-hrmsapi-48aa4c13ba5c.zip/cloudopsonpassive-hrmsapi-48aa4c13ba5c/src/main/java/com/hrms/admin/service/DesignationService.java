package com.hrms.admin.service;

import java.util.List;

import com.hrms.admin.model.DesignationRequest;
import com.hrms.admin.response.DesignationResponse;

public interface DesignationService {

	public List<DesignationResponse> getAllDesignations();

	public DesignationResponse getById(Long id);

	public boolean save(DesignationRequest model);

	public boolean updateDesignation(DesignationRequest model, Long id);

	public boolean deleteDesignation(Long  id);
}
