package com.hrms.admin.exceptions;

import java.util.Date;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.hrms.admin.util.Constants;

@ControllerAdvice
@RestController
public class ProjectCustomizedResponseEntityExceptionHandler extends ResponseEntityExceptionHandler{
	
	 @ExceptionHandler(Exception.class)
	  public final ResponseEntity<Response> handleAllExceptions(Exception ex, WebRequest request) {
		  return new ResponseEntity<Response>(new Response(ex.getMessage()+" "+Constants.INSERT_FAIL,Constants.FALSE), HttpStatus.BAD_REQUEST);
	  }

	  @ExceptionHandler(ProjectNotCreatedExceptions.class)
	  public final ResponseEntity<ProjectExceptionResponse> handleProjectNotFoundException(ProjectNotFoundExceptions ex, WebRequest request) {
		  ProjectExceptionResponse projectExceptionResponse = new ProjectExceptionResponse(new Date(), ex.getMessage(),
	        request.getDescription(false));
	    return new ResponseEntity<>(projectExceptionResponse, HttpStatus.NOT_FOUND);
	  }

	  @ExceptionHandler(ProjectNotFoundExceptions.class)
	  public final ResponseEntity<Response> handleProjectNotCreatedException(ProjectNotCreatedExceptions ex) {
		  return new ResponseEntity<Response>(new Response(
				  ex.getMessage()+" "+Constants.INSERT_FAIL,
				  Constants.FALSE),
				  HttpStatus.BAD_REQUEST);
	  }

}
