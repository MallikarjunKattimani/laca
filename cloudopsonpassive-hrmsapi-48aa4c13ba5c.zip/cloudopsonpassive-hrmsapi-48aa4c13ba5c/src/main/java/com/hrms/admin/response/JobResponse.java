package com.hrms.admin.response;

public class JobResponse {
	
	private Long id;
	private String name;
	private String description;
	private Float experiance;
	
	public JobResponse(Float experiance) {
		super();
		this.experiance = experiance;
	}

	public JobResponse() {
	}
	
	public JobResponse(Long id, String name, String description, Float experiance) {
		this.id = id;
		this.name = name;
		this.description = description;
		this.experiance = experiance;
	}
	

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Float getExperiance() {
		return experiance;
	}

	public void setExperiance(Float experiance) {
		this.experiance = experiance;
	}
	
}
