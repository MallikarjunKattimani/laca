package com.hrms.admin.exceptions;

import java.util.Date;

public class HolidaySuccessResponse {

	 private Date timestamp;
	  private String message;

	  public HolidaySuccessResponse(Date timestamp, String message) {
	    super();
	    this.timestamp = timestamp;
	    this.message = message;
	  }

	  public Date getTimestamp() {
	    return timestamp;
	  }

	  public String getMessage() {
	    return message;
	  }

}
