package com.hrms.admin.service;

import java.math.BigInteger;
import java.util.List;

import com.hrms.admin.model.SkillRequest;
import com.hrms.admin.response.SkillResponse;

public interface SkillService {

	public boolean save(SkillRequest model);

	public boolean updateSkill(SkillRequest model, BigInteger id);

	public SkillResponse getById(BigInteger id);
	
	public SkillResponse getByName(String skillSet);

	public List<SkillResponse> getAllSkill();

	public boolean deleteSkill(BigInteger id);


}
