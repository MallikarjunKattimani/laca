package com.hrms.admin.service.impl;

import java.math.BigInteger;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hrms.admin.entity.Notification;
import com.hrms.admin.model.NotificationRequest;
import com.hrms.admin.repository.NotificationRepository;
import com.hrms.admin.response.NotificationResponse;
import com.hrms.admin.service.NotificationService;

@Service
public class NotificationServiceImpl implements NotificationService {

	private static final Logger logger = LoggerFactory.getLogger(NotificationServiceImpl.class);

	@Autowired
	private NotificationRepository repo;

	/**
	 * Returns true when new notification is store in database
	 * 
	 * @param model - new notification data
	 * @return - boolean
	 */
	@Override
	public boolean save(NotificationRequest model) {
		boolean flag = Boolean.FALSE;
		Notification entity = new Notification();
		BeanUtils.copyProperties(model, entity);
		// setting values
		entity.setSubject(model.getSubject());
		entity.setDescription(model.getDescription());
		entity.setCreatedBy("abc");
		entity.setUpdatedBy("abc");
		Notification d = repo.save(entity);
		if (!Objects.isNull(d))
			flag = Boolean.TRUE;
		logger.debug("Notification Added into database :: " + entity);
		return flag;

	}

	/**
	 * Returns true when existing notification data is store in database
	 * 
	 * @param model - new notification data
	 * @param id    - notification Id
	 * @return - boolean
	 */
	@Override
	public boolean updateNotification(NotificationRequest model, BigInteger id) {
		boolean flag = Boolean.FALSE;
		Optional<Notification> findById = repo.findById(id);
		if (findById.isPresent()) {
			Notification oldNotification = findById.get();
			oldNotification.setSubject(model.getSubject());
			oldNotification.setDescription(model.getDescription());
			oldNotification.setCreatedBy("abc");
			oldNotification.setUpdatedBy("abc");
			Notification n = repo.save(oldNotification);
			if (!Objects.isNull(n))
				flag = Boolean.TRUE;
			logger.debug("Notification ID = " + id + " is updated in to database :: " + oldNotification);
			return flag;
		} else {
			logger.error("Notification is not available in to database with ID= " + id);
			return flag;
		}

	}

	/**
	 * Returns Notification data when notification data is available in database by
	 * id
	 * 
	 * @param id - notification Id
	 * @return - NotificationModel
	 */
	@Override
	public NotificationResponse getById(BigInteger id) {
		Optional<Notification> optionalEntity = repo.findById(id);
		Notification notificationEntity = optionalEntity.get();
		NotificationResponse model = new NotificationResponse();
		BeanUtils.copyProperties(notificationEntity, model);
		logger.debug("Notification found with ID = " + id + " " + notificationEntity);

		return model;
	}

	/**
	 * Returns Notification data when notification data is available in database by
	 * subject
	 * 
	 * @param subject - subject
	 * @return - NotificationModel
	 */
	@Override
	public NotificationResponse getBySubject(String subject) {
		Notification findBySubject = repo.findBysubject(subject);
		NotificationResponse model = new NotificationResponse();
		BeanUtils.copyProperties(findBySubject, model);
		logger.debug("Notification found with Subject = " + subject + " " + findBySubject);
		return model;
	}

	/**
	 * Returns All Notification data when notification data is available in database
	 * 
	 * @return - List of NotificationModel
	 */
	@Override
	public List<NotificationResponse> getAllNotifications() {
		List<Notification> allNotifications = repo.findAll();
		List<NotificationResponse> models = allNotifications.stream().map(entity -> {
			NotificationResponse model = new NotificationResponse();
			BeanUtils.copyProperties(entity, model);
			return model;
		}).collect(Collectors.toList());

		return models;
	}

	/**
	 * Returns true when notification data is deleted from database by id
	 * 
	 * @param id - notification id
	 * @return - boolean
	 */
	@Override
	public boolean deleteNotification(BigInteger id) {
		repo.deleteById(id);
		logger.debug(" Notification record is deleted from database ");
		return true;
	}
}